execute as @e[type=interaction,distance=..50,tag=amet,tag=!rc.done] if data entity @s interaction run tag @s add right_clicked

execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] on target run function projectswords:interaction/score
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] run tag @s add rc.done

execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 1 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 0.5
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 2 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 0.6
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 3 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 0.7
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 4 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 0.8
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 5 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 0.9
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 6 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 1.0
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 7 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 1.1
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 8 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 1.2
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 9 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 1.3
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 10 run playsound minecraft:block.note_block.chime block @a ~ ~ ~ 5 1.4
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 10 run playsound minecraft:entity.player.levelup block @a ~ ~ ~ 2 1
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] on target if score clicks ametclick matches 10 run give @s minecraft:amethyst_shard[enchantments={"minecraft:protection":1},tooltip_display={hidden_components:["enchantments"]},custom_name={"bold":true,"color":"#8B31E6","italic":false,"obfuscated":false,"strikethrough":false,"text":"Ethereal Shard","underlined":false},lore=[{"bold":false,"color":"#6323A3","italic":true,"obfuscated":false,"strikethrough":false,"text":"An ancient fragment, said to have divine origins.","underlined":false}]]
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] on target if score clicks ametclick matches 10 run tag @s add has.allay_key
execute as @e[type=interaction,distance=..50,tag=amet,tag=right_clicked] at @s if score clicks ametclick matches 10 run scoreboard players reset clicks ametclick

execute as @e[type=interaction,distance=..50,tag=amet] run tag @s remove right_clicked
execute as @e[type=interaction,distance=..50,tag=amet] run data remove entity @s interaction