scoreboard players add clicks ametclick 1
