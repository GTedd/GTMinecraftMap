tellraw @s[team=!Villager] [{"text":"You will no longer Spectate the next game.","color":"red"}]
playsound minecraft:block.note_block.pling master @s[team=!Villager] ~ ~ ~ 0.7 0.4
team join Villager @s
advancement revoke @s only projectswords:press_button_leave