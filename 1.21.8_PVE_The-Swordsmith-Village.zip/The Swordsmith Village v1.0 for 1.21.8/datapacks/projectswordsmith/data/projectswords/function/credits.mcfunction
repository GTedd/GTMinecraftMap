setblock 8 103 0 minecraft:polished_blackstone_button[powered=false,facing=west]
tellraw @s [{"text":"  PvE Village","color":"aqua","bold":true}]
tellraw @s [{"text":" by ProjectStew","color":"dark_aqua","bold":false}]
tellraw @s [{"text":"▶ YouTube: ","color":"red","bold":true},{"click_event":{"action":"open_url","url":"https://www.youtube.com/@projectstew/videos"},"text":"[🔗]","color":"red","bold":false,"hover_event":{"action":"show_text","value":[{"text":"Open on Youtube"}]}}]
tellraw @s [{"text":"▶ Discord: ","color":"blue","bold":true},{"click_event":{"action":"open_url","url":"https://discord.gg/efsbVDXz46"},"text":"[🔗]","color":"blue","bold":false,"hover_event":{"action":"show_text","value":[{"text":"Open on Discord"}]}}]
execute at @s run playsound minecraft:entity.arrow.hit_player master @s ~ ~ ~ 0.7 1.1
tag @s remove credits