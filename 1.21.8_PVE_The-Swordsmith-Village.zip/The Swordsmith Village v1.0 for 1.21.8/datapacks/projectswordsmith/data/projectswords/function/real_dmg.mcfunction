
scoreboard players add @s damageDealt.real 1
scoreboard players remove @s damageDealt 10