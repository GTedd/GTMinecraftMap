# dev #
execute as @a[tag=dev] run effect give @s night_vision infinite 1 true

# Relogs #
#sync tags
execute as @a[scores={leave=1}] run function projectswords:relog
execute as @a[scores={leave=1}] unless score @s reset.wasHere matches 1 run function projectswords:reset_relog
scoreboard players set @a leave 0
#victory
execute if entity @a[tag=victory] run tag @a add victory

# Spectator/Villager #
execute as @a[team=Spectator,tag=!dev] run clear @s
execute as @a[team=!Villager,team=!Spectator] run function projectswords:newplayer
execute as @a[team=Spectator] if entity @a[tag=housetp] run tag @s add housetp
execute as @a[team=!Spectator,tag=!dev,team=!Villager] run team join Villager @s
execute as @a[tag=!housetp] run scoreboard objectives setdisplay sidebar lobby
execute as @a[tag=housetp] run scoreboard objectives setdisplay sidebar health

# NoPickup #
execute at @a as @e[distance=..5,type=item] if data entity @s {Item:{components:{"minecraft:custom_data":{NoPickup:1b}}}} at @s run function projectswords:no_pickup

# Swords #
execute as @a if data entity @s Inventory[{id:"minecraft:diamond_sword"}] run function projectswords:has_swords

execute as @a[tag=watersword1] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:1b}}}]}] run function projectswords:swords/water_1
execute as @a[tag=watersword2] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:2b}}}]}] run function projectswords:swords/water_2
execute as @a[tag=watersword3] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:3b}}}]}] run function projectswords:swords/water_3
execute as @a[tag=watersword4] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:4b}}}]}] run function projectswords:swords/water_4

execute as @a[tag=magmasword1] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:1b}}}]}] run function projectswords:swords/magma_1
execute as @a[tag=magmasword2] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:2b}}}]}] run function projectswords:swords/magma_2
execute as @a[tag=magmasword3] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:3b}}}]}] run function projectswords:swords/magma_3
execute as @a[tag=magmasword4] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:4b}}}]}] run function projectswords:swords/magma_4

execute as @a[tag=slimesword1] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:1b}}}]}] run function projectswords:swords/slime_1
execute as @a[tag=slimesword2] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:2b}}}]}] run function projectswords:swords/slime_2
execute as @a[tag=slimesword3] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:3b}}}]}] run function projectswords:swords/slime_3
execute as @a[tag=slimesword4] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:4b}}}]}] run function projectswords:swords/slime_4

execute as @a[tag=icesword1] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:1b}}}]}] run function projectswords:swords/ice_1
execute as @a[tag=icesword2] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:2b}}}]}] run function projectswords:swords/ice_2
execute as @a[tag=icesword3] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:3b}}}]}] run function projectswords:swords/ice_3
execute as @a[tag=icesword4] unless entity @s[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:4b}}}]}] run function projectswords:swords/ice_4

# Stop Mobs #
execute if score dummy nighttimer matches 1 as @a[tag=diamondbtier] unless entity @e[type=minecraft:villager,tag=expedition.ran] run scoreboard players set dummy nighttimer 2
execute if score dummy nighttimer matches 1..2 as @a[tag=diamondbtier] run tag @s add stop.mobs
execute if score dummy nighttimer matches 1..2 as @a[tag=!final.push,tag=diamondbtier,tag=!all.cleared] positioned -191.99 79.90 114.00 if entity @e[tag=Mob,distance=..300] run tellraw @s [{"text":"<","color":"white"},{"selector":"@s"},{"text":">","color":"white"},{"text":" It's the final push! Let's ","color":"gray"},{"text":"defeat ","color":"red"},{"text":"every single alive Mob!","color":"gray"}]
execute if score dummy nighttimer matches 1..2 as @a[tag=!final.push,tag=diamondbtier,tag=!all.cleared] positioned -191.99 79.90 114.00 if entity @e[tag=Mob,distance=..300] run tag @s add final.push
execute if score dummy nighttimer matches 1..2 as @a[tag=diamondbtier,tag=!all.cleared] positioned -191.99 79.90 114.00 unless entity @e[tag=Mob,distance=..300] run tellraw @s [{"text":"<","color":"white"},{"selector":"@s"},{"text":">","color":"white"},{"text":" And that was the last one. Well, the ","color":"gray"},{"text":"Librarian ","color":"white"},{"text":"told me this was the last night of attacks... I should go speak to him.","color":"gray"}]
execute if score dummy nighttimer matches 1..2 as @a[tag=diamondbtier,tag=!all.cleared] positioned -191.99 79.90 114.00 unless entity @e[tag=Mob,distance=..300] run tag @s add all.cleared
execute as @a[tag=all.cleared] run function projectswords:transition_prepare

# Prepare for Boss #
execute if score dummy daytimer matches 9997 as @a[tag=diamondbtier] run scoreboard players set dummy preboss 18000
execute if score dummy daytimer matches 9997 as @a[tag=diamondbtier] run function projectswords:transition_prepare_end
execute if entity @a[tag=preboss,tag=!boss.unlocked] run function projectswords:preboss

# Bossbar #
execute positioned -236 81 -30 as @a[distance=..5] run tag @s add in_boss
execute as @a[tag=in_boss] positioned -190 40 -10 run function projectswords:bossbar
execute as @a[tag=in_boss,tag=!boss_spawned] if entity @s[predicate=projectswords:below_y60] run setblock -177 26 1 minecraft:redstone_block

# Boss #
#summonboss: /summon ghast ~ ~ ~ {Silent:1b,Invulnerable:0b,PersistenceRequired:1b,NoAI:0b,Health:500f,Tags:["Boss"],CustomName:'[{"text":"[Golem] ","color":"dark_gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"The Stone","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]',active_effects:[{id:invisibility,Amplifier:1b,Duration:199999980,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:500}]}
#summonstone: /summon minecraft:block_display ~ ~ ~ {Tags:["Stone","Mob"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[5f,5f,5f]},block_state:{Name:"minecraft:stone"}}
execute positioned -178.52 36.00 -0.49 as @e[distance=..100,type=ghast,tag=Boss] at @s run function projectswords:boss
# Death #
execute positioned -178.52 36.00 -0.49 as @a[tag=boss_spawned] unless entity @e[distance=..100,type=ghast,tag=Boss] run function projectswords:boss_death
execute positioned -178.52 36.00 -0.49 if score dummy boss.death matches 200.. as @a[tag=!boss_spawned] unless entity @e[distance=..100,type=ghast,tag=Boss] run kill @e[tag=Mob]
execute positioned -178.52 36.00 -0.49 if score dummy boss.death matches 200.. as @a[tag=!boss_spawned] unless entity @e[distance=..100,type=ghast,tag=Boss] run tag @s add setup
execute positioned -178.52 36.00 -0.49 if score dummy boss.death matches 200.. as @a[tag=!boss_spawned] unless entity @e[distance=..100,type=ghast,tag=Boss] run tag @s remove parrot.unlocked
execute positioned -178.52 36.00 -0.49 if score dummy boss.death matches 200.. as @a[tag=!boss_spawned] unless entity @e[distance=..100,type=ghast,tag=Boss] run tag @s remove opened.allay
execute positioned -178.52 36.00 -0.49 if score dummy boss.death matches 200.. as @a[tag=!boss_spawned] unless entity @e[distance=..100,type=ghast,tag=Boss] run tag @s add ending
execute positioned -178.52 36.00 -0.49 if score dummy boss.death matches 200.. as @a[tag=!boss_spawned] unless entity @e[distance=..100,type=ghast,tag=Boss] run tp @e[distance=..100,team=Companions] 0 0 0
execute positioned -178.52 36.00 -0.49 if score dummy boss.death matches 200.. as @a[tag=!boss_spawned] unless entity @e[distance=..100,type=ghast,tag=Boss] run scoreboard players reset dummy boss.death
execute positioned -178.52 36.00 -0.49 unless entity @e[distance=..100,type=ghast,tag=Boss] run function projectswords:boss_cleanup

# DayTimer #
execute if score dummy daytimer matches 9998 run tag @a remove night
execute if score dummy daytimer matches 9998 run tag @a add day
execute if score dummy daytimer matches 9998 run tp @a[tag=!day0] -213.5 79 23.5
execute if score dummy daytimer matches 9998 run tp @a[tag=day1,tag=!transition.comein.tp] -217.5 79 27.7
execute if score dummy daytimer matches 9998 run tag @a add transition.comein.tp

execute unless score dummy daytimer matches 10000 run scoreboard players remove dummy daytimer 1
execute if score dummy daytimer matches 0 run setblock -240 44 91 redstone_block
execute if score dummy daytimer matches 0 run scoreboard players set dummy daytimer 10000

# NightTimer #
execute if score dummy nighttimer matches 9998 run tag @a remove day
execute if score dummy nighttimer matches 9998 run scoreboard players set @s clickevent.compass 0
execute if score dummy nighttimer matches 9998 run tag @a add night
execute if score dummy nighttimer matches 9998 run tp @a[tag=housetp,tag=!day0] -197 65 113
execute if score dummy nighttimer matches 9998 run tellraw @a[tag=housetp,tag=!day0,tag=night] [{"text":"-------------------------------------------","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\nThe Night Falls... The Monsters are Coming.","color":"#3c349a","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"\n-------------------------------------------","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute if score dummy nighttimer matches 9998 as @a[tag=housetp,tag=!day0] at @s run playsound minecraft:entity.wither.spawn master @s ~ ~ ~ 0.5 1.4 0

execute unless score dummy nighttimer matches 10000 run scoreboard players remove dummy nighttimer 1
execute if score dummy nighttimer matches 0 run setblock -236 44 91 redstone_block
execute if score dummy nighttimer matches 0 run scoreboard players set dummy nighttimer 10000

# Death #
execute as @a[scores={deathMSG=1..}] run function projectswords:death
execute as @a[scores={death.timer=0..200}] run scoreboard players remove @s death.timer 1
execute as @a[tag=!hardcore,scores={death.timer=1}] run title @s clear
execute as @a[tag=!hardcore,scores={death.timer=0},team=!Spectator] run gamemode adventure @s
execute as @a[tag=!hardcore,scores={death.timer=0}] run tag @s remove dead_spectator
execute as @a[tag=!hardcore,scores={death.timer=0}] run scoreboard players reset @s death.timer

# Spawn #
spawnpoint @a[tag=!housetp] 0 101 0 -90
spawnpoint @a[tag=housetp,tag=!hardcore,tag=!boss_spawned] -197 65 113 90
execute if block 0 103 8 minecraft:polished_blackstone_button[powered=true] if entity @a[team=Villager] run setblock 0 97 -2 redstone_block
execute if block 0 103 8 minecraft:polished_blackstone_button[powered=true] unless entity @a[team=Villager] run tellraw @a {"text":"The game cannot start with only Spectators!","color":"red"}
execute if block 0 103 8 minecraft:polished_blackstone_button[powered=true] unless entity @a[team=Villager] run setblock 0 103 8 minecraft:polished_blackstone_button[facing=north]
execute if block 8 103 0 minecraft:polished_blackstone_button[powered=true] run tag @a add credits
execute if block 0 103 -8 minecraft:polished_blackstone_button[powered=true] run tag @a add difficulty

# credits
execute as @a[tag=credits] run function projectswords:credits

# stats
execute as @a if score @s damageDealt matches 10.. run function projectswords:real_dmg
execute as @a if score @s damageTaken matches 10.. run function projectswords:real_taken

execute if score players difficulty matches 1 run tag @a add 1_player
execute unless score players difficulty matches 1 run tag @a remove 1_player
execute if score players difficulty matches 2 run tag @a add 2_players
execute unless score players difficulty matches 2 run tag @a remove 2_players
execute if score players difficulty matches 3 run tag @a add 3_players
execute unless score players difficulty matches 3 run tag @a remove 3_players
execute if score players difficulty matches 4.. run tag @a add 4_players
execute unless score players difficulty matches 4.. run tag @a remove 4_players

# difficulty
execute as @p[tag=difficulty] run function projectswords:difficulty

execute if score difficulty difficulty matches 1 run tag @a add easy_difficulty
execute unless score difficulty difficulty matches 1 run tag @a remove easy_difficulty
execute if score difficulty difficulty matches 2 run tag @a add normal_difficulty
execute unless score difficulty difficulty matches 2 run tag @a remove normal_difficulty
execute if score difficulty difficulty matches 3 run tag @a add hard_difficulty
execute unless score difficulty difficulty matches 3 run tag @a remove hard_difficulty
execute if score difficulty difficulty matches 4 run tag @a add hardcore
execute unless score difficulty difficulty matches 4 run tag @a remove hardcore

#lobby scoreboard
scoreboard players display numberformat @s lobby blank
execute as @a[team=Villager] run scoreboard players display numberformat @s lobby fixed [{"text":"Player","color":"red","bold":true}]
execute as @a[team=Spectator] run scoreboard players display numberformat @s lobby fixed [{"text":"Spectator","color":"dark_gray","bold":true}]

scoreboard players set Difficulty: lobby 2
scoreboard players display name Difficulty: lobby [{"text":"Difficulty:","color":"yellow"}]
execute as @a[tag=easy_difficulty] run scoreboard players display numberformat Difficulty: lobby fixed [{"text":"Novice","color":"green","bold":true}]
execute as @a[tag=normal_difficulty] run scoreboard players display numberformat Difficulty: lobby fixed [{"text":"Intermediate","color":"yellow","bold":true}]
execute as @a[tag=hard_difficulty] run scoreboard players display numberformat Difficulty: lobby fixed [{"text":"Advanced","color":"red","bold":true}]
execute as @a[tag=hardcore] run scoreboard players display numberformat Difficulty: lobby fixed [{"text":"Master","color":"dark_red","bold":true}]

scoreboard players operation Player: lobby = playerCount difficulty
scoreboard players display name Player: lobby [{"text":"Player Count:","color":"yellow"}]
execute if score Player: lobby matches 0 run scoreboard players display numberformat Player: lobby fixed [{"text":"0","color":"red","bold":true}]
execute as @a[tag=1_player] run scoreboard players display numberformat Player: lobby fixed [{"text":"1","color":"yellow","bold":true}]
execute as @a[tag=2_players] run scoreboard players display numberformat Player: lobby fixed [{"text":"2","color":"yellow","bold":true}]
execute as @a[tag=3_players] run scoreboard players display numberformat Player: lobby fixed [{"text":"3","color":"yellow","bold":true}]
execute as @a[tag=4_players] run scoreboard players display numberformat Player: lobby fixed [{"text":"4+","color":"yellow","bold":true}]

scoreboard players set playerCount difficulty 0
execute as @a[team=Villager] run scoreboard players add playerCount difficulty 1
execute as @a[team=Spectator] run scoreboard players set @s lobby -1
scoreboard players operation players difficulty = playerCount difficulty

execute as @a[tag=!hardcore,tag=dead_spectator,gamemode=spectator,team=Villager] at @s unless entity @a[gamemode=!spectator,distance=..0] run spectate @a[gamemode=!spectator,sort=nearest,limit=1]
execute as @a[tag=!dev,tag=!hardcore,tag=dead_spectator,gamemode=spectator,team=Villager,tag=!boss_spawned] at @s unless entity @a[gamemode=adventure] run tp @s -197 65 113 90 0
execute as @a[tag=!dev,tag=!hardcore,tag=dead_spectator,gamemode=spectator,team=Villager,tag=boss_spawned] at @s unless entity @a[gamemode=adventure] run tp @s -229 25 32
execute as @a[tag=!hardcore,tag=dead_spectator,team=Villager] run function projectswords:player_death

execute as @a[tag=!dead_spectator] run scoreboard players reset @s respawn.timer

execute as @a[tag=hardcore] run function projectswords:hardcore

#pets
execute if block 0 117 0 #minecraft:buttons[powered=true] run function projectswords:pets

# Jukebox #
execute positioned -180 67 84 as @p[limit=1,tag=!jukebox,tag=!jukebox_complete] if block -180 67 84 minecraft:jukebox[has_record=true] run fill -186 74 80 -186 73 80 air destroy
execute positioned -180 67 84 as @p[limit=1,tag=!jukebox,tag=!jukebox_complete] positioned -180 67 84 if block ~ ~ ~ minecraft:jukebox[has_record=true] run tellraw @a [{"text":"<","color":"yellow"},{"selector":"@p[team=!Spectator]"},{"text":"> Something seems to have opened nearby..."}]
execute positioned -180 67 84 as @p[limit=1,tag=!jukebox] if block -180 67 84 minecraft:jukebox[has_record=true] run tag @s add jukebox
execute positioned -180 67 84 as @p[limit=1,tag=jukebox] run function projectswords:song
execute if score songofswords timer matches 200.. run setblock -180 67 84 minecraft:jukebox
execute if score songofswords timer matches 200.. run summon item -180 67.7 84 {Item:{id:"minecraft:music_disc_5",count:1,components:{"minecraft:lore": [{italic: 0b, underlined: 0b, bold: 0b, color: "gray", obfuscated: 0b, strikethrough: 0b, text: '"The Song of Swords"'}], "minecraft:tooltip_display": {hidden_components: ["minecraft:jukebox_playable"]}}}}
execute if score songofswords timer matches 200.. run scoreboard players reset songofswords timer
execute as 0147acc8-14ba-4f17-b1d0-3273b9d76713 if data entity @s interaction on target if entity @s[nbt={SelectedItem:{id:"minecraft:music_disc_5",components:{"minecraft:lore": [{italic: 0b, underlined: 0b, bold: 0b, color: "gray", obfuscated: 0b, strikethrough: 0b, text: '"The Song of Swords"'}], "minecraft:tooltip_display": {hidden_components: ["minecraft:jukebox_playable"]}}}}] run function projectswords:jukebox
execute as 0147acc8-14ba-4f17-b1d0-3273b9d76713 run data remove entity @s interaction

# Spectate #
execute as @a[tag=!housetp,team=Spectator,tag=!dev] at @s run gamemode adventure @s
execute as @a[tag=housetp,team=Spectator] run tag @s add dead_spectator
execute as @a[tag=housetp,team=Spectator,tag=!dev] at @s run gamemode spectator @s
execute as @a[gamemode=spectator,team=Spectator,tag=housetp,tag=!dev] at @s unless entity @a[gamemode=!spectator,distance=..0] run spectate @a[gamemode=!spectator,sort=nearest,limit=1]
execute as @a[team=Spectator,gamemode=spectator] run title @s actionbar [{"bold":false,"color":"yellow","italic":false,"obfuscated":false,"strikethrough":false,"text":"Press ","underlined":false},{"bold":true,"italic":false,"keybind":"key.hotbar.1","obfuscated":false,"strikethrough":false,"underlined":false},{"bold":false,"color":"yellow","italic":false,"obfuscated":false,"strikethrough":false,"text":" to change who you are Spectating","underlined":false}]

# Magnetic #
execute as @a[tag=magnetic] at @s as @e[type=item,nbt=!{Item:{id:"minecraft:firework_star",components:{"minecraft:firework_explosion":{shape:"small_ball"}}}},distance=..10] at @s run function projectswords:magnetic
execute as @a if data entity @s {Inventory:[{id:"minecraft:firework_star",components:{"minecraft:firework_explosion":{shape:"small_ball"}}}]} run tag @s add magnetic
execute as @a unless data entity @s {Inventory:[{id:"minecraft:firework_star",components:{"minecraft:firework_explosion":{shape:"small_ball"}}}]} run tag @s remove magnetic

# Enchanter #
execute positioned -276 88 152 as @a[distance=..20] as @e[type=armor_stand,tag=Spin2] run function projectswords:enchanter

execute positioned -276 88 152 as @e[distance=..5,type=interaction,tag=enchanter] run function projectswords:enchants/interaction

# Dialogue #
# day0
execute as @a[tag=day0] run function projectswords:day0
execute as @a[team=Spectator,tag=!day1] run tag @s remove nightbar

# day0->1
execute as @a[tag=day1] run tag @a add day1
execute as @a[tag=outofhouse] run tag @a add outofhouse
tellraw @a[tag=day1,tag=!tellraw1] [{"text":"<","color":"white"},{"selector":"@p[team=!Spectator]"},{"text":">","color":"white"},{"text":" What on earth were those monsters doing here?! I thought our village was completely hidden from the world... I should go to the","color":"gray"},{"text":" Library ","color":"gold"},{"text":"for some info on what happened.","color":"gray"}]
execute as @a[tag=day1,tag=!tellraw1] run tag @s add tellraw1
execute as @a[tag=day1,tag=!transition1] run function projectswords:transition1

# day1
execute positioned -164.52 68.00 160.98 as @a[tag=!outofhouse,distance=..1] run tellraw @s [{"text":"<","color":"white"},{"selector":"@s"},{"text":">","color":"white"},{"text":" Are those... monsters?! Oh no, I better defeat them!","color":"gray"}]
execute positioned -242.51 70.00 109.83 as @a[tag=!outofhouse,distance=..1] run tellraw @s [{"text":"<","color":"white"},{"selector":"@s"},{"text":">","color":"white"},{"text":" Are those... monsters?! Oh no, I better defeat them!","color":"gray"}]
execute positioned -244.93 71.00 131.99 as @a[tag=!outofhouse,distance=..1] run tellraw @s [{"text":"<","color":"white"},{"selector":"@s"},{"text":">","color":"white"},{"text":" Are those... monsters?! Oh no, I better defeat them!","color":"gray"}]
execute positioned -241.80 65.94 131.99 as @a[tag=!outofhouse,distance=..1] run tellraw @s [{"text":"<","color":"white"},{"selector":"@s"},{"text":">","color":"white"},{"text":" Are those... monsters?! Oh no, I better defeat them!","color":"gray"}]
execute positioned -244.93 71.00 131.99 as @a[distance=..1] run tag @s add outofhouse
execute positioned -164.52 68.00 160.98 as @a[distance=..1] run tag @s add outofhouse
execute positioned -242.51 70.00 109.83 as @a[distance=..1] run tag @s add outofhouse
execute positioned -241.80 65.94 131.99 as @a[distance=..1] run tag @s add outofhouse

# librarian1
execute positioned -217.5 79.5 26.0 as @p[team=!Spectator,dx=2,dy=1,dz=2] run tag @e[type=minecraft:villager,name="[Librarian] Kacper",limit=1,sort=nearest] add comein
execute positioned -211 79 23 as @e[distance=..5,type=minecraft:villager,tag=comein,tag=!tpran1] run function projectswords:tp_ran
#execute as @e[type=minecraft:villager,tag=comein] at @s run tp @s ~ ~ ~ facing entity @p[team=!Spectator]
execute positioned -211 79 23 as @e[distance=..5,type=minecraft:villager,tag=comein] unless entity @a[tag=objective1] at @s run particle glow -213 79.1 23 1 1 1 0 0 force
team join Objective @e[type=shulker,tag=Objective]
execute positioned -213.0 78.0 23.0 as @a[dy=2] run tag @s add objective1
execute as @a[tag=objective1,limit=1] run function projectswords:objective

# options 1-x
execute as @a if score @s clickevent matches 1 unless score global clickevent matches 1.. run scoreboard players set librarian1 timer 903
execute as @a if score @s clickevent matches 2 unless score global clickevent matches 1.. run scoreboard players set librarian1 timer 911
execute as @a if score @s clickevent matches 3 unless score global clickevent matches 3.. run scoreboard players set librarian1 timer 903
execute as @a if score @s clickevent matches 4 unless score global clickevent matches 3.. run scoreboard players set librarian1 timer 903
execute as @a if score @s clickevent matches 3 unless score global clickevent matches 3.. run setblock -235 54 104 minecraft:redstone_block
execute as @a if score @s clickevent matches 4 unless score global clickevent matches 3.. run setblock -235 54 104 minecraft:redstone_block
execute as @a if score @s clickevent matches 5 unless score global clickevent matches 5.. run setblock -237 40 104 minecraft:redstone_block
execute as @a if score @s clickevent matches 6 run tag 112eb2d8-5d51-4122-804f-bc618a4cf1b8 add tradable

scoreboard players enable @a clickevent
scoreboard players operation global clickevent > @a clickevent

# librarian2
execute positioned -209.5 79.5 23.5 if entity @e[distance=..2,type=villager,tag=!tradable] if score librarian1 timer matches 909 as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 run tp @s -209.7 79.5 23.5
execute positioned -209.5 79.5 23.5 if entity @e[distance=..2,type=villager] unless score librarian1 timer matches 909 as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 run tp @s -238 43 109
execute positioned -209.5 79.5 23.5 if entity @e[distance=..2,type=villager,tag=tradable] as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 run tp @s -238 43 109
execute as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 if data entity @s interaction run tag @s add librarian_clicked

execute if score librarian1 timer matches 909 as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 at @s unless entity @s[tag=tradable] unless score global clickevent matches 5.. as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 on target run tellraw @s [{"text":"<"},{"selector":"112eb2d8-5d51-4122-804f-bc618a4cf1b8"},{"text":">"},{"text":" Hey, did you want to discuss something else?","color":"gray"}]
execute if score librarian1 timer matches 909 as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 at @s unless entity @s[tag=tradable] unless score global clickevent matches 5.. as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 on target run tellraw @s [{"text":"[About the attack...] ","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"hover_event":{"action":"show_text","value":[{"text":"[How were the enemies able to find our village?] ","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]},"click_event":{"action":"run_command","command":"/trigger clickevent set 5"}},{"text":" [I would like to trade!]","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"hover_event":{"action":"show_text","value":[{"text":"[Enter trade menu]","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]},"click_event":{"action":"run_command","command":"/trigger clickevent set 6"}}]

execute if score librarian1 timer matches 909 as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 at @s unless entity @s[tag=tradable] if score global clickevent matches 5.. as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 on target run tellraw @s [{"text":"<"},{"selector":"112eb2d8-5d51-4122-804f-bc618a4cf1b8"},{"text":">"},{"text":" Hello, would you be interested in a trade?","color":"gray"}]
execute if score librarian1 timer matches 909 as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 at @s unless entity @s[tag=tradable] if score global clickevent matches 5.. as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 on target run tellraw @s [{"text":"[About the attack...] ","color":"dark_gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"click_event":{"action":"run_command","command":"/trigger clickevent set 5"}},{"text":" [I would like to trade!]","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false,"hover_event":{"action":"show_text","value":[{"text":"[Enter trade menu]","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]},"click_event":{"action":"run_command","command":"/trigger clickevent set 6"}}]

execute as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 if data entity @s interaction run tag @s remove librarian_clicked
execute as 2b729f4d-1d01-4ec3-afe4-1e5bf43c6e02 if data entity @s interaction run data remove entity @s interaction

execute if score librarian1 timer matches ..908 run tag 112eb2d8-5d51-4122-804f-bc618a4cf1b8 remove tradable
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 if entity @s[tag=tradable] run data merge entity @s {Offers:{Recipes:[{rewardExp:0b,maxUses:9999,buy:{id:"minecraft:paper",count:12},sell:{id:"minecraft:gold_ingot",count:1}},{rewardExp:0b,maxUses:9999,buy:{id:"minecraft:leather",count:8},sell:{id:"minecraft:gold_ingot",count:1}},{rewardExp:0b,maxUses:9999,buy:{id:"minecraft:ink_sac",count:4},sell:{id:"minecraft:gold_ingot",count:1}},{rewardExp:0b,maxUses:9999,buy:{id:"minecraft:book",count:32},sell:{id:"minecraft:gold_ingot",count:2}},{rewardExp:0b,maxUses:9999,buy:{id:"minecraft:writable_book",count:1},sell:{id:"minecraft:gold_ingot",count:1}}]}}
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 unless entity @s[tag=tradable] run data merge entity @s {Offers:{Recipes:[]}}
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 at @s if score librarian1 timer matches 909 unless entity @e[type=text_display,distance=..5] run summon text_display ~ ~2 ~ {view_range:1f,billboard:"center",Tags:["hint","talk"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]},text:{"bold":false,"color":"yellow","italic":false,"obfuscated":false,"strikethrough":false,"text":"[Click the Villager to Talk]","underlined":false}}
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 at @s if entity @s[tag=tradable] run kill @e[type=text_display,tag=talk,distance=..5]
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 at @s if score librarian1 timer matches 909 unless entity @e[type=text_display,distance=..5] if entity @s[tag=tradable] run summon text_display ~ ~2 ~ {view_range:1f,billboard:"center",Tags:["hint","trade"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[1f,1f,1f]},text:[{"bold":false,"color":"yellow","italic":false,"obfuscated":false,"strikethrough":false,"text":"[Click the Villager to ","underlined":false},{"bold":false,"italic":false,"obfuscated":false,"strikethrough":false,"text":"Trade","underlined":true},{"bold":false,"italic":false,"obfuscated":false,"strikethrough":false,"text":"]","underlined":false}]}

execute if score librarian1 timer matches 909 run fill -219 81 28 -217 79 28 air

# librarian3
execute positioned -213 79 23 if entity @p[team=!Spectator,distance=..2,tag=leathertier,tag=!chainmailtier,tag=!leather_reward] as @a run function projectswords:rewards/leather
execute positioned -213 79 23 if entity @p[team=!Spectator,distance=..2,tag=chainmailtier,tag=!irontier,tag=!chainmail_reward] as @a run function projectswords:rewards/chainmail
execute positioned -218 80 26 as @a[team=!Spectator,distance=..2,tag=chainmail_reward,tag=!iron_reward,tag=!tnt1.reward] run function projectswords:rewards/tnt1
execute positioned -213 79 23 if entity @p[team=!Spectator,distance=..2,tag=irontier,tag=!diamondtier,tag=!iron_reward] as @a run function projectswords:rewards/iron
execute positioned -213 79 23 if entity @p[team=!Spectator,distance=..2,tag=diamondtier,tag=!diamondbtier,tag=!diamond_reward] as @a run function projectswords:rewards/diamond

# synctiers #
execute if entity @a[tag=diamondbtier] run tag @a add diamondbtier
execute if entity @a[tag=diamondtier] run tag @a add diamondtier
execute if entity @a[tag=irontier] run tag @a add irontier
execute if entity @a[tag=chainmailtier] run tag @a add chainmailtier
execute if entity @a[tag=leathertier] run tag @a add leathertier
execute if entity @a[tag=tnt1.reward] run tag @a add tnt1.reward

# tnt
execute positioned -222 73 64 as @a[distance=..6,nbt={SelectedItem:{id:"minecraft:tnt"}}] run function projectswords:tnt
execute positioned -228 75 93 as @a[distance=..6,nbt={SelectedItem:{id:"minecraft:tnt"}}] run function projectswords:tnt
#FISHING ROD PREVENTION
execute positioned -226 74 92 as @e[type=tnt,distance=..0.6] at @s run tp @s -226 74 92
execute positioned -221 73 62 as @e[type=tnt,distance=..0.6] at @s run tp @s -221 73 62
execute positioned -227 74 91 as @e[type=tnt,distance=..0.6] at @s run tp @s -227 74 91
execute positioned -222 73 61 as @e[type=tnt,distance=..0.6] at @s run tp @s -222 73 61
execute positioned -227 75 93 as @e[type=tnt,distance=..0.6] at @s run tp @s -227 75 93
execute positioned -222 74 64 as @e[type=tnt,distance=..0.6] at @s run tp @s -222 74 64
execute positioned -228 75 94 as @e[type=tnt,distance=..0.6] at @s run tp @s -228 75 94
# despawn
execute positioned -222 73 64 unless entity @a[distance=..6,nbt={SelectedItem:{id:"minecraft:tnt"}}] as @e[distance=..4,type=shulker,team=Villager] run function projectswords:shulker_despawn
execute positioned -228 75 93 unless entity @a[distance=..6,nbt={SelectedItem:{id:"minecraft:tnt"}}] as @e[distance=..4,type=shulker,team=Villager] run function projectswords:shulker_despawn
execute positioned -228 75 93 if entity @a[distance=..6,tag=swordsmith_open] as @e[distance=..4,type=shulker,team=Villager] run function projectswords:shulker_despawn
execute positioned -228 75 93 if entity @a[distance=..6,tag=armorer_open] as @e[distance=..4,type=shulker,team=Villager] run function projectswords:shulker_despawn

# Amethyst #
execute positioned -190 60 240 if entity @a[distance=..50] run function projectswords:interaction/amethyst

# Charms #
execute as @a if data entity @s SelectedItem{id:"minecraft:goat_horn"} run function projectswords:charms/enable
execute as @a if data entity @s {equipment:{offhand:{id:"minecraft:goat_horn"}}} run function projectswords:charms/enable

# Deepslate #
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=item,nbt={Item:{id:"minecraft:deepslate"}}] run data merge entity @s {Item:{id:"minecraft:deepslate",count:1,components:{"minecraft:enchantments":{"minecraft:protection":1},"minecraft:tooltip_display":{hidden_components:["enchantments","enchantments"]},"minecraft:custom_name":{"bold":true,"color":"#543869","italic":false,"obfuscated":false,"strikethrough":false,"text":"Endslate","underlined":false}}}}

# Fast Travel #
scoreboard players enable @a clickevent.compass
execute as @a[tag=!night,nbt={SelectedItem:{id:"minecraft:compass",count:1,components:{"minecraft:custom_data":{NoPickup:1b}}}}] at @s run function projectswords:anchor/held
execute as @a[tag=!night,nbt=!{SelectedItem:{id:"minecraft:compass",count:1,components:{"minecraft:custom_data":{NoPickup:1b}}}}] run function projectswords:anchor/fail
execute as @a[tag=night,scores={clickevent.compass=1..4},tag=!anchor.night] run function projectswords:anchor/night

# Ice Room #
execute positioned -278 69 108 as @a[distance=..3] run tag @s remove in.iceroom
execute positioned -283 71 108 as @a[distance=..3] run tag @s add in.iceroom
execute as @a[tag=in.iceroom] run function projectswords:iceroom/puzzle

execute positioned -335 54 86 as @a[tag=!rabbit.unlocked] run function projectswords:rabbit_locked
execute positioned -335 54 86 as @e[distance=..10,type=interaction,tag=rabbit.unlock] on target if entity @s[tag=!rabbit.unlocked,nbt={SelectedItem:{id:"minecraft:golden_carrot",components:{"minecraft:custom_name":{"color":"gold","italic":false,"text":"The Legendary Carrot"}}}}] run function projectswords:iceroom/rabbit
execute positioned -269 69 102 as @e[distance=..10,type=interaction,tag=rabbit.unlock] run function projectswords:rabbit_effect

execute positioned -269 69 102 as @e[distance=..10,type=text_display] run data merge entity @s {text:[{"bold":true,"color":"gold","italic":false,"obfuscated":false,"strikethrough":false,"text":"Nugget Count: ","underlined":false},{"bold":false,"color":"yellow","italic":false,"obfuscated":false,"score":{"name":"5f9682e6-6f83-4a83-a6b4-a0b361943222","objective":"rabbit"},"strikethrough":false,"underlined":false}]}
execute positioned -269 69 102 as @e[distance=..10,type=interaction,tag=rabbit.unlock] run data remove entity @s interaction

# Slime Room #
execute positioned -222 51 175 as @a[distance=..1] run tag @s add in.slimeroom
execute positioned -222 54 175 as @a[distance=..1] run tag @s remove in.slimeroom
execute as @a[tag=in.slimeroom] run function projectswords:slimeroom
execute as @a[tag=!in.slimeroom] run function projectswords:slimeroom_reset

execute as @e[type=parrot,tag=Origami] at @s run function projectswords:origami

# Magma Room #
execute positioned -191 65 243 if entity @a[distance=..20] run particle ash ~ ~ ~ 2 4 3 1 20 normal
execute positioned -184 58 209 as @a[distance=..20] at @e[type=marker,distance=..50,tag=Waterfall] run particle cloud ~ ~ ~ 0.5 0.5 0.5 0 30 normal

# Tetsuo #
execute positioned -225 72 63 as @a[distance=..1,tag=!tetsuo.unlocked] run tellraw @a[distance=..10] [{"text":"<"},{"selector":"26d6176b-0201-4c9e-a80b-d46300ae7d9a"},{"text":"> "},{"selector":"@s"},{"text":"... Of course it is you to rescue me. You really take after your father. Many thanks, young master.","color":"gray"}]
execute positioned -225 72 63 as @a[distance=..1] run tag @a add tetsuo.unlocked

# Trident #
execute positioned -221 57 154 run data merge entity @e[type=minecraft:trident,tag=Trident,distance=..3,limit=1] {Rotation:[90F,-90F],Motion:[0d,0d,0d],NoGravity:1b,life:99s,pickup:0b}
execute positioned -221 57 154 if entity @a[distance=..10] as @e[distance=..3,type=interaction,tag=Trident] run function projectswords:trident

# Bubbles #
execute positioned -221 71 167 as @a[tag=trident.unlocked,tag=!axolotl.unlocked] if entity @e[type=trident,x=-221.8,y=70.5,z=168,dy=1,dx=1.7,dz=-2] run function projectswords:axolotl
execute positioned -216 72 90 as @e[distance=..300,tag=!Bubbles,type=minecraft:axolotl] run data merge entity @s {PersistenceRequired:1b,Variant:4,Tags:["Bubbles"]}

execute positioned -216 72 90 as @e[distance=..300,type=axolotl,tag=Bubbles] at @s as @a[distance=..3,tag=axolotl.unlocked,tag=!axolotl.buffed] run function projectswords:axolotl_buff
execute as @a[tag=axolotl.buffed] unless entity @s[nbt={active_effects:[{id:"minecraft:strength",amplifier:1b}]}] run tag @s remove axolotl.buffed

execute as @a[nbt={SelectedItem:{id:"minecraft:axolotl_bucket",count:1}}] run item replace entity @s weapon.mainhand with axolotl_bucket[custom_name=[{"bold":false,"italic":false,"text":"Bucket of "},{"bold":true,"color":"blue","italic":false,"text":"Bubbles"}],lore=[[{"bold":false,"color":"gray","italic":false,"text":"Place on Prismarine to deploy "},{"bold":true,"color":"blue","italic":false,"text":"Bubbles"}]]] 1

# Recipes #
execute as @a[tag=!recipe.gold,nbt={Inventory:[{id:"minecraft:gold_nugget"}]}] run function projectswords:gold

# Ending #
execute as @a[tag=ending,tag=!final.room] run function projectswords:ending
execute as @a[tag=final.room] run scoreboard players reset countdown final
execute as @a[tag=final.room] run clear @a[tag=!dev]
execute positioned -201.00 58.44 267.82 as @p[tag=final.room,distance=..2] run function projectswords:final

# Resets #
scoreboard players enable @a reset
tag @a[scores={reset=1..}] add reset
scoreboard players set @a[scores={reset=1..}] reset 0

execute as @a[tag=reset] run function projectswords:reset
execute as @a[tag=reset] run scoreboard players set @s reset.wasHere 1
execute as @a[tag=reset] run tag @s remove reset