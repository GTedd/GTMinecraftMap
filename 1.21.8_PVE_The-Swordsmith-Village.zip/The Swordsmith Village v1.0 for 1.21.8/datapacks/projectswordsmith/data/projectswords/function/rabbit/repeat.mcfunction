schedule function projectswords:rabbit/repeat 10s

execute positioned -269 69 102 as @e[distance=..10,type=interaction,tag=rabbit.unlock] run scoreboard players add @s rabbit 1
