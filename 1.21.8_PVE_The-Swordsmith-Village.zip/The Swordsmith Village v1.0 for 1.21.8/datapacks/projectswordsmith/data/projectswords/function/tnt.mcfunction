execute positioned -222 73 64 as @e[type=shulker,distance=..1] run effect give @s invisibility infinite 1 true
execute positioned -222 73 62 as @e[type=shulker,distance=..1] run effect give @s invisibility infinite 1 true
execute positioned -228 75 93 as @e[type=shulker,distance=..1] run effect give @s invisibility infinite 1 true
execute positioned -227 74 92 as @e[type=shulker,distance=..1] run effect give @s invisibility infinite 1 true
execute positioned -222 73 64 if block ~ ~ ~ minecraft:cracked_stone_bricks unless entity @e[type=shulker,distance=..0] if entity @a[distance=..6,nbt={SelectedItem:{id:"minecraft:tnt"}}] run summon minecraft:shulker -224 73 64 {Glowing:0b,NoAI:1b,Invulnerable:1b,Team:"Villager",Silent:1b,Tags:["shulker1"]}
execute positioned -222 73 62 if block ~ ~ ~ minecraft:cracked_stone_bricks unless entity @e[type=shulker,distance=..0] if entity @a[distance=..6,nbt={SelectedItem:{id:"minecraft:tnt"}}] run summon minecraft:shulker -224 73 62 {Glowing:0b,NoAI:1b,Invulnerable:1b,Team:"Villager",Silent:1b,Tags:["shulker2"]}
execute positioned -228 75 93 if block ~ ~ ~ minecraft:cracked_stone_bricks unless entity @e[type=shulker,distance=..0] if entity @a[distance=..6,nbt={SelectedItem:{id:"minecraft:tnt"}}] run summon minecraft:shulker -229 75 93 {Glowing:0b,NoAI:1b,Invulnerable:1b,Team:"Villager",Silent:1b,Tags:["shulker3"]}
execute positioned -227 74 92 if block ~ ~ ~ minecraft:cracked_stone_bricks unless entity @e[type=shulker,distance=..0] if entity @a[distance=..6,nbt={SelectedItem:{id:"minecraft:tnt"}}] run summon minecraft:shulker -229 74 92 {Glowing:0b,NoAI:1b,Invulnerable:1b,Team:"Villager",Silent:1b,Tags:["shulker4"]}
execute positioned -224 73 62 run tp @e[distance=..10,type=shulker,tag=shulker1] -222 73 64
execute positioned -224 73 62 run tp @e[distance=..10,type=shulker,tag=shulker2] -222 73 62
execute positioned -229 75 93 run tp @e[distance=..10,type=shulker,tag=shulker3] -228 75 93
execute positioned -229 75 93 run tp @e[distance=..10,type=shulker,tag=shulker4] -227 74 92
execute positioned -222 73 64 as @e[type=shulker,distance=..1] run data merge entity @s {Glowing:1b}
execute positioned -222 73 62 as @e[type=shulker,distance=..1] run data merge entity @s {Glowing:1b}
execute positioned -228 75 93 as @e[type=shulker,distance=..1] run data merge entity @s {Glowing:1b}
execute positioned -227 74 92 as @e[type=shulker,distance=..1] run data merge entity @s {Glowing:1b}
