# hotbar 0–8
execute if data entity @s Inventory[{Slot:0b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.0 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:1b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.1 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:2b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.2 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:3b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.3 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:4b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.4 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:5b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.5 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:6b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.6 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:7b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.7 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:8b,id:"minecraft:bone_meal"}] run item modify entity @s hotbar.8 projectswords:farm/bone_meal

#inventory 0-26
execute if data entity @s Inventory[{Slot:9b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.0 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:10b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.1 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:11b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.2 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:12b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.3 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:13b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.4 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:14b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.5 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:15b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.6 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:16b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.7 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:17b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.8 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:18b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.9 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:19b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.10 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:20b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.11 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:21b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.12 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:22b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.13 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:23b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.14 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:24b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.15 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:25b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.16 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:26b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.17 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:27b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.18 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:28b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.19 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:29b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.20 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:30b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.21 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:31b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.22 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:32b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.23 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:33b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.24 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:34b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.25 projectswords:farm/bone_meal
execute if data entity @s Inventory[{Slot:35b,id:"minecraft:bone_meal"}] run item modify entity @s inventory.26 projectswords:farm/bone_meal

# offhand (NBT slot 40b)
execute if data entity @s equipment{offhand:{id:"minecraft:bone_meal"}} run item modify entity @s weapon.offhand projectswords:farm/bone_meal

advancement revoke @s only projectswords:bonemeal_pickup