scoreboard players reset objective1 timer
effect clear 703a7907-2f36-415e-823e-256c9d9a9324 minecraft:glowing
scoreboard players add librarian1 timer 1
execute if score librarian1 timer matches 1 run setblock -235 40 104 minecraft:redstone_block
execute if score librarian1 timer matches 151 run setblock -235 42 104 minecraft:redstone_block
execute if score librarian1 timer matches 301 run setblock -235 44 104 minecraft:redstone_block
execute if score librarian1 timer matches 451 run setblock -235 46 104 minecraft:redstone_block
execute if score librarian1 timer matches 651 run setblock -235 48 104 minecraft:redstone_block
execute if score librarian1 timer matches 851 run setblock -235 50 104 minecraft:redstone_block
execute if score librarian1 timer matches 901..902 run scoreboard players set librarian1 timer 901
execute if score librarian1 timer matches 904 run setblock -235 54 104 minecraft:redstone_block
execute if score librarian1 timer matches 909..910 run scoreboard players set librarian1 timer 909
execute if score librarian1 timer matches 912 run setblock -235 52 104 minecraft:redstone_block
execute if score librarian1 timer matches 962 run setblock -235 56 104 minecraft:redstone_block