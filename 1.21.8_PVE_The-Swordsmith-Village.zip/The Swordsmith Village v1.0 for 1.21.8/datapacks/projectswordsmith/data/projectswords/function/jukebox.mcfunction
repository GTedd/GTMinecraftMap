setblock -180 67 84 minecraft:jukebox[has_record=true]
clear @s minecraft:music_disc_5