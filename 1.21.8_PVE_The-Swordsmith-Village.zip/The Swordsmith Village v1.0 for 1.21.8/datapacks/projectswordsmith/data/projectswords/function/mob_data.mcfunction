#Angry Bees
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=bee] run function projectswords:angry_bees
#AngryAt
execute as @e[distance=..200,type=#projectswords:angry] at @s run data modify entity @s AngryAt set from entity @p[team=!Spectator] UUID
#Honey
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=minecraft:area_effect_cloud,tag=HoneyDecay] at @s as @a[distance=..3] run effect give @s minecraft:slowness 5 2 false
#TPs
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=bee,predicate=projectswords:toohigh] run tp @s ~ ~-6 ~
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=spider,predicate=projectswords:spiderhigh] run tp @s ~ ~-6 ~
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=!spider,tag=Mob,predicate=projectswords:toohigh] run tp @s -180 67 70
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=enderman,predicate=projectswords:enderlow] run tp @s -171 68 63
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=stray,predicate=projectswords:straylow] run tp @s -171 68 63