setblock -219 63 68 minecraft:redstone_block
tag @a remove day
tag @a add night
scoreboard players set dummy nighttimer 10000
tag @s remove nightbar
tag @s remove leathertier
setblock -238 40 93 air
execute if entity @s[tag=outofhouse] positioned -191.99 79.90 114.00 unless entity @e[tag=Mob,tag=day0,distance=..300] run tag @s add day1
execute if entity @s[tag=outofhouse] positioned -191.99 79.90 114.00 unless entity @e[tag=Mob,tag=day0,distance=..300] run tag @s remove day0
