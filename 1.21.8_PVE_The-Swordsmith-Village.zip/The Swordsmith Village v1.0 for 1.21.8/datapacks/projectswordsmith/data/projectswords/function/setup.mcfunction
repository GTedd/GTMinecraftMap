scoreboard objectives remove health
scoreboard objectives add health dummy
scoreboard objectives setdisplay sidebar health
scoreboard objectives modify health displayname [{"bold":true,"text":"Alive Mobs ","color":"dark_red"},{"text":" / ","color":"black"},{"text":" HP","color":"red"}]
scoreboard objectives modify health displayautoupdate true
tag @s remove setup