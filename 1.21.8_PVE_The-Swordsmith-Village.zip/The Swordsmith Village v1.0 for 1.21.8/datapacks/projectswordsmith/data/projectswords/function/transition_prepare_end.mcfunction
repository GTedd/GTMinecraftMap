tag @s remove day
tag @s remove daybar
bossbar set minecraft:daytimer players
scoreboard players reset dummy daytimer
scoreboard players reset prepare transition
bossbar set minecraft:prepare players
tag @s add preboss