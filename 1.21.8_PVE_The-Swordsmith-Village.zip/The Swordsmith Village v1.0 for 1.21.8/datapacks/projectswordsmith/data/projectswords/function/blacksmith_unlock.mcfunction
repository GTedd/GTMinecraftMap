execute positioned -222 73 63 run kill @e[type=tnt,distance=..4]
particle minecraft:explosion -222 73 63 1 1 1 1 1 force
particle minecraft:explosion_emitter -222 73 63 1.5 1 1.5 1 1 force
particle minecraft:explosion_emitter -222 73 63 1 1.5 1 1 1 force
playsound minecraft:entity.generic.explode block @a -222 73 63 10 1
fill -221 72 61 -222 75 65 air
fill -225 78 64 -225 77 62 air
