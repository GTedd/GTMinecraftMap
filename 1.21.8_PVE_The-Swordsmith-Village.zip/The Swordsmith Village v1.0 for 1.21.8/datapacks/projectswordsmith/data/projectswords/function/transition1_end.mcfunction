tag @s remove night
setblock -236 44 91 minecraft:redstone_block
bossbar set minecraft:daynight players
scoreboard players reset day0 transition
tag @s add transition1