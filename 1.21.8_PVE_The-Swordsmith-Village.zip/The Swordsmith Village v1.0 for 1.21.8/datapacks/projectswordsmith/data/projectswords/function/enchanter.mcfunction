execute positioned -276 88 152 run particle minecraft:enchant ~ ~ ~ 0.8 0.2 0.8 1 5 normal
execute at @s run tp @s ~ ~ ~ ~15 ~
execute at @s positioned ~ ~-0.6 ~ run particle minecraft:end_rod ^2.25 ^ ^ 0.1 0.1 0.1 0 1 normal
execute at @s positioned ~ ~-0.6 ~ run particle minecraft:end_rod ^2 ^ ^ 0.1 0.1 0.1 0 1 normal
execute at @s positioned ~ ~-0.6 ~ run particle minecraft:end_rod ^1.75 ^ ^ 0.1 0.1 0.1 0 1 normal
execute at @s positioned ~ ~-0.6 ~ run particle minecraft:end_rod ^1.5 ^ ^ 0.1 0.1 0.1 0 1 normal
execute at @s positioned ~ ~-0.6 ~ run particle minecraft:end_rod ^1.25 ^ ^ 0.1 0.1 0.1 0 1 normal
execute at @s positioned ~ ~-0.6 ~ run particle minecraft:end_rod ^1 ^ ^ 0.1 0.1 0.1 0 1 normal
execute at @s positioned ~ ~-0.6 ~ run particle minecraft:end_rod ^0.75 ^ ^ 0.1 0.1 0.1 0 1 normal
