execute on target if entity @s[tag=rabbit.unlocked,nbt={SelectedItem:{id:"minecraft:golden_carrot",components:{"minecraft:custom_name":{"color":"gold","italic":false,"text":"The Legendary Carrot"}}}}] run tellraw @a[distance=..10] [{"text":"<Peppy>","color":"#FF474C"},{"text":" *happy squeak* (yum!)","color":"white"}]
execute on target if entity @s[tag=rabbit.unlocked,nbt={SelectedItem:{id:"minecraft:golden_carrot",components:{"minecraft:custom_name":{"color":"gold","italic":false,"text":"The Legendary Carrot"}}}}] as @a[distance=..10] at @s run playsound minecraft:entity.dolphin.play master @s ~ ~ ~ 0.8 0.6
execute on target if entity @s[tag=rabbit.unlocked,nbt={SelectedItem:{id:"minecraft:golden_carrot",components:{"minecraft:custom_name":{"color":"gold","italic":false,"text":"The Legendary Carrot"}}}}] run clear @s golden_carrot[custom_name={"color":"gold","italic":false,"text":"The Legendary Carrot"}] 1

tellraw @a[distance=..5,tag=!repeat.started] [{"text":"<Peppy>","color":"#FF474C"},{"text":" *squeak* *squeak!* (heyo! me gib u GOLD nuggit! plz come by often!!)","color":"white"}]
execute if entity @a[distance=..5,tag=rabbit.unlocked,tag=!repeat.started] run function projectswords:rabbit/repeat
execute if entity @a[distance=..5,tag=rabbit.unlocked,tag=!repeat.started] positioned 0 0 0 as @e[type=minecraft:text_display,limit=1,distance=..2] positioned -269 69 102 at @e[distance=..10,type=interaction,tag=rabbit.unlock] run tp @s ~ ~1.02 ~
execute as @a[distance=..5,tag=rabbit.unlocked,tag=!repeat.started] run tag @s add repeat.started
execute if score @s rabbit matches ..9 unless score @s rabbit matches ..0 on target run give @s gold_nugget 1
execute if score @s rabbit matches ..9 unless score @s rabbit matches ..0 on target run playsound minecraft:item.armor.equip_gold master @a ~ ~ ~ 1 2
execute if score @s rabbit matches ..9 unless score @s rabbit matches ..0 on target run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 1 2
execute if score @s rabbit matches ..9 unless score @s rabbit matches ..0 on target run scoreboard players remove @e[distance=..10,type=interaction,tag=rabbit.unlock] rabbit 1
execute if score @s rabbit matches 10.. on target run give @s gold_nugget 10
execute if score @s rabbit matches 10.. on target run playsound minecraft:item.armor.equip_gold master @a ~ ~ ~ 2 2
execute if score @s rabbit matches 10.. on target run playsound minecraft:entity.experience_orb.pickup master @a ~ ~ ~ 2 2
execute if score @s rabbit matches 10.. on target run scoreboard players remove @e[distance=..10,type=interaction,tag=rabbit.unlock] rabbit 10