setblock -229 44 116 air
setblock -227 41 116 redstone_block
setblock -231 41 116 redstone_block
title @a title [{"text":"🔥 ","color":"yellow","bold":false},{"text":"ERUPTION","color":"gold","bold":true,"underlined":true},{"text":" 🔥","color":"yellow","bold":false}]
title @a subtitle [{"text":"All Mobs Within ","color":"gold","bold":true,"underlined":true},{"text":"20 ","color":"yellow","bold":true,"underlined":true},{"text":"Blocks Are Lit On Fire","color":"gold","bold":true,"underlined":true}]
setblock -228 41 116 redstone_block