# StoneRangers #
execute positioned -204 33 -11 as @e[distance=..100,type=silverfish,tag=StoneMinion] at @s run function projectswords:stone_minion
execute if score fangs timer20s matches 40.. run scoreboard players set fangs timer20s 0
#execute if score fangs timer20s matches 1 run kill @e[distance=..5,type=minecraft:evoker_fangs]
# Minions #
#summon x3-10: /summon minecraft:block_display ~ ~ ~ {Tags:["StoneMinion","Minion","Mob","StoneMinion1"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[0.5f,0.5f,0.5f]},block_state:{Name:"minecraft:stone"}}
#summon x3-10: /summon silverfish ~ ~1 ~ {Silent:1b,Invulnerable:0b,PersistenceRequired:1b,Health:40f,Tags:["NoGlow","Mob","StoneMinion","Minion","StoneMinion1"],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:19999980,show_particles:0b}],Attributes:[{Name:generic.max_health,Base:40},{Name:generic.movement_speed,Base:0.25},{Name:generic.attack_damage,Base:4}]}
execute positioned -204 33 -11 as @e[distance=..100,type=minecraft:block_display,tag=Minion] at @s unless entity @e[type=silverfish,tag=NoGlow,distance=..2] run kill @s
#summon x3-inf: /summon zombie ~ ~ ~ {Health:20b,Glowing:1b,CustomNameVisible:1b,IsBaby:1b,Tags:["Mob","Minion"],CustomName:'[{"text":"[Golem] ","color":"gray","bold":true},{"text":"Stone Minion","color":"dark_gray"}]',HandItems:[{id:"minecraft:iron_pickaxe",count:1},{}],HandDropChances:[0.000F,0.085F],ArmorItems:[{id:"minecraft:leather_boots",count:1,tag:{display:{color:7500402}}},{id:"minecraft:leather_leggings",count:1,tag:{display:{color:7500402}}},{id:"minecraft:leather_chestplate",count:1,tag:{display:{color:8553090}}},{id:"minecraft:stone",count:1}],ArmorDropChances:[0.000F,0.000F,0.000F,0.000F],ActiveEffects:[{Id:14,Amplifier:1b,Duration:199980,ShowParticles:0b}],Attributes:[{Name:generic.max_health,Base:20},{Name:generic.movement_speed,Base:0.3},{Name:generic.attack_damage,Base:8}]}
#summon x2-inf: /summon zombie ~ ~1 ~ {Tags:["Mob","Minion","NoGlow"],Attributes:[{Name:generic.attack_damage,Base:10}],IsBaby:1b,ArmorItems:[{},{},{},{id:"minecraft:cobblestone",count:1}],ArmorDropChances:[0.000F,0.000F,0.000F,0.000F],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:19999980,show_particles:0b}],PersistenceRequired:1b,Silent:1b,Passengers:[{id:"minecraft:area_effect_cloud",Particle:"block stone",ReapplicationDelay:150,Radius:2f,Duration:99999,Color:8421237,Tags:["StoneDecay"]}]}
execute positioned -204 33 -11 as @e[distance=..100,type=minecraft:area_effect_cloud,tag=StoneDecay] at @s as @a[distance=..3] run effect give @s minecraft:weakness 8 0 false
execute positioned -204 33 -11 as @e[distance=..100,type=minecraft:area_effect_cloud,tag=StoneDecay] at @s unless entity @e[type=zombie,tag=NoGlow,distance=..2] run kill @s

execute positioned -213 15 0 run tp @e[tag=spikerandom,type=minecraft:marker,limit=1,sort=random,distance=..2] -215 15 2
execute positioned -215 15 2 run tp @e[tag=spikerandom,type=minecraft:marker,limit=1,sort=random,distance=..2] -213 15 0
execute if entity @s[tag=!res_cleared] run effect clear @s minecraft:resistance
execute if entity @s[tag=!res_cleared] run effect clear @s minecraft:glowing
execute if entity @s[tag=!res_cleared] run tag @s add res_cleared
effect give @s minecraft:resistance infinite 2 true
setblock -220 18 101 redstone_block
execute unless block -219 19 103 minecraft:dropper run setblock -219 19 103 minecraft:dropper[facing=west]
execute if entity @s[tag=SpawnMinion] store result score #randomboss randomregen run random value 1..3
execute if entity @s[tag=SpawnMinion] if score #randomboss randomregen matches 1 run setblock -214 18 -11 minecraft:redstone_block
execute if entity @s[tag=SpawnMinion] if score #randomboss randomregen matches 2 run setblock -214 18 -9 minecraft:redstone_block
execute if entity @s[tag=SpawnMinion] if score #randomboss randomregen matches 3 run setblock -214 18 -7 minecraft:redstone_block
execute if entity @s[tag=SpawnMinion] run tag @s remove SpawnMinion
execute if score dummy BossTimer matches 10..30 run playsound minecraft:block.sculk.spread master @a ~ ~ ~ 2 0.1
execute if score dummy spawntimer matches 10..30 run playsound minecraft:block.stone.break master @a ~ ~ ~ 1 0.1
execute if score dummy BossTimer matches 100..130 run playsound minecraft:block.sculk.spread master @a ~ ~ ~ 2 0.1
execute if score dummy spawntimer matches 100..130 run playsound minecraft:block.stone.break master @a ~ ~ ~ 1 0.1
execute if score dummy BossTimer matches 180..200 run playsound minecraft:block.sculk.spread master @a ~ ~ ~ 2 0.1
execute if score dummy spawntimer matches 180..200 run playsound minecraft:block.stone.break master @a ~ ~ ~ 1 0.1
 