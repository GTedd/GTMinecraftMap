execute positioned -166 69 161 if block ~ ~ ~ minecraft:spruce_door[open=true] if score dummy nighttimer matches 1..9998 run function projectswords:lockdoors_west_left
execute positioned -166 69 160 if block ~ ~ ~ minecraft:spruce_door[open=true] if score dummy nighttimer matches 1..9998 run function projectswords:lockdoors_west_right
execute positioned -243 67 132 if block ~ ~ ~ minecraft:spruce_door[open=true] if score dummy nighttimer matches 1..9998 run function projectswords:lockdoors_west_left
execute positioned -243 67 131 if block ~ ~ ~ minecraft:spruce_door[open=true] if score dummy nighttimer matches 1..9998 run function projectswords:lockdoors_west_right
execute positioned -243 71 110 if block ~ ~ ~ minecraft:spruce_door[open=true] if score dummy nighttimer matches 1..9998 run function projectswords:lockdoors_south_left
execute positioned -243 69 110 if score dummy nighttimer matches 1..9999 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~ ~1 ~-2
execute positioned -244 65 132 if score dummy nighttimer matches 1..9999 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~2 ~1 ~
execute positioned -244 65 131 if score dummy nighttimer matches 1..9999 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~2 ~1 ~
execute positioned -167 67 161 if score dummy nighttimer matches 1..9999 as @a[dy=3,dx=0.4,dz=0.4] run tp @s ~2 ~1 ~
execute positioned -167 67 160 if score dummy nighttimer matches 1..9999 as @a[dy=3,dx=0.4,dz=0.4] run tp @s ~2 ~1 ~