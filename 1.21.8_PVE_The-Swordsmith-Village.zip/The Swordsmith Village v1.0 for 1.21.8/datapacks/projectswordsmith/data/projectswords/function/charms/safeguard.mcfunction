effect clear @s poison
effect clear @s wither
effect clear @s weakness
effect clear @s blindness