execute if entity @s[nbt={SelectedItem:{id:"minecraft:goat_horn",count:1,components:{"minecraft:instrument":"minecraft:call_goat_horn"}}}] run function projectswords:charms/summoning
execute if entity @s[nbt={SelectedItem:{id:"minecraft:goat_horn",count:1,components:{"minecraft:instrument":"minecraft:admire_goat_horn"}}}] run function projectswords:charms/endurance
execute if entity @s[nbt={SelectedItem:{id:"minecraft:goat_horn",count:1,components:{"minecraft:instrument":"minecraft:feel_goat_horn"}}}] run function projectswords:charms/healing
execute if entity @s[nbt={SelectedItem:{id:"minecraft:goat_horn",count:1,components:{"minecraft:instrument":"minecraft:seek_goat_horn"}}}] run function projectswords:charms/power
execute if entity @s[nbt={SelectedItem:{id:"minecraft:goat_horn",count:1,components:{"minecraft:instrument":"minecraft:ponder_goat_horn"}}}] run function projectswords:charms/revealing

execute if entity @s[nbt={equipment:{offhand:{id:"minecraft:goat_horn",components:{"minecraft:instrument":"minecraft:call_goat_horn"}}}}] run function projectswords:charms/summoning
execute if entity @s[nbt={equipment:{offhand:{id:"minecraft:goat_horn",components:{"minecraft:instrument":"minecraft:admire_goat_horn"}}}}] run function projectswords:charms/endurance
execute if entity @s[nbt={equipment:{offhand:{id:"minecraft:goat_horn",components:{"minecraft:instrument":"minecraft:feel_goat_horn"}}}}] run function projectswords:charms/healing
execute if entity @s[nbt={equipment:{offhand:{id:"minecraft:goat_horn",components:{"minecraft:instrument":"minecraft:seek_goat_horn"}}}}] run function projectswords:charms/power
execute if entity @s[nbt={equipment:{offhand:{id:"minecraft:goat_horn",components:{"minecraft:instrument":"minecraft:ponder_goat_horn"}}}}] run function projectswords:charms/revealing