execute at @s if score @s cooldown matches 1 run effect give @s minecraft:strength 8 0
execute at @s if score @s cooldown matches 1.. run scoreboard players remove @s cooldown 1