tp @s ~ ~ ~ ~50 ~
particle minecraft:sculk_charge_pop ^ ^-0.4 ^1
summon snowball ^ ^-0.5 ^0.3 {Item:{id:"minecraft:creeper_head",count:1b}}
execute unless entity @e[type=creeper,distance=..2] run kill @s