execute if block -237 18 151 minecraft:lever[powered=true] run tag @a add lever.1
execute if block -237 18 150 minecraft:lever[powered=false] run tag @a add lever.2
execute if block -237 18 149 minecraft:lever[powered=false] run tag @a add lever.3
execute if block -237 18 148 minecraft:lever[powered=true] run tag @a add lever.4
execute if block -237 18 147 minecraft:lever[powered=false] run tag @a add lever.5
execute unless block -237 18 151 minecraft:lever[powered=true] run tag @a remove lever.1
execute unless block -237 18 150 minecraft:lever[powered=false] run tag @a remove lever.2
execute unless block -237 18 149 minecraft:lever[powered=false] run tag @a remove lever.3
execute unless block -237 18 148 minecraft:lever[powered=true] run tag @a remove lever.4
execute unless block -237 18 147 minecraft:lever[powered=false] run tag @a remove lever.5

execute if block -211 15 157 minecraft:lever[powered=true] run tag @a add lever.6
execute if block -211 15 158 minecraft:lever[powered=true] run tag @a add lever.7
execute if block -211 15 159 minecraft:lever[powered=false] run tag @a add lever.8
execute if block -211 15 160 minecraft:lever[powered=true] run tag @a add lever.9
execute if block -211 15 161 minecraft:lever[powered=true] run tag @a add lever.10
execute unless block -211 15 157 minecraft:lever[powered=true] run tag @a remove lever.6
execute unless block -211 15 158 minecraft:lever[powered=true] run tag @a remove lever.7
execute unless block -211 15 159 minecraft:lever[powered=false] run tag @a remove lever.8
execute unless block -211 15 160 minecraft:lever[powered=true] run tag @a remove lever.9
execute unless block -211 15 161 minecraft:lever[powered=true] run tag @a remove lever.10

execute as @a[tag=!lever.solved,tag=lever.1,tag=lever.2,tag=lever.3,tag=lever.4,tag=lever.5,tag=lever.6,tag=lever.7,tag=lever.8,tag=lever.9,tag=lever.10] at @s run playsound minecraft:entity.player.levelup block @s ~ ~ ~ 0.6 1.5
execute as @a[tag=!lever.solved,tag=lever.1,tag=lever.2,tag=lever.3,tag=lever.4,tag=lever.5,tag=lever.6,tag=lever.7,tag=lever.8,tag=lever.9,tag=lever.10] run fill -225 14 142 -227 16 142 air replace lime_stained_glass
execute as @a[tag=!lever.solved,tag=lever.1,tag=lever.2,tag=lever.3,tag=lever.4,tag=lever.5,tag=lever.6,tag=lever.7,tag=lever.8,tag=lever.9,tag=lever.10] run tag @s add lever.solved

execute positioned -226 13 140 as @e[type=parrot,distance=..2,tag=Origami] at @s as @a[distance=..5,tag=!lever.solved,tag=!parrot.tellraw] run tellraw @s [{"text":"<Origami>","color":"green"},{"bold":false,"text":" *squawk* *squawk* (man help me out here im trapped for real)","color":"white"}]
execute positioned -226 13 140 as @e[type=parrot,distance=..2,tag=Origami] at @s as @a[distance=..5,tag=!parrot.tellraw] run playsound minecraft:entity.parrot.ambient master @s ~ ~ ~ 2 1
execute positioned -226 13 140 as @e[type=parrot,distance=..2,tag=Origami] at @s as @a[distance=..5,tag=!parrot.tellraw] run tag @s add parrot.tellraw
execute positioned -226 13 140 as @e[type=parrot,distance=..2,tag=Origami] at @s as @a[distance=10..15,tag=parrot.tellraw] run tag @s remove parrot.tellraw

execute positioned -226 13 140 as @e[type=parrot,tag=Origami,distance=..2] at @s as @a[tag=lever.solved,tag=!parrot.unlocked,distance=..4] run tellraw @s [{"text":"<Origami>","color":"green","bold":true},{"bold":false,"text":" *squawk* *squawk* *squawk* (thanks for freeing me dude. In exchange ima keep u well fed)","color":"white"}]
execute positioned -226 13 140 as @e[type=parrot,tag=Origami,distance=..2] at @s as @a[tag=lever.solved,tag=!parrot.unlocked,distance=..4] run tellraw @s [{"text":"<"},{"selector":"@s"},{"text":">"},{"bold":false,"text":" So this parrot will feed me when my hunger is low? I guess I won't be needing any more food...","color":"white"}]
execute positioned -226 13 140 as @e[type=parrot,tag=Origami,distance=..2] at @s as @a[tag=lever.solved,tag=!parrot.unlocked,distance=..4] run tag @s add parrot.unlocked

execute as @a[tag=parrot.unlocked,tag=!origami.joined] run setblock -253 35 80 minecraft:redstone_block
execute as @a[tag=parrot.unlocked,tag=!origami.joined] run tellraw @a [{"text":"Origami","color":"green"},{"text":" has joined the party!","color":"yellow"}]
execute as @a[tag=parrot.unlocked] run tag @s add origami.joined
execute as @a[tag=parrot.unlocked] at @s as @e[type=parrot,tag=Origami,distance=..20] run data merge entity @s {Sitting:0b,NoAI:0b}
