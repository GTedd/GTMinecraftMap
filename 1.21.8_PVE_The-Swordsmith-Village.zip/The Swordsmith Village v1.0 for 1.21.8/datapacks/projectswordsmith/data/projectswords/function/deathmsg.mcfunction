execute if entity @a[scores={deathMSG=1..}]
summon minecraft:marker 0 0 0 {Tags:[death_rand,"1"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"2"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"3"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"4"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"5"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"6"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"7"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"8"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"9"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"10"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"11"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"12"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"13"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"14"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"15"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"16"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"17"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"18"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"19"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"20"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"21"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"22"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"23"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"24"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"25"]}
summon minecraft:marker 0 0 0 {Tags:[death_rand,"26"]}
tp @e[tag=death_rand,type=minecraft:marker,limit=1,sort=random,distance=..1,x=0,y=0,z=0] 2 0 2
execute positioned 2 0 2 if entity @e[tag=1,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" died. It was a tactical death.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=2,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" fought like a true warrior.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=3,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"text":"Oh, you are die. Thank you forever, ","color":"yellow"},{"selector":"@s"}]
execute positioned 2 0 2 if entity @e[tag=4,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" dedicated their heart.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=5,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" forgot what their plan was.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=6,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" had a tragic fate.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=7,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" missed all their crits.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=8,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"text":"The future of the village depends on you, ","color":"yellow"},{"selector":"@s"},{"text":"! Don't lose hope!","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=9,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" doesn't seem to be stayin' alive.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=10,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"text":"Dust yourself off, ","color":"yellow"},{"selector":"@s"},{"text":", greatness awaits!","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=11,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"text":"Remember, ","color":"yellow"},{"selector":"@s"},{"text":", death is only temporary, victory is permanent!","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=12,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"text":"You died, ","color":"yellow"},{"selector":"@s"},{"text":", but you already knew that, didn't you?","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=13,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" tried to divide by 0","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=14,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"text":"Fun fact, ","color":"yellow"},{"selector":"@s"},{"text":" - there was only a 3.85% chance of you seeing this message!","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=15,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" doesn't feel so good...","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=16,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" blames the lag","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=17,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" got hit by a truck and found himself on another world... how cliché.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=18,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" met an immovable object.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=19,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" got eaten alive! How spooky.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=20,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"text":"Mission failed. We'll get em next time, ","color":"yellow"},{"selector":"@s"}]
execute positioned 2 0 2 if entity @e[tag=21,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"text":"Nobody said it would be easy, ","color":"yellow"},{"selector":"@s"},{"text":". Well, no one said it would be hard either...","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=22,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" did not survive through 100 days of hardcore minecraft.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=23,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" fell down a rabbit hole.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=24,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" fell for a distraction dance.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=25,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" believed they could fly.","color":"yellow"}]
execute positioned 2 0 2 if entity @e[tag=26,distance=..1] as @a[scores={deathMSG=1..}] run tellraw @a [{"selector":"@s"},{"text":" got hit by an unlucky crit and fainted!","color":"yellow"}]
scoreboard players reset @a[scores={deathMSG=1..}] deathMSG
execute positioned 0 0 0 run kill @e[tag=death_rand,distance=..5,type=minecraft:marker]
