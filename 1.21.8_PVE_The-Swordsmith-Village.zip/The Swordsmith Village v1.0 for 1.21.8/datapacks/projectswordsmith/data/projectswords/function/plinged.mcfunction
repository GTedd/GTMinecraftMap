execute as @e[type=item,tag=!plinged,nbt={Item:{id:"minecraft:diamond",count:1}}] at @s run playsound minecraft:block.note_block.bell master @a ~ ~ ~ 1 2
execute as @e[type=item,tag=!plinged,nbt={Item:{id:"minecraft:emerald",count:1}}] at @s run playsound minecraft:block.note_block.bell master @a ~ ~ ~ 1 2
execute as @e[type=item,tag=!plinged,nbt={Item:{id:"minecraft:lapis_lazuli",count:1}}] at @s run playsound minecraft:block.note_block.bell master @a ~ ~ ~ 1 2
execute as @e[type=item,tag=!plinged,nbt={Item:{id:"minecraft:gold_ingot",count:1}}] at @s run playsound minecraft:block.note_block.bell master @a ~ ~ ~ 1 2
execute as @e[type=item,tag=!plinged,nbt={Item:{id:"minecraft:diamond",count:1}}] run tag @s add plinged
execute as @e[type=item,tag=!plinged,nbt={Item:{id:"minecraft:gold_ingot",count:1}}] run tag @s add plinged
execute as @e[type=item,tag=!plinged,nbt={Item:{id:"minecraft:lapis_lazuli",count:1}}] run tag @s add plinged
execute as @e[type=item,tag=!plinged,nbt={Item:{id:"minecraft:emerald",count:1}}] run tag @s add plinged
