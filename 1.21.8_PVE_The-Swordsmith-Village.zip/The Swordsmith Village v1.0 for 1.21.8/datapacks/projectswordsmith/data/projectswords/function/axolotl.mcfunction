setblock -221 59 165 minecraft:iron_trapdoor[open=false,half=top]
tellraw @s [{"text":"Bubbles","color":"blue"},{"text":" has joined the party!","color":"yellow"}]
setblock -253 35 80 minecraft:redstone_block
execute positioned -221 59 167 as @e[type=minecraft:axolotl,tag=Bubbles,distance=..2] run data merge entity @s {NoAI:0b}
execute positioned -221 59 167 as @e[type=minecraft:axolotl,tag=Bubbles,distance=..2] run effect give @s minecraft:glowing 10 0 true
tag @s add axolotl.unlocked