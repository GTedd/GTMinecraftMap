tellraw @a[tag=!victory] [{"text":"Master ","color":"dark_red","bold":true},{"bold":false,"text":"difficulty unlocked!","color":"yellow"}]
scoreboard players add @a stats 1
schedule function projectswords:victory 5t replace
tag @a add victory
tag @a add reset