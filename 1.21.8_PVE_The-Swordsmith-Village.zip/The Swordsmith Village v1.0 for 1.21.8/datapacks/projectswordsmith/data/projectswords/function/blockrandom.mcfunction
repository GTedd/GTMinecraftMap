execute as @p[team=!Spectator,tag=tuff1] if score dummy randomtimer matches 10 store result score #random1 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff1] if score #random1 randomregen matches 1 run setblock -170 69 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff1] if score #random1 randomregen matches 1 run tag @a remove tuff1
execute as @p[team=!Spectator,tag=!tuff1] if score #random1 randomregen matches 1 store result score #random1 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff2] if score dummy randomtimer matches 13 store result score #random2 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff2] if score #random2 randomregen matches 1 run setblock -169 69 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff2] if score #random2 randomregen matches 1 run tag @a remove tuff2
execute as @p[team=!Spectator,tag=!tuff2] if score #random2 randomregen matches 1 store result score #random2 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff3] if score dummy randomtimer matches 43 store result score #random3 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff3] if score #random3 randomregen matches 1 run setblock -169 68 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff3] if score #random3 randomregen matches 1 run tag @a remove tuff3
execute as @p[team=!Spectator,tag=!tuff3] if score #random3 randomregen matches 1 store result score #random3 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff4] if score dummy randomtimer matches 33 store result score #random4 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff4] if score #random4 randomregen matches 1 run setblock -168 69 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff4] if score #random4 randomregen matches 1 run tag @a remove tuff4
execute as @p[team=!Spectator,tag=!tuff4] if score #random4 randomregen matches 1 store result score #random4 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff5] if score dummy randomtimer matches 23 store result score #random5 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff5] if score #random5 randomregen matches 1 run setblock -168 70 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff5] if score #random5 randomregen matches 1 run tag @a remove tuff5
execute as @p[team=!Spectator,tag=!tuff5] if score #random5 randomregen matches 1 store result score #random5 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff6] if score dummy randomtimer matches 73 store result score #random6 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff6] if score #random6 randomregen matches 1 run setblock -163 69 61 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff6] if score #random6 randomregen matches 1 run tag @a remove tuff6
execute as @p[team=!Spectator,tag=!tuff6] if score #random6 randomregen matches 1 store result score #random6 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff7] if score dummy randomtimer matches 15 store result score #random7 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff7] if score #random7 randomregen matches 1 run setblock -163 70 61 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff7] if score #random7 randomregen matches 1 run tag @a remove tuff7
execute as @p[team=!Spectator,tag=!tuff7] if score #random7 randomregen matches 1 store result score #random7 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff8] if score dummy randomtimer matches 3 store result score #random8 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff8] if score #random8 randomregen matches 1 run setblock -163 70 60 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff8] if score #random8 randomregen matches 1 run tag @a remove tuff8
execute as @p[team=!Spectator,tag=!tuff8] if score #random8 randomregen matches 1 store result score #random8 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff9] if score dummy randomtimer matches 46 store result score #random9 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff9] if score #random9 randomregen matches 1 run setblock -163 71 60 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff9] if score #random9 randomregen matches 1 run tag @a remove tuff9
execute as @p[team=!Spectator,tag=!tuff9] if score #random9 randomregen matches 1 store result score #random9 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff10] if score dummy randomtimer matches 27 store result score #random10 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff10] if score #random10 randomregen matches 1 run setblock -174 68 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff10] if score #random10 randomregen matches 1 run tag @a remove tuff10
execute as @p[team=!Spectator,tag=!tuff10] if score #random10 randomregen matches 1 store result score #random10 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff11] if score dummy randomtimer matches 19 store result score #random11 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff11] if score #random11 randomregen matches 1 run setblock -173 67 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff11] if score #random11 randomregen matches 1 run tag @a remove tuff11
execute as @p[team=!Spectator,tag=!tuff11] if score #random11 randomregen matches 1 store result score #random11 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff12] if score dummy randomtimer matches 23 store result score #random12 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff12] if score #random12 randomregen matches 1 run setblock -174 67 57 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff12] if score #random12 randomregen matches 1 run tag @a remove tuff12
execute as @p[team=!Spectator,tag=!tuff12] if score #random12 randomregen matches 1 store result score #random12 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff13] if score dummy randomtimer matches 68 store result score #random13 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff13] if score #random13 randomregen matches 1 run setblock -165 72 59 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff13] if score #random13 randomregen matches 1 run tag @a remove tuff13
execute as @p[team=!Spectator,tag=!tuff13] if score #random13 randomregen matches 1 store result score #random13 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff14] if score dummy randomtimer matches 38 store result score #random14 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff14] if score #random14 randomregen matches 1 run setblock -165 73 59 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff14] if score #random14 randomregen matches 1 run tag @a remove tuff14
execute as @p[team=!Spectator,tag=!tuff14] if score #random14 randomregen matches 1 store result score #random14 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff15] if score dummy randomtimer matches 22 store result score #random15 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff15] if score #random15 randomregen matches 1 run setblock -166 73 59 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff15] if score #random15 randomregen matches 1 run tag @a remove tuff15
execute as @p[team=!Spectator,tag=!tuff15] if score #random15 randomregen matches 1 store result score #random15 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff16] if score dummy randomtimer matches 16 store result score #random16 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff16] if score #random16 randomregen matches 1 run setblock -165 68 59 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff16] if score #random16 randomregen matches 1 run tag @a remove tuff16
execute as @p[team=!Spectator,tag=!tuff16] if score #random16 randomregen matches 1 store result score #random16 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff17] if score dummy randomtimer matches 2 store result score #random17 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff17] if score #random17 randomregen matches 1 run setblock -166 67 59 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff17] if score #random17 randomregen matches 1 run tag @a remove tuff17
execute as @p[team=!Spectator,tag=!tuff17] if score #random17 randomregen matches 1 store result score #random17 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff18] if score dummy randomtimer matches 8 store result score #random18 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff18] if score #random18 randomregen matches 1 run setblock -166 67 60 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff18] if score #random18 randomregen matches 1 run tag @a remove tuff18
execute as @p[team=!Spectator,tag=!tuff18] if score #random18 randomregen matches 1 store result score #random18 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff19] if score dummy randomtimer matches 54 store result score #random19 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff19] if score #random19 randomregen matches 1 run setblock -167 66 60 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff19] if score #random19 randomregen matches 1 run tag @a remove tuff19
execute as @p[team=!Spectator,tag=!tuff19] if score #random19 randomregen matches 1 store result score #random19 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff20] if score dummy randomtimer matches 49 store result score #random20 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff20] if score #random20 randomregen matches 1 run setblock -166 66 61 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff20] if score #random20 randomregen matches 1 run tag @a remove tuff20
execute as @p[team=!Spectator,tag=!tuff20] if score #random20 randomregen matches 1 store result score #random20 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff21] if score dummy randomtimer matches 34 store result score #random21 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff21] if score #random21 randomregen matches 1 run setblock -168 68 65 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff21] if score #random21 randomregen matches 1 run tag @a remove tuff21
execute as @p[team=!Spectator,tag=!tuff21] if score #random21 randomregen matches 1 store result score #random21 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff22] if score dummy randomtimer matches 42 store result score #random22 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff22] if score #random22 randomregen matches 1 run setblock -169 67 64 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff22] if score #random22 randomregen matches 1 run tag @a remove tuff22
execute as @p[team=!Spectator,tag=!tuff22] if score #random22 randomregen matches 1 store result score #random22 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff23] if score dummy randomtimer matches 78 store result score #random23 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff23] if score #random23 randomregen matches 1 run setblock -172 66 60 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff23] if score #random23 randomregen matches 1 run tag @a remove tuff23
execute as @p[team=!Spectator,tag=!tuff23] if score #random23 randomregen matches 1 store result score #random23 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff24] if score dummy randomtimer matches 57 store result score #random24 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff24] if score #random24 randomregen matches 1 run setblock -173 71 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff24] if score #random24 randomregen matches 1 run tag @a remove tuff24
execute as @p[team=!Spectator,tag=!tuff24] if score #random24 randomregen matches 1 store result score #random24 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff25] if score dummy randomtimer matches 66 store result score #random25 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff25] if score #random25 randomregen matches 1 run setblock -174 70 56 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff25] if score #random25 randomregen matches 1 run tag @a remove tuff25
execute as @p[team=!Spectator,tag=!tuff25] if score #random25 randomregen matches 1 store result score #random25 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff26] if score dummy randomtimer matches 90 store result score #random26 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff26] if score #random26 randomregen matches 1 run setblock -165 68 63 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff26] if score #random26 randomregen matches 1 run tag @a remove tuff26
execute as @p[team=!Spectator,tag=!tuff26] if score #random26 randomregen matches 1 store result score #random26 randomregen run random value 2..4

execute as @p[team=!Spectator,tag=tuff27] if score dummy randomtimer matches 36 store result score #random27 randomregen run random value 1..4
execute as @p[team=!Spectator,tag=tuff27] if score #random27 randomregen matches 1 run setblock -170 66 59 dead_brain_coral_block
execute as @p[team=!Spectator,tag=tuff27] if score #random27 randomregen matches 1 run tag @a remove tuff27
execute as @p[team=!Spectator,tag=!tuff27] if score #random27 randomregen matches 1 store result score #random27 randomregen run random value 2..4
