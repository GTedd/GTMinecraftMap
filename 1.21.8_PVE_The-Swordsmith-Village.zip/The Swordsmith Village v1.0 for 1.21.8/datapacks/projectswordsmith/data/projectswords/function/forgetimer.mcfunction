setblock -237 35 146 minecraft:redstone_block

# forgetimer #
execute as @e[tag=iceupgrade1] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 1200
execute as @e[tag=iceupgrade2] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 2400
execute as @e[tag=iceupgrade3] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 3600
execute as @e[tag=iceupgrade4] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 4800

execute as @e[tag=slimeupgrade1] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 1200
execute as @e[tag=slimeupgrade2] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 2400
execute as @e[tag=slimeupgrade3] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 3600
execute as @e[tag=slimeupgrade4] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 4800

execute as @e[tag=magmaupgrade1] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 1200
execute as @e[tag=magmaupgrade2] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 2400
execute as @e[tag=magmaupgrade3] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 3600
execute as @e[tag=magmaupgrade4] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 4800

execute as @e[tag=waterupgrade1] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 1200
execute as @e[tag=waterupgrade2] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 2400
execute as @e[tag=waterupgrade3] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 3600
execute as @e[tag=waterupgrade4] if score dummy forgetimer matches ..0 run scoreboard players set dummy forgetimer 4800

# upgrade1 - 1m #
execute as @e[tag=iceupgrade1] run execute if score dummy forgetimer matches 1200 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=iceupgrade1] run execute if score dummy forgetimer matches 960 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=iceupgrade1] run execute if score dummy forgetimer matches 720 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=iceupgrade1] run execute if score dummy forgetimer matches 480 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=iceupgrade1] run execute if score dummy forgetimer matches 240 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=iceupgrade1] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=slimeupgrade1] run execute if score dummy forgetimer matches 1200 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=slimeupgrade1] run execute if score dummy forgetimer matches 960 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=slimeupgrade1] run execute if score dummy forgetimer matches 720 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=slimeupgrade1] run execute if score dummy forgetimer matches 480 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=slimeupgrade1] run execute if score dummy forgetimer matches 240 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=slimeupgrade1] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=magmaupgrade1] run execute if score dummy forgetimer matches 1200 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=magmaupgrade1] run execute if score dummy forgetimer matches 960 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=magmaupgrade1] run execute if score dummy forgetimer matches 720 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=magmaupgrade1] run execute if score dummy forgetimer matches 480 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=magmaupgrade1] run execute if score dummy forgetimer matches 240 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=magmaupgrade1] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=waterupgrade1] run execute if score dummy forgetimer matches 1200 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=waterupgrade1] run execute if score dummy forgetimer matches 960 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=waterupgrade1] run execute if score dummy forgetimer matches 720 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=waterupgrade1] run execute if score dummy forgetimer matches 480 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=waterupgrade1] run execute if score dummy forgetimer matches 240 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=waterupgrade1] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

# upgrade2 - 2m #
execute as @e[tag=iceupgrade2] run execute if score dummy forgetimer matches 2400 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=iceupgrade2] run execute if score dummy forgetimer matches 1920 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=iceupgrade2] run execute if score dummy forgetimer matches 1440 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=iceupgrade2] run execute if score dummy forgetimer matches 960 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=iceupgrade2] run execute if score dummy forgetimer matches 480 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=iceupgrade2] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=slimeupgrade2] run execute if score dummy forgetimer matches 2400 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=slimeupgrade2] run execute if score dummy forgetimer matches 1920 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=slimeupgrade2] run execute if score dummy forgetimer matches 1440 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=slimeupgrade2] run execute if score dummy forgetimer matches 960 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=slimeupgrade2] run execute if score dummy forgetimer matches 480 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=slimeupgrade2] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=magmaupgrade2] run execute if score dummy forgetimer matches 2400 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=magmaupgrade2] run execute if score dummy forgetimer matches 1920 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=magmaupgrade2] run execute if score dummy forgetimer matches 1440 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=magmaupgrade2] run execute if score dummy forgetimer matches 960 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=magmaupgrade2] run execute if score dummy forgetimer matches 480 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=magmaupgrade2] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=waterupgrade2] run execute if score dummy forgetimer matches 2400 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=waterupgrade2] run execute if score dummy forgetimer matches 1920 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=waterupgrade2] run execute if score dummy forgetimer matches 1440 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=waterupgrade2] run execute if score dummy forgetimer matches 960 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=waterupgrade2] run execute if score dummy forgetimer matches 480 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=waterupgrade2] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

# upgrade3 - 3m #
execute as @e[tag=iceupgrade3] run execute if score dummy forgetimer matches 3600 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=iceupgrade3] run execute if score dummy forgetimer matches 2880 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=iceupgrade3] run execute if score dummy forgetimer matches 2160 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=iceupgrade3] run execute if score dummy forgetimer matches 1440 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=iceupgrade3] run execute if score dummy forgetimer matches 720 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=iceupgrade3] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=slimeupgrade3] run execute if score dummy forgetimer matches 3600 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=slimeupgrad3] run execute if score dummy forgetimer matches 2880 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=slimeupgrade3] run execute if score dummy forgetimer matches 2160 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=slimeupgrade3] run execute if score dummy forgetimer matches 1440 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=slimeupgrade3] run execute if score dummy forgetimer matches 720 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=slimeupgrade3] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=magmaupgrade3] run execute if score dummy forgetimer matches 3600 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=magmaupgrade3] run execute if score dummy forgetimer matches 2880 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=magmaupgrade3] run execute if score dummy forgetimer matches 2160 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=magmaupgrade3] run execute if score dummy forgetimer matches 1440 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=magmaupgrade3] run execute if score dummy forgetimer matches 720 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=magmaupgrade3] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=waterupgrade3] run execute if score dummy forgetimer matches 3600 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=waterupgrade3] run execute if score dummy forgetimer matches 2880 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=waterupgrade3] run execute if score dummy forgetimer matches 2160 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=waterupgrade3] run execute if score dummy forgetimer matches 1440 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=waterupgrade3] run execute if score dummy forgetimer matches 720 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=waterupgrade3] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

# upgrade4 - 4m #
execute as @e[tag=iceupgrade4] run execute if score dummy forgetimer matches 4800 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=iceupgrade4] run execute if score dummy forgetimer matches 3840 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=iceupgrade4] run execute if score dummy forgetimer matches 2880 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=iceupgrade4] run execute if score dummy forgetimer matches 1920 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=iceupgrade4] run execute if score dummy forgetimer matches 960 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=iceupgrade4] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=slimeupgrade4] run execute if score dummy forgetimer matches 4800 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=slimeupgrade4] run execute if score dummy forgetimer matches 3840 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=slimeupgrade4] run execute if score dummy forgetimer matches 2880 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=slimeupgrade4] run execute if score dummy forgetimer matches 1920 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=slimeupgrade4] run execute if score dummy forgetimer matches 960 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=slimeupgrade4] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=magmaupgrade4] run execute if score dummy forgetimer matches 4800 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=magmaupgrade4] run execute if score dummy forgetimer matches 3840 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=magmaupgrade4] run execute if score dummy forgetimer matches 2880 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=magmaupgrade4] run execute if score dummy forgetimer matches 1920 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=magmaupgrade4] run execute if score dummy forgetimer matches 960 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=magmaupgrade4] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block

execute as @e[tag=waterupgrade4] run execute if score dummy forgetimer matches 4800 run setblock -235 35 139 minecraft:redstone_block
execute as @e[tag=waterupgrade4] run execute if score dummy forgetimer matches 3840 run setblock -235 35 140 minecraft:redstone_block
execute as @e[tag=waterupgrade4] run execute if score dummy forgetimer matches 2880 run setblock -235 35 141 minecraft:redstone_block
execute as @e[tag=waterupgrade4] run execute if score dummy forgetimer matches 1920 run setblock -235 35 142 minecraft:redstone_block
execute as @e[tag=waterupgrade4] run execute if score dummy forgetimer matches 960 run setblock -235 35 143 minecraft:redstone_block
execute as @e[tag=waterupgrade4] run execute if score dummy forgetimer matches 1 run setblock -235 35 144 minecraft:redstone_block
