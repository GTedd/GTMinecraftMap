scoreboard objectives add transition dummy
execute unless score day0 transition matches 1200.. run scoreboard players add day0 transition 1
execute if score day0 transition matches 1 run fill -215 74 35 -213 77 35 air
execute if score day0 transition matches 1 run time set 23000
execute if score day0 transition matches 1 run bossbar set minecraft:daynight players @a
execute if score day0 transition matches 1 run tp 112eb2d8-5d51-4122-804f-bc618a4cf1b8 -209.7 79.5 23.5 90 35
execute if score day0 transition matches 100 run time set 23050
execute if score day0 transition matches 200 run time set 23100
execute if score day0 transition matches 300 run time set 23150
execute if score day0 transition matches 400 run time set 23200
execute if score day0 transition matches 500 run time set 23250
execute if score day0 transition matches 600 run time set 23300
execute if score day0 transition matches 700 run time set 23350
execute if score day0 transition matches 800 run time set 23400
execute if score day0 transition matches 900 run time set 23450
execute if score day0 transition matches 1000 run time set 23500
execute if score day0 transition matches 1100 run time set 23550
execute if score day0 transition matches 1200 run time set 23600

gamerule doDaylightCycle false
tag @s remove nightbar

execute positioned -211 79 23 if entity @e[type=villager,distance=..2,tag=comein] run function projectswords:transition1_end

scoreboard players add objective1 timer 1
execute if score objective1 timer matches 200 run effect give @e[type=minecraft:shulker,tag=Objective] minecraft:glowing infinite 1 true
execute unless score objective1 timer matches 200.. run effect clear @e[type=minecraft:shulker,tag=Objective] minecraft:glowing
