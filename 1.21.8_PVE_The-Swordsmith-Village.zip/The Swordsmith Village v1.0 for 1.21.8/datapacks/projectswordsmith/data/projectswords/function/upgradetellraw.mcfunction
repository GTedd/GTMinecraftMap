# ICE #
execute as @e[tag=iceupgrade1] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=iceupgrade1] run tellraw @a ""
execute as @e[tag=iceupgrade1] run tellraw @a {"text":"           ICE INFUSION","color":"aqua","bold":true}
execute as @e[tag=iceupgrade1] run tellraw @a {"text":"      Upgrade Time: 1 minute","color":"green","bold":true}
execute as @e[tag=iceupgrade1] run tellraw @a ""
execute as @e[tag=iceupgrade1] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=iceupgrade2] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=iceupgrade2] run tellraw @a ""
execute as @e[tag=iceupgrade2] run tellraw @a {"text":"          ICE REFORGING","color":"aqua","bold":true}
execute as @e[tag=iceupgrade2] run tellraw @a {"text":"      Upgrade Time: 2 minutes","color":"green","bold":true}
execute as @e[tag=iceupgrade2] run tellraw @a ""
execute as @e[tag=iceupgrade2] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=iceupgrade3] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=iceupgrade3] run tellraw @a ""
execute as @e[tag=iceupgrade3] run tellraw @a {"text":"         ICE AUGMENTATION","color":"aqua","bold":true}
execute as @e[tag=iceupgrade3] run tellraw @a {"text":"      Upgrade Time: 3 minutes","color":"green","bold":true}
execute as @e[tag=iceupgrade3] run tellraw @a ""
execute as @e[tag=iceupgrade3] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=iceupgrade4] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=iceupgrade4] run tellraw @a ""
execute as @e[tag=iceupgrade4] run tellraw @a {"text":"         ICE REINFORCEMENT","color":"aqua","bold":true}
execute as @e[tag=iceupgrade4] run tellraw @a {"text":"      Upgrade Time: 4 minutes","color":"green","bold":true}
execute as @e[tag=iceupgrade4] run tellraw @a ""
execute as @e[tag=iceupgrade4] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

# SLIME #

execute as @e[tag=slimeupgrade1] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=slimeupgrade1] run tellraw @a ""
execute as @e[tag=slimeupgrade1] run tellraw @a {"text":"          SLIME INFUSION","color":"green","bold":true}
execute as @e[tag=slimeupgrade1] run tellraw @a {"text":"      Upgrade Time: 1 minute","color":"green","bold":true}
execute as @e[tag=slimeupgrade1] run tellraw @a ""
execute as @e[tag=slimeupgrade1] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=slimeupgrade2] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=slimeupgrade2] run tellraw @a ""
execute as @e[tag=slimeupgrade2] run tellraw @a {"text":"         SLIME REFORGING","color":"green","bold":true}
execute as @e[tag=slimeupgrade2] run tellraw @a {"text":"      Upgrade Time: 2 minutes","color":"green","bold":true}
execute as @e[tag=slimeupgrade2] run tellraw @a ""
execute as @e[tag=slimeupgrade2] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=slimeupgrade3] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=slimeupgrade3] run tellraw @a ""
execute as @e[tag=slimeupgrade3] run tellraw @a {"text":"         SLIME AUGMENTATION","color":"green","bold":true}
execute as @e[tag=slimeupgrade3] run tellraw @a {"text":"      Upgrade Time: 3 minutes","color":"green","bold":true}
execute as @e[tag=slimeupgrade3] run tellraw @a ""
execute as @e[tag=slimeupgrade3] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=slimeupgrade4] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=slimeupgrade4] run tellraw @a ""
execute as @e[tag=slimeupgrade4] run tellraw @a {"text":"        SLIME REINFORCEMENT","color":"green","bold":true}
execute as @e[tag=slimeupgrade4] run tellraw @a {"text":"      Upgrade Time: 4 minutes","color":"green","bold":true}
execute as @e[tag=slimeupgrade4] run tellraw @a ""
execute as @e[tag=slimeupgrade4] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

# MAGMA #

execute as @e[tag=magmaupgrade1] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=magmaupgrade1] run tellraw @a ""
execute as @e[tag=magmaupgrade1] run tellraw @a {"text":"          MAGMA INFUSION","color":"gold","bold":true}
execute as @e[tag=magmaupgrade1] run tellraw @a {"text":"      Upgrade Time: 1 minute","color":"green","bold":true}
execute as @e[tag=magmaupgrade1] run tellraw @a ""
execute as @e[tag=magmaupgrade1] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=magmaupgrade2] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=magmaupgrade2] run tellraw @a ""
execute as @e[tag=magmaupgrade2] run tellraw @a {"text":"          MAGMA REFORGING","color":"gold","bold":true}
execute as @e[tag=magmaupgrade2] run tellraw @a {"text":"      Upgrade Time: 2 minutes","color":"green","bold":true}
execute as @e[tag=magmaupgrade2] run tellraw @a ""
execute as @e[tag=magmaupgrade2] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=magmaupgrade3] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=magmaupgrade3] run tellraw @a ""
execute as @e[tag=magmaupgrade3] run tellraw @a {"text":"         MAGMA AUGMENTATION","color":"gold","bold":true}
execute as @e[tag=magmaupgrade3] run tellraw @a {"text":"      Upgrade Time: 3 minutes","color":"green","bold":true}
execute as @e[tag=magmaupgrade3] run tellraw @a ""
execute as @e[tag=magmaupgrade3] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=magmaupgrade4] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=magmaupgrade4] run tellraw @a ""
execute as @e[tag=magmaupgrade4] run tellraw @a {"text":"        MAGMA REINFORCEMENT","color":"gold","bold":true}
execute as @e[tag=magmaupgrade4] run tellraw @a {"text":"      Upgrade Time: 4 minutes","color":"green","bold":true}
execute as @e[tag=magmaupgrade4] run tellraw @a ""
execute as @e[tag=magmaupgrade4] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

# WATER #

execute as @e[tag=waterupgrade1] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=waterupgrade1] run tellraw @a ""
execute as @e[tag=waterupgrade1] run tellraw @a {"text":"          WATER INFUSION","color":"blue","bold":true}
execute as @e[tag=waterupgrade1] run tellraw @a {"text":"      Upgrade Time: 1 minute","color":"green","bold":true}
execute as @e[tag=waterupgrade1] run tellraw @a ""
execute as @e[tag=waterupgrade1] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=waterupgrade2] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=waterupgrade2] run tellraw @a ""
execute as @e[tag=waterupgrade2] run tellraw @a {"text":"          WATER REFORGING","color":"blue","bold":true}
execute as @e[tag=waterupgrade2] run tellraw @a {"text":"      Upgrade Time: 2 minutes","color":"green","bold":true}
execute as @e[tag=waterupgrade2] run tellraw @a ""
execute as @e[tag=waterupgrade2] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=waterupgrade3] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=waterupgrade3] run tellraw @a ""
execute as @e[tag=waterupgrade3] run tellraw @a {"text":"         WATER AUGMENTATION","color":"blue","bold":true}
execute as @e[tag=waterupgrade3] run tellraw @a {"text":"      Upgrade Time: 3 minutes","color":"green","bold":true}
execute as @e[tag=waterupgrade3] run tellraw @a ""
execute as @e[tag=waterupgrade3] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

execute as @e[tag=waterupgrade4] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}
execute as @e[tag=waterupgrade4] run tellraw @a ""
execute as @e[tag=waterupgrade4] run tellraw @a {"text":"        WATER REINFORCEMENT","color":"blue","bold":true}
execute as @e[tag=waterupgrade4] run tellraw @a {"text":"      Upgrade Time: 4 minutes","color":"green","bold":true}
execute as @e[tag=waterupgrade4] run tellraw @a ""
execute as @e[tag=waterupgrade4] run tellraw @a {"text":"----------------------------","color":"dark_gray","bold":true}

