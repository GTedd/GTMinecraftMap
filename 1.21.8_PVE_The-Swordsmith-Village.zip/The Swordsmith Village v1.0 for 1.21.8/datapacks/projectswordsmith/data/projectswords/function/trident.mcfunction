execute on target run scoreboard players add clicks tridentclick 1
execute on target run scoreboard players add tp tridentclick 1
data remove entity @s interaction
execute at @s if score tp tridentclick matches 1 as @e[type=minecraft:trident,tag=Trident,distance=..2,limit=1] at @s run tp @s ~ ~0.025 ~ 90 180
execute if score clicks tridentclick matches 20 run tag @a add trident.unlocked
execute at @s if score clicks tridentclick matches 20 run playsound minecraft:entity.player.levelup block @a ~ ~ ~ 0.6 0.5
execute at @s if score clicks tridentclick matches 20 run give @p[team=!Spectator] trident[enchantments={"minecraft:loyalty":1},custom_name={"bold":true,"color":"blue","italic":false,"obfuscated":false,"strikethrough":false,"text":"Water Elemental Trident","underlined":false},lore=[{"bold":false,"color":"#518794","italic":true,"obfuscated":false,"strikethrough":false,"text":"He who sends this trident into the crystal heart ","underlined":false},{"color":"#518794","text":"Of the weapon that never strikes, yet falls apart"},{"color":"#518794","text":"Shall be granted a companion of the purest heart."}],tooltip_display={hidden_components:["attribute_modifiers"]}] 1
execute at @s if score clicks tridentclick matches 20 as @e[type=minecraft:trident,tag=Trident,distance=..2,limit=1] run tp @s -268 1 102
execute at @s if score clicks tridentclick matches 20 run tp @s -268 1 102
scoreboard players set tp tridentclick 0