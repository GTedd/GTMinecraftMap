#KEEP ON TOP#
tag @a remove dead_spectator
setblock 0 97 -2 air
tp @a 0 101 0 -90 0
gamemode adventure @a[tag=!dev]
execute as @a[tag=hardcore] at @s run playsound minecraft:entity.wither.death master @s ~ ~ ~ 1 0.8
tag @a remove boss_spawned
kill @e[type=minecraft:ghast,tag=Boss]

tag 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 remove day
tag 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 remove night

tag @e[type=interaction,tag=amet] remove rc.done
execute as @e[type=villager] run function projectswords:reset_villagers
tag 975bcf8a-1e63-4396-ad99-d31de7b93a0d remove tnt
tag 975bcf8a-1e63-4396-ad99-d31de7b93a0d remove tnt1.given
tag 975bcf8a-1e63-4396-ad99-d31de7b93a0d remove tnt2.given
tag 975bcf8a-1e63-4396-ad99-d31de7b93a0d remove tnt.both
tp a6331fcd-5172-4df7-ae12-73cc5eb5402e -233.9 80 87.3 -65.5 39.2
tag @a remove night
tag @a remove outofhouse
tag @a remove objective1
tag @a remove tellraw1
tag @a remove day1
tag @a remove leathertier
tag @a remove day2
tag @a remove chainmailtier
tag @a remove day3
tag @a remove irontier
tag @a remove day4
tag @a remove diamondtier
tag @a remove day5
tag @a remove diamondbtier
tag @a remove daybar
tag @a remove nightbar
tag @a remove jukebox_complete
tag @a remove in_boss
tag @a remove cagelimit
tag @a remove transition1
tag @a remove anchor.failed
tag @a remove anchor.night
tag @a remove has.allay_key
tag @a remove opened.allay
tag @a remove allay.unlocked
tag @a remove clone.ran
tag @a remove in.iceroom
tag @a remove target.solved
tag @a remove target.1
tag @a remove rabbit.unlocked
tag @a remove rabbit.tellraw
tag @a remove tetsuo.unlocked
tag @a remove stop.mobs
tag @a remove kacper.final
tag @a remove trident.unlocked
tag @a remove axolotl.unlocked
tag @a remove parrot.tellraw
tag @a remove in.slimeroom
tag @a remove lever.solved
tag @a remove parrot.unlocked
tag @a remove origami.joined
tag @a remove key.dropped
tag @a remove tnt1.reward
tag @a remove leather_reward
tag @a remove chainmail_reward
tag @a remove iron_reward
tag @a remove diamond_reward
tag @a remove by.elder
tag @a remove repeat.started
tag @a remove all.cleared
tag @a remove preboss
tag @a remove boss.unlocked
tag @a remove has.key
tag @a remove armorer.saved
tag @a remove theo.1
tag @a remove apprentice.talked
tag @a remove axolotl.buffed
tag @a remove ending
tag @a remove final.room
tag @a remove sound.1
tag @a remove sound.2
tag @a remove sound.3
tag @a remove sound.4
tag @a remove target.1
tag @a remove target.2
tag @a remove target.3
tag @a remove target.4
tag @a remove target.5
tag @a remove recipe.gold
tag @a remove transition.comein.tp
tag @a remove final.push
tag @a remove day
tag @a add day

recipe take @a *

bossbar set minecraft:daynight players
bossbar set minecraft:daytimer players
bossbar set minecraft:nighttimer players
bossbar set minecraft:stone players
bossbar set minecraft:preboss players
bossbar set minecraft:prepare players

scoreboard objectives setdisplay sidebar
scoreboard players reset * BossTimer
scoreboard players reset * randomtimer
scoreboard players reset * preboss
scoreboard players reset * final
scoreboard players reset * villagerinteraction
scoreboard players reset * timer2
scoreboard players reset * Checks
scoreboard players reset * Position
scoreboard players reset * Shift3
scoreboard players reset * timer
scoreboard players reset * Shift4
scoreboard players reset * ametclick
scoreboard players reset * boss.death
scoreboard players reset * respawn.timer
scoreboard players reset * timerweather
scoreboard players reset * cooldown
scoreboard players reset * health
scoreboard players reset * randomregen
scoreboard players reset * random
scoreboard players reset * nighttimer
scoreboard players reset * LongTimer
scoreboard players reset * Shift
scoreboard players reset * clickevent
scoreboard players reset * timerfire
scoreboard players reset * rabbit
scoreboard players reset * clickevent.compass
scoreboard players reset * reset.wasHere
scoreboard players reset * spawntimer
scoreboard players reset * deathMSG
scoreboard players reset * timerice
scoreboard players reset * forgetimer
scoreboard players reset * death.timer
scoreboard players reset * Sneak
scoreboard players reset * tridentclick
scoreboard players reset * lobby
scoreboard players reset * transition
scoreboard players reset * player.health
scoreboard players reset * timer20s
scoreboard players reset * daytimer
scoreboard players reset * cagemobs
scoreboard players set @a timer20s 5
scoreboard players set @a timer 5
scoreboard players set dummy nighttimer 10000
scoreboard players set dummy daytimer 10000

setblock -256 50 99 minecraft:redstone_block

setblock -219 63 68 air
setblock -238 40 93 air
setblock -256 35 134 minecraft:air
setblock -261 35 131 minecraft:air
setblock -261 35 133 minecraft:air
setblock -186 74 80 birch_planks
setblock -186 73 80 birch_planks
setblock -235 40 104 minecraft:air
setblock -235 42 104 minecraft:air
setblock -235 44 104 minecraft:air
setblock -235 46 104 minecraft:air
setblock -235 48 104 minecraft:air
setblock -235 50 104 minecraft:air
setblock -235 52 104 minecraft:air
setblock -235 54 104 minecraft:air
setblock -235 56 104 minecraft:air
setblock -237 40 104 minecraft:air
setblock -239 42 104 minecraft:air
setblock -239 40 104 minecraft:air
setblock -220 17 102 air
setblock -220 14 102 air

setblock -229 44 116 air
setblock -228 41 116 air
setblock -227 41 116 minecraft:redstone_block
setblock -231 41 116 minecraft:redstone_block
setblock -219 44 116 air
setblock -217 41 116 minecraft:redstone_block
setblock -221 41 116 minecraft:redstone_block
setblock -229 44 96 air
setblock -228 41 96 minecraft:redstone_block
setblock -230 41 96 minecraft:redstone_block
setblock -219 44 96 air
setblock -218 41 96 minecraft:redstone_block
setblock -221 41 96 minecraft:redstone_block
setblock -179 25 0 air
setblock -177 26 1 air

setblock -251 35 141 air

setblock -276 78 154 minecraft:dropper[facing=south]
setblock -221 59 165 minecraft:iron_trapdoor[open=true,half=top]
setblock -236 80 90 minecraft:iron_trapdoor[open=false,facing=east] replace

fill -249 35 69 -244 35 69 air
fill -249 35 72 -244 35 72 air
fill -249 35 75 -244 35 75 air
fill -249 35 78 -245 35 78 air
fill -219 81 28 -217 79 28 air
fill -239 39 104 -237 44 104 air replace minecraft:redstone_block
fill -209 47 -8 -207 47 -10 crimson_trapdoor[half=top]
fill -203 37 -19 -205 37 -17 crimson_trapdoor[half=top]
fill -189 43 -4 -187 43 -6 crimson_trapdoor[half=top]
fill -205 41 3 -203 41 1 crimson_trapdoor[half=top]

fill -236 75 83 -236 74 85 minecraft:blast_furnace[facing=east,lit=true] replace minecraft:blast_furnace
fill -152 68 146 -134 68 150 minecraft:spruce_fence_gate[open=false] replace minecraft:spruce_fence_gate

#slime room
fill -234 77 -9 -238 47 -5 air
clone -239 45 94 -235 53 98 -238 69 -9
fill -225 14 142 -227 16 142 lime_stained_glass replace air
fill -237 18 151 -237 18 147 lever[facing=east]
fill -211 15 157 -211 15 161 lever[facing=west]

#bunny structure
fill -271 69 104 -267 73 100 air

#armorer
clone -274 1 116 -275 3 113 -228 74 91
#swordsmith entrance
clone -269 1 116 -270 4 112 -222 72 61
#swordsmith balcony
clone -270 6 116 -270 7 114 -225 77 62
#boss entrance
clone -281 1 114 -283 5 110 -237 72 41
#librarian
clone -306 0 113 -292 3 100 -221 74 21

effect clear @e[type=shulker] glowing
effect clear @a
effect give @a minecraft:regeneration 3 100 false

execute positioned -232.73 74.00 88.94 run kill @e[type=item,distance=..5]
execute positioned -210 80 120 run kill @e[tag=Mob,distance=..500]
execute positioned -191.99 79.90 114.00 run kill @e[type=drowned,distance=..500]
execute positioned -210 80 120 run kill @e[type=minecraft:goat,distance=..500]
execute positioned -237.28 43.52 92.00 run kill @e[type=zombie,distance=..5]
kill @e[type=minecraft:text_display,tag=hint]
kill @e[type=minecraft:experience_orb]
kill @e[type=splash_potion]
kill @e[type=iron_golem]
kill @e[type=minecraft:block_display,tag=Minion]
kill @e[type=minecraft:area_effect_cloud,tag=StoneDecay]
kill @e[type=evoker_fangs]

experience set @a 0 levels
experience set @a 0 points

kill @e[type=interaction,tag=allay]

execute positioned -269 70 102 as @e[type=minecraft:text_display,limit=1,distance=..2] run tp @s 0 0 0
tp 5f9682e6-6f83-4a83-a6b4-a0b361943222 -334.5 55.0 86.5
tp @e[type=minecraft:rabbit,tag=Peppy] -334.5 55.0 86.5 -65 0
tp edc36b2e-5838-4138-8a68-144f6fb6dc54 -225.5 14 140.5 0 0
data merge entity edc36b2e-5838-4138-8a68-144f6fb6dc54 {Sitting:1b,NoAI:1b}
tp ee8dcb0d-5354-43a1-a19b-f5e0be13b4ed -275.5 78 153.2 180 0

kill @e[type=axolotl,tag=Bubbles]
kill @e[type=trident]
summon axolotl -221 59 167 {Invulnerable:1b,PersistenceRequired:1b,NoAI:1b,Variant:4,Rotation:[180F,0F],Tags:["Bubbles"],CustomName:{"bold":true,"color":"blue","italic":false,"text":"Bubbles"}}
team join Companions @e[type=minecraft:axolotl,tag=Bubbles]
summon minecraft:trident -220.5 56.55 154.5 {NoGravity:1b,Fire:0s,UUID:[I; 394187268, -1797634782, -1221224891, 1937751647],pickup:0b,Owner:[I; -892290018, -567786434, -2034976112, 2046951341],life:100s,damage:0d,shake:0b,crit:0b,Motion:[0d,0d,0d],Rotation:[90F,90F],Tags:["Trident"]}
execute as @e[type=minecraft:interaction,tag=Trident] run tp @s -220.5 57.0 154.5

# Villagers #
#swords
function projectswords:summonswordsmith
#cleric
data merge entity a2b887d5-fede-4abd-8662-957bbe3ba81e {Fire:0s,Air:300s,OnGround:1b,Invulnerable:1b,UUID:[I; -317511744, -1116321481, -1557695043, 420794144],PortalCooldown:0,HurtTime:0s,DeathTime:0s,LeftHanded:0b,FallFlying:0b,PersistenceRequired:1b,NoAI:1b,CanPickUpLoot:1b,AbsorptionAmount:0f,Health:20f,LastRestock:0,Xp:50,Age:0,ForcedAge:0,Motion:[0.0d, 0.0d, 0.0d],Rotation:[-180F,35F],Tags:["cleric","illager"],CustomName:[{"bold":true,"color":"dark_purple","italic":false,"obfuscated":false,"strikethrough":false,"text":"[Cleric] ","underlined":false},{"bold":false,"color":"#A85C22","italic":false,"strikethrough":false,"text":"František","underlined":false}],attributes:[{id:"minecraft:movement_speed",base:0.5}],VillagerData:{level:5,profession:"minecraft:cleric",type:"minecraft:taiga"},Offers:{Recipes:[{rewardExp:0b,maxUses:9999,uses:49,xp:1,priceMultiplier:0f,specialPrice:0,demand:0,buy:{id:"minecraft:rotten_flesh",count:4},sell:{id:"minecraft:gold_ingot",count:1}},{rewardExp:0b,maxUses:9999,uses:49,xp:1,priceMultiplier:0f,specialPrice:0,demand:0,buy:{id:"minecraft:cobweb",count:8},sell:{id:"minecraft:gold_ingot",count:1}},{rewardExp:0b,maxUses:9999,uses:0,xp:1,priceMultiplier:0f,specialPrice:0,demand:0,buy:{id:"minecraft:bone",count:4},sell:{id:"minecraft:gold_ingot",count:1}},{rewardExp:0b,maxUses:9999,uses:0,xp:1,priceMultiplier:0f,specialPrice:0,demand:0,buy:{id:"minecraft:spider_eye",count:1},sell:{id:"minecraft:gold_ingot",count:2}},{rewardExp:0b,maxUses:1,uses:0,xp:1,priceMultiplier:0f,specialPrice:0,demand:0,buy:{id:"minecraft:amethyst_shard",components:{"minecraft:enchantments":{"minecraft:protection":1},tooltip_display:{hidden_components:["enchantments"]},"minecraft:custom_name":{"text":"Ethereal Shard","color":"#8B31E6","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},"minecraft:lore":[{"text":"An ancient fragment, said to have divine origins.","color":"#6323A3","bold":false,"italic":true,"underlined":false,"strikethrough":false,"obfuscated":false}]},count:1},sell:{id:"minecraft:tripwire_hook",components:{"minecraft:custom_name":{"text":"Tower Key","color":"dark_aqua","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},"minecraft:custom_data":{tower:1b}},count:1}}]}}

# Reset all chests/armorstands #
#brown house
data modify block -161 74 125 Items set from block -250 1 110 Items
data modify block -159 74 125 Items set from block -250 1 111 Items
data modify block -165 73 121 Items set from block -250 1 112 Items
data modify block -165 73 123 Items set from block -250 1 113 Items
data modify block -162 70 126 Items set from block -250 0 110 Items
data modify block -165 71 125 Items set from block -250 0 111 Items
data modify block -165 68 124 Items set from block -250 0 112 Items
data modify block -165 71 126 Items set from block -250 0 113 Items
data modify block -154 67 126 Items set from block -250 0 114 Items
data modify block -153 73 121 Items set from block -250 0 115 Items
data modify block -165 73 125 Items set from block -250 0 116 Items
#red/green house
data modify block -248 77 140 Items set from block -251 2 118 Items
data modify block -244 77 136 Items set from block -251 1 118 Items
data modify block -247 77 137 Items set from block -252 1 118 Items
data modify block -247 77 138 Items set from block -253 1 118 Items
data modify block -247 78 139 Items set from block -254 1 118 Items
data modify block -247 79 140 Items set from block -255 1 118 Items
data modify block -248 78 140 Items set from block -256 1 118 Items
data modify block -247 78 140 Items set from block -257 1 118 Items
data modify block -249 68 131 Items set from block -251 0 118 Items
data modify block -250 66 140 Items set from block -252 0 118 Items
data modify block -247 65 138 Items set from block -253 0 118 Items
data modify block -247 65 139 Items set from block -254 0 118 Items
data modify block -250 77 132 Items set from block -255 0 118 Items
data modify block -244 79 136 Items set from block -256 0 118 Items
data modify block -244 78 136 Items set from block -257 0 118 Items
#cyan house
data modify block -167 73 162 Items set from block -257 1 94 Items
data modify block -168 73 162 Items set from block -256 1 94 Items
data modify block -167 73 158 Items set from block -255 1 94 Items
data modify block -168 73 158 Items set from block -254 1 94 Items
data modify block -170 79 155 Items set from block -253 1 94 Items
data modify block -174 79 155 Items set from block -252 1 94 Items
data modify block -171 76 155 Items set from block -251 1 94 Items
data modify block -173 68 161 Items set from block -257 0 94 Items
data modify block -174 73 161 Items set from block -256 0 94 Items
data modify block -174 73 160 Items set from block -255 0 94 Items
data modify block -174 73 159 Items set from block -254 0 94 Items
data modify block -174 74 159 Items set from block -253 0 94 Items
data modify block -173 76 155 Items set from block -252 0 94 Items
data modify block -172 76 155 Items set from block -251 0 94 Items
#swordsmith
data modify block -230 83 59 Items set from block -258 3 102 Items
data modify block -230 84 59 Items set from block -258 3 101 Items
data modify block -229 83 59 Items set from block -258 3 100 Items
data modify block -229 83 58 Items set from block -258 3 99 Items
data modify block -226 77 60 Items set from block -258 3 98 Items
data modify block -230 79 59 Items set from block -258 2 102 Items
data modify block -231 81 59 Items set from block -258 2 101 Items
data modify block -230 81 59 Items set from block -258 2 100 Items
data modify block -232 83 60 Items set from block -258 2 99 Items
data modify block -232 84 59 Items set from block -258 2 98 Items
data modify block -231 83 60 Items set from block -258 2 97 Items
data modify block -231 83 59 Items set from block -258 2 96 Items
data modify block -228 74 58 Items set from block -258 1 102 Items
data modify block -229 75 58 Items set from block -258 1 101 Items
data modify block -228 75 58 Items set from block -258 1 100 Items
data modify block -231 77 62 Items set from block -258 1 99 Items
data modify block -231 77 61 Items set from block -258 1 98 Items
data modify block -231 78 61 Items set from block -258 1 97 Items
data modify block -231 79 59 Items set from block -258 1 96 Items
data modify block -233 73 65 Items set from block -258 0 102 Items
data modify block -233 73 63 Items set from block -258 0 101 Items
data modify block -234 74 62 Items set from block -258 0 100 Items
data modify block -234 73 62 Items set from block -258 0 99 Items
data modify block -234 73 60 Items set from block -258 0 98 Items
data modify block -235 74 64 Items set from block -258 0 97 Items
data modify block -229 74 58 Items set from block -258 0 96 Items
#armorer
data modify block -226 77 85 Items set from block -249 1 96 Items
data modify block -226 74 83 Items set from block -249 1 97 Items
data modify block -226 74 84 Items set from block -249 1 98 Items
data modify block -228 74 85 Items set from block -249 1 99 Items
data modify block -226 74 85 Items set from block -249 1 100 Items
data modify block -228 77 85 Items set from block -249 1 101 Items
data modify block -228 76 83 Items set from block -249 1 102 Items
data modify block -231 81 87 Items set from block -249 0 96 Items
data modify block -236 76 85 Items set from block -249 0 97 Items
data modify block -236 76 84 Items set from block -249 0 98 Items
data modify block -226 75 83 Items set from block -249 0 99 Items
data modify block -226 75 84 Items set from block -249 0 100 Items
data modify block -226 75 85 Items set from block -249 0 101 Items
data modify block -227 74 83 Items set from block -249 0 102 Items
#butcher
data modify block -190 72 143 Items set from block -259 0 110 Items
data modify block -190 72 142 Items set from block -259 0 111 Items
data modify block -188 75 141 Items set from block -259 0 113 Items
data modify block -188 75 140 Items set from block -259 0 114 Items
data modify block -188 76 141 Items set from block -259 1 113 Items
data modify block -188 76 140 Items set from block -259 1 114 Items
data modify block -190 70 141 Items set from block -259 0 115 Items
data modify block -190 70 140 Items set from block -259 0 116 Items
#farm
data modify block -154 69 172 Items set from block -267 0 102 Items
data modify block -154 70 173 Items set from block -267 0 101 Items
data modify block -149 69 164 Items set from block -267 0 100 Items
data modify block -148 69 163 Items set from block -267 0 99 Items
data modify block -148 69 162 Items set from block -267 0 98 Items
data modify block -147 68 143 Items set from block -267 0 97 Items
data modify block -145 68 154 Items set from block -267 0 96 Items
data modify block -135 68 142 Items set from block -267 1 96 Items
#yellow house
data modify block -180 80 86 Items set from block -266 0 94 Items
data modify block -180 80 83 Items set from block -265 0 94 Items
data modify block -180 77 85 Items set from block -264 0 94 Items
data modify block -180 77 86 Items set from block -263 0 94 Items
data modify block -187 80 79 Items set from block -262 0 94 Items
data modify block -181 82 79 Items set from block -261 0 94 Items
#fisher hut
data modify block -226 63 153 Items set from block -260 2 118 Items
data modify block -240 64 158 Items set from block -261 2 118 Items
data modify block -242 63 158 Items set from block -260 1 118 Items
data modify block -242 63 157 Items set from block -261 1 118 Items
data modify block -242 63 155 Items set from block -262 1 118 Items
data modify block -242 63 154 Items set from block -263 1 118 Items
data modify block -242 64 154 Items set from block -264 1 118 Items
data modify block -242 63 153 Items set from block -265 1 118 Items
data modify block -243 63 155 Items set from block -266 1 118 Items
data modify block -232 63 159 Items set from block -260 0 118 Items
data modify block -232 63 158 Items set from block -261 0 118 Items
data modify block -232 64 158 Items set from block -262 0 118 Items
data modify block -231 63 158 Items set from block -263 0 118 Items
data modify block -232 63 156 Items set from block -264 0 118 Items
data modify block -239 63 158 Items set from block -265 0 118 Items
data modify block -226 63 152 Items set from block -266 0 118 Items
data modify block -240 63 157 Items set from block -262 2 118 Items
#purple house
data modify block -248 84 116 Items set from block -267 3 110 Items
data modify block -242 82 114 Items set from block -267 2 116 Items
data modify block -239 82 116 Items set from block -267 2 115 Items
data modify block -238 84 116 Items set from block -267 2 114 Items
data modify block -239 82 117 Items set from block -267 2 113 Items
data modify block -247 82 116 Items set from block -267 2 112 Items
data modify block -248 83 116 Items set from block -267 2 111 Items
data modify block -238 83 116 Items set from block -267 2 110 Items
data modify block -242 77 111 Items set from block -267 1 116 Items
data modify block -242 78 111 Items set from block -267 1 115 Items
data modify block -242 79 111 Items set from block -267 1 114 Items
data modify block -244 81 111 Items set from block -267 1 113 Items
data modify block -244 82 111 Items set from block -267 1 112 Items
data modify block -244 82 113 Items set from block -267 1 111 Items
data modify block -244 82 114 Items set from block -267 1 110 Items
data modify block -247 72 115 Items set from block -267 0 116 Items
data modify block -247 72 114 Items set from block -267 0 115 Items
data modify block -247 70 111 Items set from block -267 0 114 Items
data modify block -239 70 113 Items set from block -267 0 113 Items
data modify block -239 70 115 Items set from block -267 0 112 Items
data modify block -242 76 116 Items set from block -267 0 111 Items
data modify block -244 76 116 Items set from block -267 0 110 Items
#mason
data modify block -196 92 58 Items set from block -275 3 94 Items
data modify block -197 89 57 Items set from block -274 3 94 Items
data modify block -197 90 58 Items set from block -273 3 94 Items
data modify block -195 89 52 Items set from block -275 2 94 Items
data modify block -195 89 56 Items set from block -274 2 94 Items
data modify block -195 89 57 Items set from block -273 2 94 Items
data modify block -195 90 58 Items set from block -272 2 94 Items
data modify block -196 89 57 Items set from block -271 2 94 Items
data modify block -196 90 57 Items set from block -270 2 94 Items
data modify block -196 91 58 Items set from block -269 2 94 Items
data modify block -197 89 50 Items set from block -275 1 94 Items
data modify block -197 89 49 Items set from block -274 1 94 Items
data modify block -196 89 50 Items set from block -273 1 94 Items
data modify block -196 90 49 Items set from block -272 1 94 Items
data modify block -196 91 49 Items set from block -271 1 94 Items
data modify block -195 89 51 Items set from block -270 1 94 Items
data modify block -195 90 50 Items set from block -269 1 94 Items
data modify block -197 89 51 Items set from block -269 0 94 Items
data modify block -193 84 54 Items set from block -270 0 94 Items
data modify block -193 84 50 Items set from block -271 0 94 Items
data modify block -199 84 50 Items set from block -272 0 94 Items
data modify block -199 84 54 Items set from block -273 0 94 Items
data modify block -199 73 47 Items set from block -274 0 94 Items
data modify block -203 73 49 Items set from block -275 0 94 Items
#secrets
data modify block -229 36 153 Items set from block -268 2 96 Items
data modify block -222 33 182 Items set from block -268 2 97 Items
data modify block -225 20 142 Items set from block -268 2 98 Items
data modify block -189 69 246 Items set from block -268 1 96 Items
data modify block -193 63 245 Items set from block -268 1 97 Items
data modify block -309 54 74 Items set from block -268 0 96 Items
data modify block -347 61 80 Items set from block -268 0 97 Items
data modify block -292 59 125 Items set from block -268 0 98 Items
data modify block -305 39 123 Items set from block -268 0 99 Items
data modify block -284 63 109 Items set from block -268 0 100 Items
data modify block -314 57 153 Items set from block -268 0 101 Items
#shops
data modify block -189 65 125 Items set from block -258 0 113 Items
data modify block -190 65 125 Items set from block -258 0 112 Items
data modify block -191 65 125 Items set from block -258 0 111 Items
#others
data modify block -180 102 220 Items set from block -280 0 117 Items
data modify block -278 87 150 Items set from block -283 0 117 Items
data modify block -180 67 233 Items set from block -285 0 116 Items
data modify block -210 63 202 Items set from block -285 0 114 Items
data modify block -192 63 113 Items set from block -285 0 112 Items
data modify block -236 56 157 Items set from block -285 0 110 Items
data modify block -256 45 -2 Items set from block -283 2 117 Items
#armorer-stands
data modify entity 7ab5f81c-432b-48e8-87bc-1a451c98c5e5 equipment set from entity 04443910-5243-4432-959a-35db783aa8ab equipment
data modify entity d0b6b485-0bb3-4026-bf36-8a54f88029ec equipment set from entity dc335d91-4e46-45da-b365-6a2216a3c9b4 equipment
data modify entity 7fc83316-990a-4e52-b71c-4fbcce6f4837 equipment set from entity 7942f596-89b4-4bbb-8f63-d3239167107b equipment
data modify entity 360b847d-2c0b-4de9-af71-c9a2a093553e equipment set from entity 67687983-b663-4775-970e-9dc3d78a0c99 equipment
#r/g stands
data modify entity 250cfa06-3cbb-40b2-ba8c-a808799ceea0 equipment set from entity f5684a5e-47cd-4366-bff2-451660f9727e equipment
data modify entity 22442f4e-80cb-4ec8-99f5-160bb9d1cf0f equipment set from entity bfecf16c-f6cd-4e1f-ab7f-81b35ee17e40 equipment
#yellow stand
data modify entity 8a43182a-ed48-41ac-afd4-e522a936867e equipment set from entity c471c34f-e1f4-4b17-b60f-4c0f07e8eee0 equipment
#cyan stand
data modify entity 4cd0f127-6ab6-45f9-840e-ccc3385349ff equipment set from entity d022aa93-ec02-41f6-9c5d-0f60527aea44 equipment
#red stand
data modify entity 111c2c62-cc66-4303-be40-4f24dd618143 equipment set from entity 50978554-922b-4c5d-abc9-1bec537a6f47 equipment
#green stand
data modify entity 52f4b3c0-87cf-4f79-b6fe-ab214cf72c4d equipment set from entity bf0b3ca2-1750-4ab9-81be-1ab2c70c2cf6 equipment
#purple stand
data modify entity 0c6a3e19-8434-4cd0-8af5-e0558aa1bc8a equipment set from entity a1289a8d-c24c-4e87-9c98-7fcf49a23630 equipment
#brown stand
data modify entity cefd8eba-f76a-47b3-b43c-6f0ff7e39e67 equipment set from entity 42862ffd-2d77-415a-8bec-9ce1efbc57dd equipment
data modify entity cefd8eba-f76a-47b3-b43c-6f0ff7e39e67 equipment set from entity 42862ffd-2d77-415a-8bec-9ce1efbc57dd equipment
#swordsmith stands
data modify entity 228488f0-41c5-40c0-9f2f-7f857f6c2b60 equipment set from entity a105a81e-e5d8-4d68-90be-8af0fca43b47 equipment
data modify entity 228488f0-41c5-40c0-9f2f-7f857f6c2b60 equipment set from entity a105a81e-e5d8-4d68-90be-8af0fca43b47 equipment
data modify entity 359c8325-1c6b-4a52-8e33-fe650850dc36 equipment set from entity af9532c7-0457-4c48-b6b5-61a354ee7d09 equipment
#mason stands
data modify entity 4dacc600-ba13-4dc1-9303-0313bae7cd6b equipment set from entity 7fee858e-df21-4c05-9bf3-aadefb87f75c equipment
data modify entity 0ad05dd0-dd61-4466-8a9d-9d8132d4aaf7 equipment set from entity 6334ce7b-4328-4081-8fb3-7ee687ab9061 equipment
data modify entity c6b903b9-37ec-4f33-8a47-78c215f839a2 equipment set from entity a250e645-7d4f-48f0-8d0f-1b8d7a8a3e5d equipment
data modify entity b1c27995-0cc4-4929-a081-e9aeceb2fc8f equipment set from entity d79a6422-9fe8-4af6-bbe8-6cd3ae2f03e0 equipment
#other stands
data modify entity 1b2d0fd5-38b8-4808-b812-8b77c8d18baa equipment set from entity 32ab8fe7-0d0a-47fc-841a-08d56985b87d equipment
data modify entity 1b2d0fd5-38b8-4808-b812-8b77c8d18baa equipment set from entity 32ab8fe7-0d0a-47fc-841a-08d56985b87d equipment

# Farm #
fill -157 72 191 -128 70 160 wheat replace air
fill -157 72 191 -128 70 160 wheat replace wheat
fill -157 72 191 -128 70 160 wheat replace potatoes
fill -157 72 191 -128 70 160 wheat replace carrots
fill -157 72 191 -128 70 160 wheat replace beetroots

# Horsies #
tp 3bed0ddc-bc9c-4b32-91e7-e9f482402922 -151 71 143
tp 569be37e-76db-4ab2-92d8-8c3311b19164 -145 71 144
tp 030eda3b-9364-4c46-9fdf-cae5ec82aac9 -141 71 144
tp a1e6552e-d3bb-4bea-af6b-7b815d92a860 -135 71 144
tp 9f851ad5-d9e9-4a50-9d0e-9724b2fc50b8 -150 71 152
tp 65b1bb3a-f20f-4468-ad2e-95655a57f255 -145 71 152
tp 3652af54-5dc8-4d8e-aeb5-ef9f04d8c0df -141 71 152
tp 0a1d6f83-3e42-41f1-bc34-e744b3c9c75e -136 71 152
execute as @e[type=horse,team=Villager] run data merge entity @s {Tame:0b,NoAI:0b}

#KEEP ON BOTTOM#
tag @a remove tp.ran.villagers
kill @e[type=item]
tag @a add setup
tag @a remove day0
tag @a remove housetp
scoreboard objectives setdisplay sidebar
gamerule doDaylightCycle false
gamerule doMobLoot true
clear @a[tag=!dev]
gamemode adventure @a