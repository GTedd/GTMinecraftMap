effect give @s minecraft:strength 30 1 false
tellraw @s [{"text":"You feel empowered by ","color":"gold","italic":true},{"text":"Bubbles","color":"blue","bold":true,"italic":true},{"bold":false,"text":"!","color":"gold","italic":true}]
playsound minecraft:entity.axolotl.idle_water master @s ~ ~ ~ 5 2
tag @s add axolotl.buffed