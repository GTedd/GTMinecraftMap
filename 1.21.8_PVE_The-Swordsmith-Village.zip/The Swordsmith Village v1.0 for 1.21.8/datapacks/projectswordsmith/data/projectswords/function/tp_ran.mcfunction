fill -219 81 28 -217 79 28 barrier
tp @a -217.5 79 27.7
tp @s ~ ~ ~ 90 0
tag @s add tpran1