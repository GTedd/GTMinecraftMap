execute if entity @s[tag=easy_difficulty,team=Villager] at @s run playsound minecraft:entity.evoker.prepare_summon master @s ~ ~ ~ 2 1.8
execute if entity @s[tag=easy_difficulty,team=Villager] at @s run particle minecraft:witch ~ ~ ~ 0.3 3 0.3 1 30 normal
execute if entity @s[tag=easy_difficulty,team=Villager] at @s run particle minecraft:warped_spore ~ ~ ~ 0.3 3 0.3 1 50 normal

execute if entity @s[tag=!easy_difficulty] run tag @s add dead_spectator
execute if entity @s[tag=!easy_difficulty,team=!Spectator] run gamemode spectator @s
execute if entity @s[tag=!easy_difficulty,team=!Spectator] run spectate @a[gamemode=!spectator,sort=random,limit=1]
execute if entity @s[tag=normal_difficulty] run scoreboard players set @s death.timer 200
execute if entity @s[tag=hard_difficulty] run scoreboard players set @s death.timer 200