recipe give @s projectswords:gold
execute at @s run playsound minecraft:entity.arrow.hit_player master @s ~ ~ ~ 0.5 0.6
tag @s add recipe.gold