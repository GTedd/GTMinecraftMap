
scoreboard players add @s damageTaken.real 1
scoreboard players remove @s damageTaken 10