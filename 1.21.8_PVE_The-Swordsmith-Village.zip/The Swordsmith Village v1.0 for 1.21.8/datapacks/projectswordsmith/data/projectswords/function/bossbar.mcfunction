execute store result bossbar minecraft:stone value run data get entity @e[distance=..100,type=ghast,tag=Boss,limit=1] Health
execute if entity @e[distance=..100,type=ghast,tag=Boss] run bossbar set minecraft:stone players @a
execute unless entity @e[distance=..100,type=ghast,tag=Boss] run bossbar set minecraft:stone players
bossbar set minecraft:stone name [{"text":"[The Stone] ","color":"dark_gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"score":{"name":"@e[type=ghast,tag=Boss]","objective":"health"},"color":"red","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"bold":false,"text":"❤","color":"#FF2448"}]
execute as @e[distance=..100,type=ghast,tag=Boss] store result score @s health run data get entity @s Health
bossbar set minecraft:stone max 500