effect give @s minecraft:invisibility infinite 0 false
data merge entity @s {DeathLootTable:"projectswords:loot_table_magma"}
tag @s add Mob
tag @s add fixed