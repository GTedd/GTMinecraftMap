tp @s ^ ^ ^0.2 facing entity @p[team=!Spectator,tag=magnetic]
execute unless entity @p[team=!Spectator,limit=1,distance=..1,sort=nearest,tag=!magnetic] run data merge entity @s {NoGravity:0b}
execute if entity @a[limit=1,distance=..2,sort=nearest,tag=magnetic] run data merge entity @s {PickupDelay:1}