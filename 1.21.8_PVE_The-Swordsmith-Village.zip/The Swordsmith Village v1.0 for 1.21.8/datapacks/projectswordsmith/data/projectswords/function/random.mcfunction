# scoreboard #
scoreboard players add dummy random 1
execute if score players difficulty matches 1 if score dummy random matches 1600.. run scoreboard players set dummy random 0
execute if score players difficulty matches 2 if score dummy random matches 1200.. run scoreboard players set dummy random 0
execute if score players difficulty matches 3 if score dummy random matches 800.. run scoreboard players set dummy random 0
execute if score players difficulty matches 4.. if score dummy random matches 410.. run scoreboard players set dummy random 0

# random value #
execute as @r store result score #random random run random value 1..4

# leathertier #
execute as @a[tag=leathertier,tag=!chainmailtier] if score dummy random matches 399 if score #random random matches 1 run setblock -228 63 64 minecraft:redstone_block
execute as @a[tag=leathertier,tag=!chainmailtier] if score dummy random matches 399 if score #random random matches 2 run setblock -224 63 64 minecraft:redstone_block
execute as @a[tag=leathertier,tag=!chainmailtier] if score dummy random matches 399 if score #random random matches 3 run setblock -220 63 64 minecraft:redstone_block
execute as @a[tag=leathertier,tag=!chainmailtier] if score dummy random matches 399 if score #random random matches 4 run setblock -216 63 64 minecraft:redstone_block

# chainmailtier #
execute as @a[tag=chainmailtier,tag=!irontier] if score dummy random matches 399 if score #random random matches 1 run setblock -228 63 56 minecraft:redstone_block
execute as @a[tag=chainmailtier,tag=!irontier] if score dummy random matches 399 if score #random random matches 2 run setblock -224 63 56 minecraft:redstone_block
execute as @a[tag=chainmailtier,tag=!irontier] if score dummy random matches 399 if score #random random matches 3 run setblock -220 63 56 minecraft:redstone_block
execute as @a[tag=chainmailtier,tag=!irontier] if score dummy random matches 399 if score #random random matches 4 run setblock -216 63 56 minecraft:redstone_block

# irontier #
execute as @a[tag=irontier,tag=!diamondtier] if score dummy random matches 399 if score #random random matches 1 run setblock -224 63 60 minecraft:redstone_block
execute as @a[tag=irontier,tag=!diamondtier] if score dummy random matches 399 if score #random random matches 2 run setblock -228 63 60 minecraft:redstone_block
execute as @a[tag=irontier,tag=!diamondtier] if score dummy random matches 399 if score #random random matches 3 run setblock -220 63 60 minecraft:redstone_block
execute as @a[tag=irontier,tag=!diamondtier] if score dummy random matches 399 if score #random random matches 4 run setblock -216 63 60 minecraft:redstone_block

# diamondtier #
execute as @a[tag=diamondtier,tag=!diamondbtier] if score dummy random matches 399 if score #random random matches 1 run setblock -228 63 52 minecraft:redstone_block
execute as @a[tag=diamondtier,tag=!diamondbtier] if score dummy random matches 399 if score #random random matches 2 run setblock -224 63 52 minecraft:redstone_block
execute as @a[tag=diamondtier,tag=!diamondbtier] if score dummy random matches 399 if score #random random matches 3 run setblock -220 63 52 minecraft:redstone_block
execute as @a[tag=diamondtier,tag=!diamondbtier] if score dummy random matches 399 if score #random random matches 4 run setblock -216 63 52 minecraft:redstone_block

# diamondbtier #
execute as @a[tag=diamondbtier] if score dummy random matches 399 if score #random random matches 1 run setblock -228 63 48 minecraft:redstone_block
execute as @a[tag=diamondbtier] if score dummy random matches 399 if score #random random matches 2 run setblock -224 63 48 minecraft:redstone_block
execute as @a[tag=diamondbtier] if score dummy random matches 399 if score #random random matches 3 run setblock -220 63 48 minecraft:redstone_block
execute as @a[tag=diamondbtier] if score dummy random matches 399 if score #random random matches 4 run setblock -216 63 48 minecraft:redstone_block
