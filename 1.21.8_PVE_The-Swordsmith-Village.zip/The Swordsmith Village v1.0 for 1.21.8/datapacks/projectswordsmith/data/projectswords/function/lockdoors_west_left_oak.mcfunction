# setblocks
setblock ~ ~ ~ minecraft:air replace
setblock ~ ~ ~ minecraft:oak_door[hinge=left,open=false,facing=west,half=upper]
setblock ~ ~-1 ~ minecraft:oak_door[hinge=left,open=false,facing=west,half=lower]

# tellraw
execute if score dummy nighttimer matches ..9995 run tellraw @p[team=!Spectator] [{"text":"Doors are locked during nightime.","color":"yellow"}]

# kills
kill @e[distance=..5,type=item,nbt={Item:{id:"minecraft:oak_door"}}]
