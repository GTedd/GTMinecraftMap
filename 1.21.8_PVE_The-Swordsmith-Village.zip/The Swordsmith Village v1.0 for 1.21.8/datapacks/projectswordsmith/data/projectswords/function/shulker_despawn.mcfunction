data merge entity @s {Glowing:0b}
tp @s -250 37 132
kill @s