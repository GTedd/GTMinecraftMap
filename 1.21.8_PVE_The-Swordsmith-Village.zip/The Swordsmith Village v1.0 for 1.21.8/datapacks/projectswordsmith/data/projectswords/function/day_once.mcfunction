#tags
tag @a add setup
#bossbars
bossbar set minecraft:daytimer max 939
#gamerules
gamerule doMobLoot false
gamerule doDaylightCycle false

#farmer#
tp 5f6b174e-d917-432d-b936-19eaaefff8d9 -147.5 70 170 74 3
#elder#
tp 6289716a-679f-4ddf-b3dd-c185e197726c -255.5 65 183.5 -134 9
#cleric#
tp a2b887d5-fede-4abd-8662-957bbe3ba81e -275.5 68 170.5 -180 35
#enchanter#
tp 6df83f08-d164-49b2-8c8b-95395d17e0cf -275.5 88 156.5 -180 8.5
#butcher#
tp df3701e7-1305-4600-bd3d-8632e97b1653 -181.9 75 147.5 90 0
#fisherman#
tp cc7c202c-7e8d-4f92-9272-f6421091a3ae -236.5 63 156.8 0.4 26
#armorer#
tp a6331fcd-5172-4df7-ae12-73cc5eb5402e -233.9 80 87.3 -65.5 39.2
#mason#
tp 84dbcb45-052f-45d5-83d2-20690b218504 -197.3 78 51.5 90 28
#fletcher#
tp a5f818a2-9e88-40f4-9178-47d63ef5dba6 -196.6 78 54.5 90 18
#swordsmith-apprentice#
tp 29344ae4-8b41-42e5-84a0-4f1cffcb7b94 -230 77 62.5 90 22
#swordsmith-master#
tp 26d6176b-0201-4c9e-a80b-d46300ae7d9a -230.5 72 59.5 180 30
#librarian#
tp 112eb2d8-5d51-4122-804f-bc618a4cf1b8 -209.7 79.5 23.5 90 35
#scammer#
tp 59834455-09a2-4621-8891-aaddb8e2fef9 -202.0 66 123.3 -180 5
#shopkeeper#
tp fcc42dd6-4cbf-47ea-b6cc-670ae78da842 -176.5 66 109.0 90 5
#miner#
tp 975bcf8a-1e63-4396-ad99-d31de7b93a0d -174.5 69 61.5 -50 12
#retailer#
tp ee10b048-41ae-4d69-ad3e-e66595a73e6f -176.5 66 98.5 90 5
#bartender#
tp 58f3ab16-0a61-4cd1-9e0e-e350fe0e6dd2 -187.0 65 125.5 -180 5