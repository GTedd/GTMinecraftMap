effect give @s minecraft:blindness 3 0 false
advancement revoke @s only projectswords:fangs