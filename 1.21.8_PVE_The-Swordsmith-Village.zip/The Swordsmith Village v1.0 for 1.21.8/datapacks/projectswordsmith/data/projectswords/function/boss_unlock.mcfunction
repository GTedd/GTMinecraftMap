bossbar set minecraft:preboss players
tp @a -230.0 74 47.0 120 8
time set midnight
tag @a add night
schedule function projectswords:gates/1 2s
execute as @a run tellraw @s [{"text":"<","color":"white"},{"selector":"@s"},{"text":">","color":"white"},{"text":" Alright, I think I'm all ready. As ","color":"gray"},{"text":"Kacper ","color":"white"},{"text":"said, I gotta head into the underground and defeat some ","color":"gray"},{"text":"Golem","color":"gold"},{"text":" creature...","color":"gray"}]
tag @a add boss.unlocked
