execute positioned -320 70 100 as @e[distance=..100,type=arrow] run kill @s

execute if entity @s[tag=target.1,tag=!target.2] run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.6
execute if entity @s[tag=target.2,tag=!target.3] run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.7
execute if entity @s[tag=target.3,tag=!target.4] run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.8
execute if entity @s[tag=target.4,tag=!target.5] run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 1.9
execute if entity @s[tag=target.5,tag=!target.solved] run playsound minecraft:block.note_block.chime master @s ~ ~ ~ 1 2

execute as @a[tag=target.1] run tag @s add sound.1
execute as @a[tag=target.2] run tag @s add sound.2
execute as @a[tag=target.3] run tag @s add sound.3
execute as @a[tag=target.4] run tag @s add sound.4