# setblocks
setblock -298 69 97 air
setblock -298 69 97 target[power=0]

setblock -313 68 86 air
setblock -313 68 86 target[power=0]

setblock -320 64 131 air
setblock -320 64 131 target[power=0]

setblock -332 68 92 air
setblock -332 68 92 target[power=0]

setblock -327 67 109 air
setblock -327 67 109 target[power=0]
