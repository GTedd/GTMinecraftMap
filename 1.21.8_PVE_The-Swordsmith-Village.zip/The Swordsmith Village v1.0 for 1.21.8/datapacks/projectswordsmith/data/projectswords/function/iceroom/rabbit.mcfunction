setblock -253 35 80 minecraft:redstone_block
tellraw @a [{"text":"Peppy","color":"red"},{"text":" has joined the party!","color":"yellow"}]
tellraw @a [{"text":"<Peppy>","color":"#FF474C"},{"text":" *squeak* *squeak* *squeak* (thank u!! me gib reward!!! meet at entrance of cave!)","color":"white"}]
clone -274 1 101 -270 5 97 -271 69 100
execute positioned -334.5 55.0 86.5 run tp @e[distance=..5,type=minecraft:rabbit,tag=Peppy] -269 70 102 0 0
execute positioned -334.5 55.0 86.5 run tp 5f9682e6-6f83-4a83-a6b4-a0b361943222 -269 70 102
playsound minecraft:entity.enderman.teleport master @a ~ ~ ~ 2 1.5
tag @a add rabbit.unlocked
data remove entity @s interaction