execute as @a[tag=!target.1] run function projectswords:iceroom/reset
execute unless block -298 69 97 minecraft:target[power=0] run tag @a add target.1
execute as @a[tag=target.1,tag=!target.2] unless block -298 69 97 minecraft:target[power=0] run function projectswords:iceroom/targets
execute as @a[tag=target.1,tag=!target.2] run function projectswords:iceroom/target_1
execute as @a[tag=target.1,tag=!sound.1] as @a[tag=in.iceroom] at @s run function projectswords:iceroom/sounds

execute unless block -313 68 86 minecraft:target[power=0] run tag @a[tag=target.1] add target.2
execute as @a[tag=target.2,tag=!target.3] unless block -313 68 86 minecraft:target[power=0] run function projectswords:iceroom/targets
execute as @a[tag=target.2,tag=!target.3] run function projectswords:iceroom/target_2
execute as @a[tag=target.2,tag=!sound.2] as @a[tag=in.iceroom] at @s run function projectswords:iceroom/sounds

execute unless block -320 64 131 minecraft:target[power=0] run tag @a[tag=target.2] add target.3
execute as @a[tag=target.3,tag=!target.4] unless block -320 64 131 minecraft:target[power=0] run function projectswords:iceroom/targets
execute as @a[tag=target.3,tag=!target.4] run function projectswords:iceroom/target_3
execute as @a[tag=target.3,tag=!sound.3] as @a[tag=in.iceroom] at @s run function projectswords:iceroom/sounds

execute unless block -332 68 92 minecraft:target[power=0] run tag @a[tag=target.3] add target.4
execute as @a[tag=target.4,tag=!target.5] unless block -332 68 92 minecraft:target[power=0] run function projectswords:iceroom/targets
execute as @a[tag=target.4,tag=!target.5] run function projectswords:iceroom/target_4
execute as @a[tag=target.4,tag=!sound.4] as @a[tag=in.iceroom] at @s run function projectswords:iceroom/sounds

execute unless block -327 67 109 minecraft:target[power=0] run tag @a[tag=target.4] add target.5
execute as @a[tag=target.5,tag=!target.solved] unless block -327 67 109 minecraft:target[power=0] run function projectswords:iceroom/targets
execute as @p[team=!Spectator,limit=1,tag=target.5,tag=!target.solved] run function projectswords:iceroom/target_5

# Buttons #
#1
execute if block -303 66 98 minecraft:warped_button[powered=true] run tellraw @s {"color":"aqua","text":"1"}
execute if block -303 66 98 minecraft:warped_button[powered=true] run setblock -303 66 98 minecraft:warped_button[facing=south,face=floor] replace

#2
execute if block -321 63 87 minecraft:warped_button[powered=true] run tellraw @s {"color":"aqua","text":"2"}
execute if block -321 63 87 minecraft:warped_button[powered=true] run setblock -321 63 87 minecraft:warped_button[facing=south,face=floor] replace

#3
execute if block -322 56 128 minecraft:warped_button[powered=true] run tellraw @s {"color":"aqua","text":"3"}
execute if block -322 56 128 minecraft:warped_button[powered=true] run setblock -322 56 128 minecraft:warped_button[facing=south,face=floor] replace

#4
execute if block -331 61 101 minecraft:warped_button[powered=true] run tellraw @s {"color":"aqua","text":"4"}
execute if block -331 61 101 minecraft:warped_button[powered=true] run setblock -331 61 101 minecraft:warped_button[facing=south,face=floor] replace

#5
execute if block -307 60 120 minecraft:warped_button[powered=true] run tellraw @s {"color":"aqua","text":"5"}
execute if block -307 60 120 minecraft:warped_button[powered=true] run setblock -307 60 120 minecraft:warped_button[facing=south,face=floor] replace