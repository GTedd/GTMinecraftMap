give @s golden_carrot[custom_name={"color":"gold","italic":false,"text":"The Legendary Carrot"},lore=[{"color":"gray","text":"A Gourmet carrot that is guaranteed to bring fortune."}]] 1
execute as @a[tag=in.iceroom] at @s run playsound minecraft:entity.player.levelup master @s ~ ~ ~ 2 2
tag @s add target.solved