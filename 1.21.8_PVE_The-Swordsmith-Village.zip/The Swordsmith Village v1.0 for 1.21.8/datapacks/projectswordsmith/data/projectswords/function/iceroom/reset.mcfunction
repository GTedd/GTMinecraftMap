tag @s remove target.2
tag @s remove target.3
tag @s remove target.4
tag @s remove target.5

tag @s remove sound.1
tag @s remove sound.2
tag @s remove sound.3
tag @s remove sound.4