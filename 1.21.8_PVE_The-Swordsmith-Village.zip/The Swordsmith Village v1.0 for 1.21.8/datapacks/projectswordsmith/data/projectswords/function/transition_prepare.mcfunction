scoreboard objectives add transition dummy
execute unless score prepare transition matches 1200.. run scoreboard players add prepare transition 1
execute if score prepare transition matches 1 run fill -215 74 35 -213 77 35 air
execute if score prepare transition matches 1 run time set 23000
execute if score prepare transition matches 1 run bossbar set minecraft:prepare players @a
execute if score prepare transition matches 1 run tp 112eb2d8-5d51-4122-804f-bc618a4cf1b8 -209.7 79.5 23.5 90 35
execute if score prepare transition matches 1.. positioned -213 79 23 as @p[team=!Spectator,distance=..2] run tag @e[distance=..10,type=minecraft:villager,tag=librarian] add expedition
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 if entity @s[tag=expedition,tag=!expedition.ran] at @s run tellraw @a[distance=..20] [{"text":"<","color":"white"},{"selector":"@s"},{"text":">","color":"white"},{"text":" Hello! ","color":"gray"},{"selector":"@p[team=!Spectator]"},{"text":"! Truly an outstanding job out there! I mean, you slayed all those monsters with ease! Well, anyways, you have one final job: to go on an expedition to the ","color":"gray"},{"text":"Great Underground","color":"gold"},{"text":". There, you must find the ","color":"gray"},{"text":"Golem","color":"gold"},{"text":" that has been causing these attacks and defeat it. For now, go gear up and prepare for tonight.","color":"gray"}]
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 if entity @s[tag=expedition,tag=!expedition.ran] run bossbar set minecraft:daytimer players
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 if entity @s[tag=expedition,tag=!expedition.ran] run bossbar set minecraft:prepare players
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 if entity @s[tag=expedition,tag=!expedition.ran] run bossbar set minecraft:preboss players @a
execute as 112eb2d8-5d51-4122-804f-bc618a4cf1b8 if entity @s[tag=expedition] run tag @s add expedition.ran
execute if score prepare transition matches 100 run time set 23050
execute if score prepare transition matches 200 run time set 23100
execute if score prepare transition matches 300 run time set 23150
execute if score prepare transition matches 400 run time set 23200
execute if score prepare transition matches 500 run time set 23250
execute if score prepare transition matches 600 run time set 23300
execute if score prepare transition matches 700 run time set 23350
execute if score prepare transition matches 800 run time set 23400
execute if score prepare transition matches 900 run time set 23450
execute if score prepare transition matches 1000 run time set 23500
execute if score prepare transition matches 1100 run time set 23550
execute if score prepare transition matches 1200 run time set 23600

gamerule doDaylightCycle false
tag @s remove nightbar
tag @s remove daybar