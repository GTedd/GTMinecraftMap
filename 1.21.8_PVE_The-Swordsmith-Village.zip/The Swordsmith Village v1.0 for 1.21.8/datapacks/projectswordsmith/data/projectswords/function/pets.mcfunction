summon wolf -6 102 -6 {NoAI:0b,variant:"snowy",CustomName:{"color":"red","text":"Tommy"},Invulnerable:1b,PersistenceRequired:1b,Sitting:0b,CollarColor:14b,Tags:["Pet"]}
summon cat -6 102 6 {CustomName:{"color":"red","text":"Pommy"},Invulnerable:1b,PersistenceRequired:1b,NoAI:0b,Sitting:0b,variant:"minecraft:all_black",CollarColor:14b,Tags:["Pet"]}
playsound minecraft:entity.player.levelup master @a ~ ~ ~ 2 2
setblock -6 101 6 minecraft:diamond_block
setblock -6 101 -6 minecraft:diamond_block
setblock 0 117 0 air