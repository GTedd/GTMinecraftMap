# Record
execute if block -180 67 84 minecraft:jukebox[has_record=false] run scoreboard players reset songofswords timer
execute if block -180 67 84 minecraft:jukebox[has_record=false] run setblock -259 35 74 air
execute if block -180 67 84 minecraft:jukebox[has_record=false] run fill -260 35 74 -252 35 70 air replace minecraft:repeater
execute if block -180 67 84 minecraft:jukebox[has_record=true] run scoreboard players add songofswords timer 1

# Scoreboard
execute if score songofswords timer matches 1 as @a run stopsound @s record
execute if score songofswords timer matches 1 run clone -260 42 74 -252 41 70 -260 35 70 replace
execute if score songofswords timer matches 1 run fill -249 35 69 -244 35 69 air
execute if score songofswords timer matches 1 run fill -249 35 72 -244 35 72 air
execute if score songofswords timer matches 1 run fill -249 35 75 -244 35 75 air
execute if score songofswords timer matches 1 run fill -249 35 78 -245 35 78 air
execute if score songofswords timer matches 2 run setblock -259 35 74 redstone_wire
execute if score songofswords timer matches 3 run setblock -260 35 74 redstone_block
execute if score songofswords timer matches 10 as @a at @s run setblock -249 35 69 minecraft:redstone_block
execute if score songofswords timer matches 15 as @a at @s run setblock -248 35 69 minecraft:redstone_block
execute if score songofswords timer matches 20 as @a at @s run setblock -247 35 69 minecraft:redstone_block
execute if score songofswords timer matches 35 as @a at @s run setblock -246 35 69 minecraft:redstone_block
execute if score songofswords timer matches 40 as @a at @s run setblock -245 35 69 minecraft:redstone_block
execute if score songofswords timer matches 45 as @a at @s run setblock -244 35 69 minecraft:redstone_block
execute if score songofswords timer matches 60 as @a at @s run setblock -249 35 72 minecraft:redstone_block
execute if score songofswords timer matches 68 as @a at @s run setblock -248 35 72 minecraft:redstone_block
execute if score songofswords timer matches 73 as @a at @s run setblock -247 35 72 minecraft:redstone_block
execute if score songofswords timer matches 78 as @a at @s run setblock -246 35 72 minecraft:redstone_block
execute if score songofswords timer matches 82 as @a at @s run setblock -245 35 72 minecraft:redstone_block
execute if score songofswords timer matches 86 as @a at @s run setblock -244 35 72 minecraft:redstone_block
execute if score songofswords timer matches 90 as @a at @s run setblock -249 35 75 minecraft:redstone_block
execute if score songofswords timer matches 107 as @a at @s run setblock -248 35 75 minecraft:redstone_block
execute if score songofswords timer matches 115 as @a at @s run setblock -247 35 75 minecraft:redstone_block
execute if score songofswords timer matches 123 as @a at @s run setblock -246 35 75 minecraft:redstone_block
execute if score songofswords timer matches 128 as @a at @s run setblock -245 35 75 minecraft:redstone_block
execute if score songofswords timer matches 133 as @a at @s run setblock -244 35 75 minecraft:redstone_block
execute if score songofswords timer matches 153 as @a at @s run setblock -249 35 78 minecraft:redstone_block
execute if score songofswords timer matches 161 as @a at @s run setblock -248 35 78 minecraft:redstone_block
execute if score songofswords timer matches 169 as @a at @s run setblock -247 35 78 minecraft:redstone_block
execute if score songofswords timer matches 174 as @a at @s run setblock -246 35 78 minecraft:redstone_block
execute if score songofswords timer matches 179 as @a at @s run setblock -245 35 78 minecraft:redstone_block
execute if score songofswords timer matches 179 run fill -260 35 74 -252 35 70 air replace minecraft:repeater
execute if score songofswords timer matches 190 run setblock -259 35 74 air
execute if score songofswords timer matches 200.. as @a run tag @s add jukebox_complete
execute if score songofswords timer matches 200.. run tag @a remove jukebox