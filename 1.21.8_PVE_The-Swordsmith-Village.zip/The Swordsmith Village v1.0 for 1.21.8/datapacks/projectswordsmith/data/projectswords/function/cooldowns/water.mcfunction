execute if score @s timerweather matches ..2800 unless score @s timerweather matches ..2550 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"▒▒▒▒▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..2550 unless score @s timerweather matches ..2300 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"█","color":"green"},{"text":"▒▒▒▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..2300 unless score @s timerweather matches ..2050 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"██","color":"green"},{"text":"▒▒▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..2050 unless score @s timerweather matches ..1800 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"███","color":"green"},{"text":"▒▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..1800 unless score @s timerweather matches ..1550 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"████","color":"green"},{"text":"▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..1550 unless score @s timerweather matches ..1300 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"█████","color":"green"},{"text":"▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..1300 unless score @s timerweather matches ..1050 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"██████","color":"green"},{"text":"▒▒▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..1050 unless score @s timerweather matches ..800 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"███████","color":"green"},{"text":"▒▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..800 unless score @s timerweather matches ..550 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"████████","color":"green"},{"text":"▒▒","color":"dark_gray"}]
execute if score @s timerweather matches ..550 unless score @s timerweather matches ..300 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"█████████","color":"green"},{"text":"▒","color":"dark_gray"}]
execute if score @s timerweather matches 299 run title @s actionbar [{"text":"Ability Ready! ","color":"green"},{"text":"██████████","color":"green"}]
execute if score @s timerweather matches ..298 run title @s actionbar [{"text":"Ability In Use! ","color":"blue"},{"text":"▒▒▒▒▒▒▒▒▒▒","color":"dark_gray"}]

execute unless entity @s[scores={timerweather=1..}] run fill -216 40 99 -222 44 93 air replace minecraft:redstone_block
execute unless entity @s[scores={timerweather=1..}] run setblock -218 41 96 minecraft:redstone_block
execute unless entity @s[scores={timerweather=1..}] run setblock -221 41 96 minecraft:redstone_block
execute unless entity @s[scores={timerweather=1..}] run scoreboard players set @s timerweather 0

execute at @s run particle minecraft:dripping_water ~ ~ ~ 0.2 0 0.2 0 3 normal