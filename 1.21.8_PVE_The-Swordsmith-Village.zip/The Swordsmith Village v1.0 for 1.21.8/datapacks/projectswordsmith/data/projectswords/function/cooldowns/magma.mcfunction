execute if score @s timerfire matches ..1498 unless score @s timerfire matches ..1200 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerfire matches ..1200 unless score @s timerfire matches ..900 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"█","color":"green"},{"text":"▒▒▒▒","color":"dark_gray"}]
execute if score @s timerfire matches ..900 unless score @s timerfire matches ..600 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"██","color":"green"},{"text":"▒▒▒","color":"dark_gray"}]
execute if score @s timerfire matches ..600 unless score @s timerfire matches ..300 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"███","color":"green"},{"text":"▒▒","color":"dark_gray"}]
execute if score @s timerfire matches ..300 unless score @s timerfire matches ..1 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"████","color":"green"},{"text":"▒","color":"dark_gray"}]
execute if score @s timerfire matches 1499 run title @s actionbar [{"text":"Ability Ready! ","color":"green"},{"text":"█████","color":"green"}]

execute unless entity @s[scores={timerfire=1..}] run scoreboard players set @s timerfire 1499

execute at @s run particle minecraft:flame ~ ~ ~ 0.2 0 0.2 0 3 normal