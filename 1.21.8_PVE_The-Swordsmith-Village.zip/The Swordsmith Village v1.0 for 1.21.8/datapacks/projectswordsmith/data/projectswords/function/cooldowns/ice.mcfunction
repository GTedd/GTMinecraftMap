execute if score @s timerice matches ..2800 unless score @s timerice matches ..2550 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"▒▒▒▒▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..2550 unless score @s timerice matches ..2300 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"█","color":"green"},{"text":"▒▒▒▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..2300 unless score @s timerice matches ..2050 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"██","color":"green"},{"text":"▒▒▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..2050 unless score @s timerice matches ..1800 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"███","color":"green"},{"text":"▒▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..1800 unless score @s timerice matches ..1550 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"████","color":"green"},{"text":"▒▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..1550 unless score @s timerice matches ..1300 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"█████","color":"green"},{"text":"▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..1300 unless score @s timerice matches ..1050 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"██████","color":"green"},{"text":"▒▒▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..1050 unless score @s timerice matches ..800 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"███████","color":"green"},{"text":"▒▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..800 unless score @s timerice matches ..550 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"████████","color":"green"},{"text":"▒▒","color":"dark_gray"}]
execute if score @s timerice matches ..550 unless score @s timerice matches ..300 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"█████████","color":"green"},{"text":"▒","color":"dark_gray"}]
execute if score @s timerice matches 299 run title @s actionbar [{"text":"Ability Ready! ","color":"green"},{"text":"██████████","color":"green"}]
execute if score @s timerice matches ..298 run title @s actionbar [{"text":"Ability In Use! ","color":"blue"},{"text":"▒▒▒▒▒▒▒▒▒▒","color":"dark_gray"}]

execute unless entity @s[scores={timerice=1..}] run fill -226 40 93 -232 44 99 air replace minecraft:redstone_block
execute unless entity @s[scores={timerice=1..}] run setblock -229 41 95 minecraft:redstone_block
execute unless entity @s[scores={timerice=1..}] run setblock -228 41 96 minecraft:redstone_block
execute unless entity @s[scores={timerice=1..}] run scoreboard players set @s timerice 0

execute at @s run particle block{block_state:"minecraft:blue_ice"} ~ ~ ~ 0.2 0 0.2 0 3 normal
execute at @s if score @s timerice matches ..298 run particle minecraft:snowflake ~ ~1 ~ 7 2 7 0 10 force