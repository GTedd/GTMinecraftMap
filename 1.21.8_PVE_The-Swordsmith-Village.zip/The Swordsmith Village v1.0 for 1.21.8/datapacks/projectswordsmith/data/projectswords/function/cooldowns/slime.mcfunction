execute if score @s timer2 matches ..1498 unless score @s timer2 matches ..1200 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"▒▒▒▒▒","color":"dark_gray"}]
execute if score @s timer2 matches ..1200 unless score @s timer2 matches ..900 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"█","color":"green"},{"text":"▒▒▒▒","color":"dark_gray"}]
execute if score @s timer2 matches ..900 unless score @s timer2 matches ..600 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"██","color":"green"},{"text":"▒▒▒","color":"dark_gray"}]
execute if score @s timer2 matches ..600 unless score @s timer2 matches ..300 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"███","color":"green"},{"text":"▒▒","color":"dark_gray"}]
execute if score @s timer2 matches ..300 unless score @s timer2 matches ..1 run title @s actionbar [{"text":"Ability Recharging: ","color":"yellow"},{"text":"████","color":"green"},{"text":"▒","color":"dark_gray"}]
execute if score @s timer2 matches 1499 run title @s actionbar [{"text":"Ability Ready! ","color":"green"},{"text":"█████","color":"green"}]

execute unless entity @s[scores={timer2=1..}] run scoreboard players set @s timer2 1499

execute at @s run particle minecraft:item_slime ~ ~ ~ 0.2 0 0.2 0 4 normal