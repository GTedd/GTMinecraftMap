setblock -219 19 103 air
fill -222 28 -22 -230 26 -30 air replace minecraft:pointed_dripstone
fill -215 26 -15 -207 28 -7 air replace minecraft:pointed_dripstone
fill -193 28 11 -201 30 3 air replace minecraft:pointed_dripstone
fill -183 28 3 -175 30 -5 air replace minecraft:pointed_dripstone
fill -159 31 -21 -167 33 -29 air replace minecraft:pointed_dripstone
kill @e[distance=..100,tag=Stone,type=block_display]