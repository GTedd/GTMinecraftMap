effect give @s minecraft:absorption 30 1
advancement revoke @s only projectswords:honey
