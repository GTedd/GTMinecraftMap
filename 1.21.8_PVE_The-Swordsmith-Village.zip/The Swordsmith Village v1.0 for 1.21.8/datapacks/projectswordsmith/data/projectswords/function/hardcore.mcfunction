gamerule naturalRegeneration false
execute positioned -191.99 79.90 114.00 as @e[distance=..500,tag=Mob] run attribute @s minecraft:max_health modifier add b90752be-c9af-4434-986f-cea2d617512e 1 add_multiplied_base
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,tag=!regened] minecraft:regeneration 3 255 true
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,type=zombie,tag=!regened] minecraft:instant_damage 3 250 true
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,type=zombie_horse,tag=!regened] minecraft:instant_damage 3 250 true
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,type=zombified_piglin,tag=!regened] minecraft:instant_damage 3 250 true
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,type=husk,tag=!regened] minecraft:regeneration 3 250 true
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,type=skeleton,tag=!regened] minecraft:instant_damage 3 250 true
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,type=skeleton_horse,tag=!regened] minecraft:instant_damage 3 250 true
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,type=stray,tag=!regened] minecraft:regeneration 3 250 true
execute positioned -191.99 79.90 114.00 run effect give @e[distance=..500,tag=Mob,type=wither_skeleton,tag=!regened] minecraft:regeneration 3 250 true
execute positioned -191.99 79.90 114.00 run tag @e[distance=..500,tag=Mob,tag=!regened] add regened

spawnpoint @s 0 101 0 -90
gamerule keepInventory false
execute if entity @s[gamemode=spectator,tag=!reset] unless entity @a[tag=!dead_spectator] run tag @s add reset
execute if entity @s[tag=!dev,gamemode=spectator,team=Villager] run team join Spectator @s
execute if entity @s[tag=!dev,gamemode=spectator,team=Spectator] at @s unless entity @a[gamemode=!spectator,distance=..0] run spectate @a[gamemode=!spectator,sort=nearest,limit=1]
execute if entity @s[scores={deathMSG=1..}] store result score hardcore_death random run random value 1..5
execute if entity @s[scores={deathMSG=1..}] run title @s title [{"text":"GAME OVER","color":"dark_red","bold":true}]
execute if entity @s[scores={deathMSG=1..}] if score hardcore_death random matches 1 run title @s subtitle [{"selector":"@s"},{"text":" was slain by... a baby zombie?","color":"red"}]
execute if entity @s[scores={deathMSG=1..}] if score hardcore_death random matches 2 run title @s subtitle [{"text":"Better luck next time, ","color":"red"},{"selector":"@s"},{"text":".","color":"red"}]
execute if entity @s[scores={deathMSG=1..}] if score hardcore_death random matches 3 run title @s subtitle [{"text":"Unlucky.","color":"red"}]
execute if entity @s[scores={deathMSG=1..}] if score hardcore_death random matches 4 run title @s subtitle [{"text":"That was a nice try! Just kidding.","color":"red"}]
execute if entity @s[scores={deathMSG=1..}] if score hardcore_death random matches 5 run title @s subtitle [{"text":"Try again?","color":"red"}]
scoreboard players reset @a[scores={deathMSG=1..}] deathMSG
