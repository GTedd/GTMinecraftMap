#Location 1#
execute positioned -163 32 -25 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=1,distance=..1] run clone -222 18 -8 -230 20 0 -167 31 -29
execute positioned -163 32 -25 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=2,distance=..1] run clone -222 14 -8 -230 16 0 -167 31 -29
execute positioned -163 32 -25 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=3,distance=..1] run clone -222 10 -8 -230 12 0 -167 31 -29
execute positioned -163 32 -25 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=4,distance=..1] run clone -222 6 -8 -230 8 0 -167 31 -29
execute positioned -163 32 -25 if entity @e[type=ghast,tag=Boss,distance=..5] run playsound minecraft:entity.turtle.egg_break master @a ~ ~ ~ 1 0.8

#Location 2#
execute positioned -179 28 -1 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=1,distance=..1] run clone -222 18 -8 -230 20 0 -183 28 -5
execute positioned -179 28 -1 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=2,distance=..1] run clone -222 14 -8 -230 16 0 -183 28 -5
execute positioned -179 28 -1 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=3,distance=..1] run clone -222 10 -8 -230 12 0 -183 28 -5
execute positioned -179 28 -1 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=4,distance=..1] run clone -222 6 -8 -230 8 0 -183 28 -5
execute positioned -179 28 -1 if entity @e[type=ghast,tag=Boss,distance=..5] run playsound minecraft:entity.turtle.egg_break master @a ~ ~ ~ 1 0.8

#Location 3#
execute positioned -197 28 7 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=1,distance=..1] run clone -222 18 -8 -230 20 0 -201 28 3
execute positioned -197 28 7 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=2,distance=..1] run clone -222 14 -8 -230 16 0 -201 28 3
execute positioned -197 28 7 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=3,distance=..1] run clone -222 10 -8 -230 12 0 -201 28 3
execute positioned -197 28 7 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=4,distance=..1] run clone -222 6 -8 -230 8 0 -201 28 3
execute positioned -197 28 7 if entity @e[type=ghast,tag=Boss,distance=..5] run playsound minecraft:entity.turtle.egg_break master @a ~ ~ ~ 1 0.8

#Location 4#
execute positioned -211 26 -11 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=1,distance=..1] run clone -222 18 -8 -230 20 0 -215 26 -15
execute positioned -211 26 -11 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=2,distance=..1] run clone -222 14 -8 -230 16 0 -215 26 -15
execute positioned -211 26 -11 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=3,distance=..1] run clone -222 10 -8 -230 12 0 -215 26 -15
execute positioned -211 26 -11 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=4,distance=..1] run clone -222 6 -8 -230 8 0 -215 26 -15
execute positioned -211 26 -11 if entity @e[type=ghast,tag=Boss,distance=..5] run playsound minecraft:entity.turtle.egg_break master @a ~ ~ ~ 1 0.8

#Location 5#
execute positioned -226 26 -26 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=1,distance=..1] run clone -222 18 -8 -230 20 0 -230 26 -30
execute positioned -226 26 -26 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=2,distance=..1] run clone -222 14 -8 -230 16 0 -230 26 -30
execute positioned -226 26 -26 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=3,distance=..1] run clone -222 10 -8 -230 12 0 -230 26 -30
execute positioned -226 26 -26 if entity @e[type=ghast,tag=Boss,distance=..5] run execute positioned -215 15 2 if entity @e[type=marker,tag=4,distance=..1] run clone -222 6 -8 -230 8 0 -230 26 -30
execute positioned -226 26 -26 if entity @e[type=ghast,tag=Boss,distance=..5] run playsound minecraft:entity.turtle.egg_break master @a ~ ~ ~ 1 0.8
