execute unless score dummy boss.death matches 1.. at @e[distance=..100,tag=Stone,type=block_display] run summon minecraft:block_display ~ ~ ~ {Tags:["fake"],transformation:{left_rotation:[0f,0f,0f,1f],right_rotation:[0f,0f,0f,1f],translation:[0f,0f,0f],scale:[5f,5f,5f]},block_state:{Name:"minecraft:stone"}}
scoreboard players add dummy boss.death 1
execute if score dummy boss.death matches 1..5 at @e[distance=..100,tag=fake,type=block_display] run playsound minecraft:block.lava.extinguish master @a ~2.5 ~2.5 ~2.5 0.3 0.5
execute if score dummy boss.death matches 41..45 at @e[distance=..100,tag=fake,type=block_display] run playsound minecraft:block.lava.extinguish master @a ~2.5 ~2.5 ~2.5 0.3 0.5
execute if score dummy boss.death matches 81..85 at @e[distance=..100,tag=fake,type=block_display] run playsound minecraft:block.lava.extinguish master @a ~2.5 ~2.5 ~2.5 0.3 0.5
execute if score dummy boss.death matches 121..125 at @e[distance=..100,tag=fake,type=block_display] run playsound minecraft:block.lava.extinguish master @a ~2.5 ~2.5 ~2.5 0.3 0.5
execute if score dummy boss.death matches 161..165 at @e[distance=..100,tag=fake,type=block_display] run playsound minecraft:block.lava.extinguish master @a ~2.5 ~2.5 ~2.5 0.3 0.5
execute if score dummy boss.death matches 1..5 at @e[distance=..100,tag=fake,type=block_display] run particle cloud ~2.5 ~2.5 ~2.5 1.5 1.5 1.5 1 10 normal
execute if score dummy boss.death matches 41..45 at @e[distance=..100,tag=fake,type=block_display] run particle cloud ~2.5 ~2.5 ~2.5 1.5 1.5 1.5 1 10 normal
execute if score dummy boss.death matches 81..85 at @e[distance=..100,tag=fake,type=block_display] run particle cloud ~2.5 ~2.5 ~2.5 1.5 1.5 1.5 1 10 normal
execute if score dummy boss.death matches 121..125 at @e[distance=..100,tag=fake,type=block_display] run particle cloud ~2.5 ~2.5 ~2.5 1.5 1.5 1.5 1 10 normal
execute if score dummy boss.death matches 161..165 at @e[distance=..100,tag=fake,type=block_display] run particle cloud ~2.5 ~2.5 ~2.5 1.5 1.5 1.5 1 10 normal
execute if score dummy boss.death matches 1..200 at @e[distance=..100,tag=fake,type=block_display] run playsound minecraft:block.stone.break master @a ~2.5 ~2.5 ~2.5 2 0.5
execute if score dummy boss.death matches 1..200 at @e[distance=..100,tag=fake,type=block_display] run particle block{block_state:"minecraft:cobblestone"} ~2.5 ~2.5 ~2.5 1.2 1.2 1.2 5 50 normal
execute if score dummy boss.death matches 1 at @e[distance=..100,tag=fake,type=block_display] run playsound minecraft:entity.warden.emerge master @a ~2.5 ~2.5 ~2.5 2 0.1
execute if score dummy boss.death matches 1 at @e[distance=..100,tag=fake,type=block_display] at @p[team=!Spectator] run tp @a ~ ~ ~
execute if score dummy boss.death matches 1 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 2 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 3 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 4 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 5 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 6 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 7 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 8 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 9 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 10 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 11 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 12 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 13 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 14 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 15 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 16 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 17 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 18 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 19 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 20 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 21 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 22 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 23 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 24 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 25 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 26 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 27 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 28 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 29 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 30 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 31 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 32 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 33 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 34 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 35 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 36 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 37 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 38 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 39 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 40 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 41 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 42 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 43 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 44 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 45 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 46 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 47 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 48 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 49 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 50 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 51 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 52 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 53 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 54 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 55 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 56 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 57 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 58 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 59 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 60 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 61 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 62 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 63 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 64 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 65 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 66 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 67 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 68 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 69 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 70 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 71 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 72 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 73 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 74 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 75 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 76 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 77 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 78 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 79 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 80 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 81 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 82 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 83 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 84 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 85 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 86 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 87 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 88 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 89 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 90 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 91 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 92 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 93 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 94 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 95 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 96 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 97 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 98 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 99 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 100 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 101 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 102 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 103 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 104 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 105 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 106 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 107 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 108 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 109 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 110 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 111 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 112 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 113 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 114 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 115 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 116 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 117 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 118 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 119 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 120 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 121 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 122 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 123 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 124 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 125 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 126 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 127 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 128 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 129 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 130 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 131 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 132 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 133 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 134 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 135 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 136 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 137 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 138 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 139 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 140 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 141 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 142 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 143 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 144 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 145 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 146 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 147 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 148 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 149 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 150 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 151 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 152 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 153 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 154 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 155 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 156 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 157 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 158 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 159 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 160 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 161 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 162 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 163 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 164 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 165 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 166 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 167 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 168 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 169 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 170 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 171 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 172 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 173 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 174 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 175 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 176 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 177 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 178 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 179 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 180 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 181 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 182 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 183 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 184 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 185 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 186 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 187 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 188 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 189 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 190 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 191 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 192 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 193 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 194 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 195 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 196 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 197 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~0.1
execute if score dummy boss.death matches 198 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~ ~ ~-0.1
execute if score dummy boss.death matches 199 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~0.1 ~ ~
execute if score dummy boss.death matches 200 as @e[distance=..100,tag=fake,type=block_display] at @s run tp @s ~-0.1 ~ ~
execute if score dummy boss.death matches 200 at @e[distance=..100,tag=fake,type=block_display] run playsound minecraft:entity.wither.death master @a ~2.5 ~2.5 ~2.5 0.4 1.5
execute if score dummy boss.death matches 200 at @e[distance=..100,tag=fake,type=block_display] run particle minecraft:flash ~2.5 ~2.5 ~2.5 3 3 3 0 10 normal
execute if score dummy boss.death matches 198..200 as @a at @s run particle minecraft:flash ~ ~ ~ 0 0 0 0 5 force
execute if score dummy boss.death matches 200 run scoreboard objectives setdisplay sidebar
execute if score dummy boss.death matches 200 as @a at @s run particle minecraft:flash ~ ~2 ~ 0.00001 0.00001 0.00001 0 1 normal
execute if score dummy boss.death matches 200 as @e[distance=..100,tag=fake,type=block_display] at @s run kill @s
execute if score dummy boss.death matches 200 run tag @a remove boss_spawned