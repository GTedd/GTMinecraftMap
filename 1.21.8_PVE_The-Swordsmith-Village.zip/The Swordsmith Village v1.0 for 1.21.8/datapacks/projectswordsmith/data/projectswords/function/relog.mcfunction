execute as 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 if entity @s[tag=day] run tag @a remove night
execute as 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 if entity @s[tag=day] run tag @a add day
execute as 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 if entity @s[tag=night] run tag @a remove day
execute as 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 if entity @s[tag=night] run tag @a add night
execute if entity @a[tag=outofhouse] run tag @s add outofhouse
execute if entity @a[tag=objective1] run tag @s add objective1
execute if entity @a[tag=tellraw1] run tag @s add tellraw1
execute if entity @a[tag=daybar] run tag @s add daybar
execute if entity @a[tag=nightbar] run tag @s add nightbar
execute if entity @a[tag=jukebox_complete] run tag @s add jukebox_complete
execute if entity @a[tag=in_boss] run tag @s add in_boss
execute if entity @a[tag=cagelimit] run tag @s add cagelimit
execute if entity @a[tag=transition1] run tag @s add transition1
execute if entity @a[tag=anchor.night] run tag @s add anchor.night
execute if entity @a[tag=anchor.failed] run tag @s add anchor.failed
execute if entity @a[tag=clone.ran] run tag @s add clone.ran
execute if entity @a[tag=target.solved] run tag @s add target.solved
execute if entity @a[tag=target.1] run tag @s add target.1
execute if entity @a[tag=tetsuo.unlocked] run tag @s add tetsuo.unlocked
execute if entity @a[tag=stop.mobs] run tag @s add stop.mobs
execute if entity @a[tag=kacper.final] run tag @s add kacper.final
execute if entity @a[tag=axolotl.unlocked] run tag @s add axolotl.unlocked
execute if entity @a[tag=trident.unlocked] run tag @s add trident.unlocked
execute if entity @a[tag=origami.joined] run tag @s add origami.joined
execute if entity @a[tag=armorer.saved] run tag @s add armorer.saved
execute if entity @a[tag=has.key] run tag @s add has.key
execute if entity @a[tag=key.dropped] run tag @s add key.dropped
#rewards and regifts
#execute if entity @a[tag=chainmail_reward] unless entity @s[tag=chainmail_reward] run give @s compass[custom_name='{"text":"Daylight Anchor","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}',lore=['{"text":"Allows for fast travel during the daytime.","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}','[{"keybind":"key.use","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" to select a destination.","color":"gray","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]'],custom_data={NoPickup:1b}] 1
execute if entity @a[tag=chainmail_reward] run tag @s add chainmail_reward
#sync tags 2
execute if entity @a[tag=repeat.started] run tag @s add repeat.started
execute if entity @a[tag=all.cleared] run tag @s add all.cleared
execute if entity @a[tag=preboss] run tag @s add preboss
execute if entity @a[tag=boss.unlocked] run tag @s add boss.unlocked
execute if entity @a[tag=final.room] run tag @s add final.room
execute if entity @a[tag=ending] run tag @s add ending
execute if entity @a[tag=transition.comein.tp] run tag @s add transition.comein.tp
execute if entity @a[tag=day1] run tag @s add day1
#Spectate on too late
execute if entity @s[tag=!housetp] if entity @a[tag=housetp] run tellraw @s [{"text":"You joined while a game is occuring. You will Spectate this game.","color":"dark_red"}]
execute if entity @s[tag=!housetp] if entity @a[tag=housetp] run team join Spectator @s
execute if entity @s[tag=!housetp] if entity @a[tag=housetp] run tag @s add housetp