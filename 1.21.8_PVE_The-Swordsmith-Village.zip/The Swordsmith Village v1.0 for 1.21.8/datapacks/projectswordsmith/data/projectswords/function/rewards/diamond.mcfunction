tellraw @s [{"text":"<"},{"selector":"112eb2d8-5d51-4122-804f-bc618a4cf1b8"},{"text":"> "},{"text":"Great to see you again, ","color":"gray"},{"selector":"@s"},{"text":"! Lately you've been really giving your all out there! I prepared one final ","color":"gray"},{"text":"reward ","color":"gold"},{"text":"for you. The attacks should stop tomorrow, so now it's just one last push! I wish you all the best.","color":"gray"}]
give @s netherite_scrap 4
execute at @s as @e[type=item,distance=..5] run data merge entity @s {Glowing:1b}
tag @s add diamond_reward