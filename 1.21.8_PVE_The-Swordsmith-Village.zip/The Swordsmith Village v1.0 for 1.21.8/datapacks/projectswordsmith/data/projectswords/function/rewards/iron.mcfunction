tellraw @s [{"text":"<"},{"selector":"112eb2d8-5d51-4122-804f-bc618a4cf1b8"},{"text":"> "},{"selector":"@s"},{"text":"! We really appreciate your work! This time around I have a very special ","color":"gray"},{"text":"reward","color":"gold"},{"text":"! Take these and go gear up for tonight!","color":"gray"}]
give @s diamond 5
execute at @s as @e[type=item,distance=..5] run data merge entity @s {Glowing:1b}
tag @s add iron_reward