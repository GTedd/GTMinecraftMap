tellraw @s [{"text":"<"},{"selector":"112eb2d8-5d51-4122-804f-bc618a4cf1b8"},{"text":"> "},{"text":"Hey! ","color":"gray"},{"selector":"@s"},{"text":"! You've been doing great out there. I have prepared a ","color":"gray"},{"text":"reward ","color":"gold"},{"text":"for you! These should help you manage your items.","color":"gray"}]
give @s purple_bundle 1
give @s cyan_bundle 1
give @s red_bundle 1
give @s lime_bundle 1
execute at @s as @e[type=item,distance=..5] run data merge entity @s {Glowing:1b}
tag @s add leather_reward