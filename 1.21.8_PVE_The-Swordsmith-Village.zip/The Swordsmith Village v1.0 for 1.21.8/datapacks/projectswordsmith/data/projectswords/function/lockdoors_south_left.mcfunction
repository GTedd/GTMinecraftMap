# setblocks
setblock ~ ~ ~ minecraft:air replace
setblock ~ ~ ~ minecraft:spruce_door[hinge=left,open=false,facing=south,half=upper]
setblock ~ ~-1 ~ minecraft:spruce_door[hinge=left,open=false,facing=south,half=lower]

# tellraw
execute if score dummy nighttimer matches ..9995 run tellraw @p[team=!Spectator] [{"text":"Doors are locked during nightime.","color":"yellow"}]

# kills
kill @e[distance=..5,type=item,nbt={Item:{id:"minecraft:spruce_door"}}]
