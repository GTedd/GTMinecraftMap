execute as @a[tag=opened.allay] at @s run tp @e[distance=..5,type=allay,tag=Memi] ~ ~2.5 ~ ~ ~ 
particle falling_dust{block_state:"minecraft:prismarine"} ~ ~ ~ 1 0.7 1 0.3 1 normal
effect give @p[team=!Spectator,distance=..3] health_boost 30 0 true
execute if score @p[team=!Spectator] timer matches 15 run effect give @a[distance=..3] regeneration 2 2 true
execute if score @p[team=!Spectator] timer matches ..20 run particle falling_dust{block_state:"minecraft:pink_wool"} ~ ~ ~ 1 0.7 1 0.3 1 normal
#execute at @s as @e[type=interaction,tag=allay] run tp @s ~ ~-0.05 ~