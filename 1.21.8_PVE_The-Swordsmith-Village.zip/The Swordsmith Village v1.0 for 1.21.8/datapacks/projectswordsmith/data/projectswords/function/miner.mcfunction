execute if entity @a[distance=..5,tag=tnt1.reward] run tag @s add tnt
execute if entity @s[tag=tnt,tag=!tnt1.given] run effect clear a0e69427-6df3-4261-aa09-8ea2948646a0 glowing
execute if entity @s[tag=tnt,tag=!tnt1.given] if entity @a[tag=!irontier] run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":" Hey! Did you hear from the Librarian? I got some nice explosive materials while mining. I have crafted them into a ","color":"gray"},{"text":"TNT","color":"gold","bold":false},{"text":", and I am in the process of crafting another!","color":"gray"}]
execute if entity @s[tag=tnt,tag=!tnt1.given] if entity @a[tag=!irontier] run schedule function projectswords:dialogue/approach_miner_1 3s replace
execute if entity @s[tag=tnt,tag=!tnt1.given] if entity @a[tag=!irontier] run tag @s add tnt1.given

execute if entity @s[tag=tnt,tag=!tnt1.given] if entity @a[tag=irontier] run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":" Hey! Did you hear from the Librarian? I got some nice explosive materials while mining. I have crafted them into two ","color":"gray"},{"text":"TNT","color":"gold","bold":false},{"text":"! Please use them to free the Armorer and Swordsmith.","color":"gray"}]
execute if entity @s[tag=tnt,tag=!tnt1.given] if entity @a[tag=irontier] run give @p[team=!Spectator] minecraft:tnt[custom_name={"text":"High-Precision TNT","color":"red","bold":false,"italic":false},can_place_on={blocks:["minecraft:cracked_stone_bricks"]}] 2
execute if entity @s[tag=tnt,tag=!tnt1.given] if entity @a[tag=irontier] run tag @s add tnt.both
execute if entity @s[tag=tnt,tag=!tnt1.given] if entity @a[tag=irontier] run tag @s add tnt1.given

execute if entity @s[tag=tnt,tag=tnt1.given,tag=!tnt2.given,tag=!tnt.both] if entity @a[tag=irontier,distance=..5] run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":" Hey! As promised, here is the other ","color":"gray"},{"text":"TNT","color":"gold","bold":false},{"text":". Please, do your part now! And don't forget to come by to do some mining!","color":"gray"}]
execute if entity @s[tag=tnt,tag=tnt1.given,tag=!tnt2.given,tag=!tnt.both] if entity @a[tag=irontier,distance=..5] run give @p[team=!Spectator] minecraft:tnt[custom_name={"text":"High-Precision TNT","color":"red","bold":false,"italic":false},can_place_on={blocks:["minecraft:cracked_stone_bricks"]}] 1
execute if entity @s[tag=tnt,tag=tnt1.given,tag=!tnt2.given,tag=!tnt.both] if entity @a[tag=irontier,distance=..5] run tag @s add tnt2.given