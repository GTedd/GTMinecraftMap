#0-9 ball
execute if entity @s[tag=can_takeDMG] run function projectswords:boss_dmg

# Always Run
effect clear @s poison
#Mob
execute positioned -191.99 79.90 114.00 as @e[team=!Mob,tag=Mob,distance=..300] run team join Mob @s
#witches
execute positioned -191.99 79.90 114.00 as @e[type=!evoker_fangs,distance=..400,tag=Mob] store result score @s health run data get entity @s Health 1
execute positioned -191.99 79.90 114.00 as @e[type=!evoker_fangs,distance=..400,tag=Mob,scores={health=..10},tag=!executed] at @s if entity @e[type=witch,distance=..7] run function projectswords:witch
#cages
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=minecraft:iron_golem,tag=Angry] at @s run data modify entity @s AngryAt set from entity @p[team=!Spectator] UUID
execute positioned -195 42 -10 as @e[distance=..100,tag=cagespawn,tag=!falling] run effect give @s minecraft:slow_falling 3 1 false
execute positioned -195 42 -10 as @e[distance=..100,tag=cagespawn] run tag @s add falling
#stage1
teleport @e[distance=..100,type=minecraft:block_display,tag=Stone,limit=1,sort=nearest] ~-2.5 ~ ~-2.5
execute if entity @s[tag=stage1,tag=!stage2] run tp @s -178.52 36.00 -0.49
execute if entity @s[tag=stage1,tag=!stage2] if score @r timer20s matches 1 run tp @s ~ ~ ~ facing entity @p[team=!Spectator]
#golems
scoreboard players add dummy LongTimer 1
execute if entity @a[tag=1_player] unless entity @e[type=iron_golem,tag=Angry] if score dummy LongTimer matches 1.. store result score #randomlong random run random value 1..500
execute if entity @a[tag=2_players] unless entity @e[type=iron_golem,tag=Angry] if score dummy LongTimer matches 1.. store result score #randomlong random run random value 1..400
execute if entity @a[tag=3_players] unless entity @e[type=iron_golem,tag=Angry] if score dummy LongTimer matches 1.. store result score #randomlong random run random value 1..300
execute if entity @a[tag=4_players] unless entity @e[type=iron_golem,tag=Angry] if score dummy LongTimer matches 1.. store result score #randomlong random run random value 1..200
execute if score dummy LongTimer matches 1000.. run scoreboard players set dummy LongTimer 0
execute if score #randomlong random matches 10 run tag @s add iron_golem.run
execute if entity @s[tag=iron_golem.run] run function projectswords:iron_golem
execute if score dummy spawntimer matches 200.. run scoreboard players set dummy spawntimer 0

# Run On Stage 1
execute if entity @s[tag=stage1] run function projectswords:boss_stage1

execute unless entity @s[tag=stage1] run fill -209 47 -8 -207 47 -10 crimson_trapdoor[half=top]
execute unless entity @s[tag=stage1] run fill -203 37 -19 -205 37 -17 crimson_trapdoor[half=top]
execute unless entity @s[tag=stage1] run fill -189 43 -4 -187 43 -6 crimson_trapdoor[half=top]
execute unless entity @s[tag=stage1] run fill -205 41 3 -203 41 1 crimson_trapdoor[half=top]

# Run Before Stage 2
execute unless entity @s[tag=stage2] run setblock -220 18 101 air
execute unless entity @s[tag=stage2] as @e[type=minecraft:arrow,distance=..6] at @s run particle dust{color:[1.000,0.000,0.000],scale:1} ~ ~ ~ 0.1 0.3 0.1 0 50 force
execute unless entity @s[tag=stage2] as @e[type=minecraft:arrow,distance=..6] run kill @s

# Run On Stage 2
execute if entity @s[tag=stage2] run function projectswords:boss_stage2

# Other
execute if score dummy BossTimer matches ..0 run scoreboard players set dummy BossTimer 200
scoreboard players remove dummy BossTimer 1
execute if entity @s[tag=stage2] if score dummy BossTimer matches 1 at @s at @e[type=armor_stand,tag=BossRTP,sort=random,distance=5..100,limit=1] run tp @s ~ ~0.5 ~
execute positioned -163 32 -25 if entity @s[tag=Toxic,distance=..5] run particle dust{color:[0.149,0.800,0.106],scale:1} ~ ~ ~ 1.8 0.3 1.8 0 20 normal
execute positioned -179 28 -1 if entity @s[tag=Toxic,distance=..5] run particle dust{color:[0.149,0.800,0.106],scale:1} ~ ~ ~ 1.8 0.3 1.8 0 20 normal
execute positioned -197 28 7 if entity @s[tag=Toxic,distance=..5] run particle dust{color:[0.149,0.800,0.106],scale:1} ~ ~ ~ 1.8 0.3 1.8 0 20 normal
execute positioned -211 26 -11 if entity @s[tag=Toxic,distance=..5] run particle dust{color:[0.149,0.800,0.106],scale:1} ~ ~ ~ 1.8 0.3 1.8 0 20 normal
execute positioned -226 26 -26 if entity @s[tag=Toxic,distance=..5] run particle dust{color:[0.149,0.800,0.106],scale:1} ~ ~ ~ 1.8 0.3 1.8 0 20 normal
execute positioned -195 42 -10 if score dummy BossTimer matches 1 run tag @e[distance=..100,type=ghast,tag=Toxic] remove Toxic
execute if score dummy BossTimer matches 2 run fill -222 28 -22 -230 26 -30 air replace minecraft:pointed_dripstone
execute if score dummy BossTimer matches 2 run fill -215 26 -15 -207 28 -7 air replace minecraft:pointed_dripstone
execute if score dummy BossTimer matches 2 run fill -193 28 11 -201 30 3 air replace minecraft:pointed_dripstone
execute if score dummy BossTimer matches 2 run fill -183 28 3 -175 30 -5 air replace minecraft:pointed_dripstone
execute if score dummy BossTimer matches 2 run fill -159 31 -21 -167 33 -29 air replace minecraft:pointed_dripstone

execute if entity @s[tag=stage2] run particle minecraft:cloud ~ ~3 ~ 1.2 1.2 1.2 0.1 10 normal
execute if entity @s[tag=stage2] run particle dust_color_transition{from_color:[0.467,0.486,0.522],scale:2,to_color:[0.949,1.000,0.992]} ~ ~2.7 ~ 1 1 1 0 100 normal