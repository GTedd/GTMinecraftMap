execute on origin at @s run data modify entity @e[distance=..2,type=item,sort=nearest,limit=1] Owner set from entity @s UUID
data modify entity @s PickupDelay set value 0s
execute on origin at @s run tp @e[distance=..2,type=item,sort=nearest,limit=1] @s
