tellraw @s[team=!Spectator] [{"text":"You will now Spectate the next game.","color":"green"}]
playsound minecraft:entity.arrow.hit_player master @s[team=!Spectator] ~ ~ ~ 0.7 0.8
team join Spectator @s
advancement revoke @s only projectswords:press_button_spec