effect give @s minecraft:invisibility infinite 0 true
data merge entity @s {Silent:1b}
kill @s
tag @s add Mob
tag @s add fixed