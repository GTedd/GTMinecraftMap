execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:1b}}}}] run function projectswords:cooldowns/water
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword2:1b}}}}] run function projectswords:cooldowns/water
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword3:1b}}}}] run function projectswords:cooldowns/water
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword4:1b}}}}] run function projectswords:cooldowns/water

execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:1b}}}}] run function projectswords:cooldowns/magma
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword2:1b}}}}] run function projectswords:cooldowns/magma
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword3:1b}}}}] run function projectswords:cooldowns/magma
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword4:1b}}}}] run function projectswords:cooldowns/magma

execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:1b}}}}] run function projectswords:cooldowns/slime
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword2:1b}}}}] run function projectswords:cooldowns/slime
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword3:1b}}}}] run function projectswords:cooldowns/slime
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword4:1b}}}}] run function projectswords:cooldowns/slime

execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:1b}}}}] run function projectswords:cooldowns/ice
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword2:1b}}}}] run function projectswords:cooldowns/ice
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword3:1b}}}}] run function projectswords:cooldowns/ice
execute as @a[nbt={SelectedItem:{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword4:1b}}}}] run function projectswords:cooldowns/ice