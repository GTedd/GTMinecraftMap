execute store result bossbar minecraft:preboss value run scoreboard players get dummy preboss
scoreboard players remove dummy preboss 1
execute if score dummy preboss matches 1.. run bossbar set minecraft:prepare players
execute if score dummy preboss matches 0 run function projectswords:boss_unlock