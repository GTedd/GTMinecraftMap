# Resets #
tag 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 remove day
tag @a remove daybar
tag @a remove day
tag 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 add night
execute as 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 if entity @s[tag=night] run tag @a add night
tag @a remove tp.ran.villagers
execute unless score day0 transition matches 1.. unless score prepare transition matches 1.. run tag @a[tag=!day0,tag=!preboss] add nightbar

# StartNight #
execute as @a[tag=!day0,tag=!preboss] run time set night

# CloseGates #
execute unless entity @a[tag=clone.ran] run function projectswords:night_once

# LockDoors #
execute unless entity @a[tag=day0] run function projectswords:starter_doors
execute positioned -230 75 93 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_west_left
execute positioned -230 75 92 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_west_right
execute positioned -181 71 144 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_west_left
execute positioned -223 73 63 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_west_left
execute positioned -229 64 153 if block ~ ~ ~ minecraft:oak_door[open=true] run function projectswords:lockdoors_west_left_oak
execute positioned -200 74 54 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_east_left
execute positioned -158 69 118 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_east_left
execute positioned -190 71 145 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_north_left
execute positioned -189 71 145 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_north_right
execute positioned -182 68 87 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_north_left
execute positioned -181 68 87 if block ~ ~ ~ minecraft:spruce_door[open=true] run function projectswords:lockdoors_north_right
#door barriers
execute positioned -200 72 54 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~-2 ~1 ~
execute positioned -223 71 63 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~2 ~1 ~
execute positioned -230 73 93 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~2 ~1 ~
execute positioned -230 73 92 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~2 ~1 ~
execute positioned -181 66 86 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~ ~1 ~2
execute positioned -182 66 86 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~ ~1 ~2
execute positioned -158 67 118 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~-2 ~1 ~
execute positioned -182 69 144 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~2 ~1 ~
execute positioned -189 69 144 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~ ~1 ~2
execute positioned -190 69 144 as @a[dy=3,dx=0.5,dz=0.5] run tp @s ~ ~1 ~2
execute positioned -230 63 153 as @a[dy=2,dx=0.5,dz=0.5] run tp @s ~2 ~ ~

# Mob Data #
# Mob
execute positioned -191.99 79.90 114.00 as @e[team=!Mob,tag=Mob,distance=..300] run team join Mob @s
# Witches
execute positioned -191.99 79.90 114.00 as @e[distance=..400,tag=Mob] store result score @s health run data get entity @s Health 1
execute positioned -191.99 79.90 114.00 as @e[distance=..400,tag=Mob,scores={health=..10},tag=!executed] at @s if entity @e[type=witch,distance=..7] run function projectswords:witch
# Honey Sprites
#summon x2: /summon zombie ~ ~1 ~ {Tags:["Mob","NoGlow"],Attributes:[{Name:generic.attack_damage,Base:10}],IsBaby:1b,ArmorItems:[{},{},{},{id:"minecraft:honey_block",count:1}],ArmorDropChances:[0.085F,0.085F,0.085F,0.000F],active_effects:[{id:"minecraft:invisibility",amplifier:1b,duration:19999980,show_particles:0b}],PersistenceRequired:1b,Silent:1b,Passengers:[{id:"minecraft:area_effect_cloud",Particle:"wax_on",ReapplicationDelay:150,Radius:2f,Duration:99999,Color:15908111,Tags:["HoneyDecay"]}]}
# Blazes
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=blaze,tag=Mob] at @s run function projectswords:fire_range
# Fixes
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=minecraft:slime,tag=!fixed] if entity @s[nbt={Size:0}] run function projectswords:fixslime
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=minecraft:magma_cube,tag=!fixed] if entity @s[nbt={Size:0}] run function projectswords:fixmagma

# Position #
execute positioned -191.99 79.90 114.00 store result score x Position as @e[tag=Mob,sort=nearest,distance=..500] run data get entity @s Pos[0]
execute positioned -191.99 79.90 114.00 store result score y Position as @e[tag=Mob,sort=nearest,distance=..500] run data get entity @s Pos[1]
execute positioned -191.99 79.90 114.00 store result score z Position as @e[tag=Mob,sort=nearest,distance=..500] run data get entity @s Pos[2]

# HideVillagers #
execute unless score day0 transition matches 1.. unless score prepare transition matches 1.. run tp @e[type=minecraft:villager] -237.5 43 109.5

