execute as 59834455-09a2-4621-8891-aaddb8e2fef9 unless entity @s[tag=click_scammer_1] at @s run tellraw @a[distance=..4] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"I'm Giovanni, pleasure! Buy the freshest new items from my shop for'a cheap price!","color":"gray"}]
execute as 59834455-09a2-4621-8891-aaddb8e2fef9 unless entity @s[tag=click_scammer_1] run tag @s add click_scammer_1
advancement revoke @s only projectswords:scammer_trade
