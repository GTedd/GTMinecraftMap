execute as 5f6b174e-d917-432d-b936-19eaaefff8d9 unless entity @s[tag=click_farmer_1] at @s run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Good morning, great guardian. What may I provide you?","color":"gray"}]
execute as 5f6b174e-d917-432d-b936-19eaaefff8d9 unless entity @s[tag=click_farmer_1] run tag @s add click_farmer_1
advancement revoke @s only projectswords:farmer_trade
