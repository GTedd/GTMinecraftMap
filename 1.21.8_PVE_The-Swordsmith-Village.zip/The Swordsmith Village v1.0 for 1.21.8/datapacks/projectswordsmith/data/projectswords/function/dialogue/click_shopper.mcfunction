execute as fcc42dd6-4cbf-47ea-b6cc-670ae78da842 unless entity @s[tag=click_shopper_1] at @s run tellraw @a[distance=..5] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Hey, amigo! I'm Alejandro! Just between you an' me, I wouldn't buy anything from that Giovanni guy... Why don't ya buy from me instead!","color":"gray"}]
execute as fcc42dd6-4cbf-47ea-b6cc-670ae78da842 unless entity @s[tag=click_shopper_1] run tag @s add click_shopper_1
advancement revoke @s only projectswords:shopper_trade
