execute as 84dbcb45-052f-45d5-83d2-20690b218504 unless entity @s[tag=click_mason_1] at @s run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"I heard yer gonna be on guard duty, thanks mate! If ya find some ","color":"gray"},{"text":"treasure, ","color":"gold"},{"text":"make sure to pass by, I can trade it for some big bucks!","color":"gray"}]
execute as 84dbcb45-052f-45d5-83d2-20690b218504 unless entity @s[tag=click_mason_1] run tag @s add click_mason_1
advancement revoke @s only projectswords:mason_trade
