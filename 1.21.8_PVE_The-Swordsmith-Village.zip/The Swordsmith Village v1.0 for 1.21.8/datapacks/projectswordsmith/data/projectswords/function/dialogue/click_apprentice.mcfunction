execute as 29344ae4-8b41-42e5-84a0-4f1cffcb7b94 unless entity @s[tag=click_apprentice_1] at @s run tellraw @a[distance=..5] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Anyways, you should buy a sword. ","color":"gray"},{"text":"Sensei","color":"dark_red","bold":false},{"text":" only works with brand-new, undamaged stuff.","color":"gray"}]
execute as 29344ae4-8b41-42e5-84a0-4f1cffcb7b94 unless entity @s[tag=click_apprentice_1] run tag @s add click_apprentice_1
advancement revoke @s only projectswords:apprentice_trade
