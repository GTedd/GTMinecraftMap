execute as 975bcf8a-1e63-4396-ad99-d31de7b93a0d unless entity @s[tag=click_miner_1] at @s run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"In need of some change? Buy yourself a pickaxe and get to mining! It might take a while to get good stuff, but you can even get juicy ","color":"gray"},{"text":"diamonds!","color":"gold"}]
execute as 975bcf8a-1e63-4396-ad99-d31de7b93a0d unless entity @s[tag=click_miner_1] run tag @s add click_miner_1
advancement revoke @s only projectswords:miner_trade
