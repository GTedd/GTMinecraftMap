execute as 5f6b174e-d917-432d-b936-19eaaefff8d9 unless entity @s[tag=trade_farmer_repeat] at @s run tellraw @a[distance=..5] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"My sincere gratitude for aiding the village.","color":"gray"}]
execute as 5f6b174e-d917-432d-b936-19eaaefff8d9 unless entity @s[tag=trade_farmer_repeat] run tag @s add trade_farmer_repeat
advancement revoke @s only projectswords:farmer_trade_repeat
