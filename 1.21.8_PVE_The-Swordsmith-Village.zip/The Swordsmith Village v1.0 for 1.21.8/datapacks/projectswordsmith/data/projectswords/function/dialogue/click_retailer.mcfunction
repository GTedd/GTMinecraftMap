execute as ee10b048-41ae-4d69-ad3e-e66595a73e6f unless entity @s[tag=click_retailer_1] at @s run tellraw @a[distance=..5] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Good day! Name's Nordirbek. I sell only reused goods. My products are not bad for their price, though if you seek higher quality, the Armorer Jacques might serve you better.","color":"gray"}]
execute as ee10b048-41ae-4d69-ad3e-e66595a73e6f unless entity @s[tag=click_retailer_1] run tag @s add click_retailer_1
advancement revoke @s only projectswords:retailer_trade
