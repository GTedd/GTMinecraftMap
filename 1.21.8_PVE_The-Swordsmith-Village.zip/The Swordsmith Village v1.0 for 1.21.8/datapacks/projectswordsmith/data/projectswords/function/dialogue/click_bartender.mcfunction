execute as 58f3ab16-0a61-4cd1-9e0e-e350fe0e6dd2 unless entity @s[tag=click_bartender_1] at @s run tellraw @a[distance=..5] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Aye comrade! You can call me Mika! Need a drink? Try one and your troubles will be gone... for a little while.","color":"gray"}]
execute as 58f3ab16-0a61-4cd1-9e0e-e350fe0e6dd2 unless entity @s[tag=click_bartender_1] run tag @s add click_bartender_1
advancement revoke @s only projectswords:bartender_trade
