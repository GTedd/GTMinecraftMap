execute as 59834455-09a2-4621-8891-aaddb8e2fef9 unless entity @s[tag=trade_scammer_potion] at @s run tellraw @a[distance=..5] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Thanks for buyin'! This Sweet Potion should enhance your combat skills... Good luck, hehe...","color":"gray"}]
execute as 59834455-09a2-4621-8891-aaddb8e2fef9 unless entity @s[tag=trade_scammer_potion] run tag @s add trade_scammer_potion
advancement revoke @s only projectswords:scammer_trade_potion
