execute as fcc42dd6-4cbf-47ea-b6cc-670ae78da842 unless entity @s[tag=trade_shopper_repeat] at @s run tellraw @a[distance=..5] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Many thanks, amigo! Come back soon, ya hear!","color":"gray"}]
execute as fcc42dd6-4cbf-47ea-b6cc-670ae78da842 unless entity @s[tag=trade_shopper_repeat] run tag @s add trade_shopper_repeat
advancement revoke @s only projectswords:shopper_trade_repeat
