tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":" Ah, magnifique! You are my hero! You can take the armor sets if you need them! What else can I do for you, mon ami?","color":"gray"}]
tp @s ~ ~ ~ facing entity @p[team=!Spectator,distance=..10]
tag @a add armorer.saved