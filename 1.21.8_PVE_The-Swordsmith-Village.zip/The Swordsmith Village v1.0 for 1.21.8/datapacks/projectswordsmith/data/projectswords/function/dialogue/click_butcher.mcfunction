execute as df3701e7-1305-4600-bd3d-8632e97b1653 unless entity @s[tag=click_butcher_1] at @s run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Hej! You hungry, ja? You should try my famous brew!","color":"gray"}]
execute as df3701e7-1305-4600-bd3d-8632e97b1653 unless entity @s[tag=click_butcher_1] run tag @s add click_butcher_1
advancement revoke @s only projectswords:butcher_trade
