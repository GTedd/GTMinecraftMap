execute as 59834455-09a2-4621-8891-aaddb8e2fef9 unless entity @s[tag=trade_scammer_swords] at @s run tellraw @a[distance=..5] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Pleasure doin' business with ya! Hehehe...","color":"gray"}]
execute as 59834455-09a2-4621-8891-aaddb8e2fef9 unless entity @s[tag=trade_scammer_swords] run tag @s add trade_scammer_swords
advancement revoke @s only projectswords:scammer_trade_swords
