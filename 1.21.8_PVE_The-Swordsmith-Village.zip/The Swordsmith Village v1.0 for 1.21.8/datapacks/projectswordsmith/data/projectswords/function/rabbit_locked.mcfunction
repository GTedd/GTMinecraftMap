execute if entity @s[distance=..3,tag=in.iceroom,tag=rabbit.tellraw] run tellraw @s [{"text":"<Peppy>","color":"#FF474C"},{"text":" *squeak* *squeak* (bring... gourmet... plz)","color":"white"}]
execute if entity @s[distance=..3,tag=in.iceroom,tag=rabbit.tellraw] run playsound minecraft:entity.rabbit.ambient master @s ~ ~ ~ 10 1
execute if entity @s[distance=..3,tag=in.iceroom] run tag @s remove rabbit.tellraw
execute if entity @s[distance=10..20,tag=in.iceroom] run tag @s add rabbit.tellraw
execute if entity @s[distance=21..30] run tag @s remove rabbit.tellraw