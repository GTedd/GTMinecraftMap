tag @s remove watersword4
scoreboard players reset @s timerweather