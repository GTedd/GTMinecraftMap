tag @s remove icesword1
scoreboard players reset @s timerice