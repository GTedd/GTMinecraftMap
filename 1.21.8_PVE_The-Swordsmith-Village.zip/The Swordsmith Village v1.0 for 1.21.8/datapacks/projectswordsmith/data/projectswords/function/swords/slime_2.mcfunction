tag @s remove slimesword2
scoreboard players reset @s timer2