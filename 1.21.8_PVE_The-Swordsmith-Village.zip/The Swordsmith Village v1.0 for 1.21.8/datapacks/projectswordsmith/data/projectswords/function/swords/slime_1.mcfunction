tag @s remove slimesword1
scoreboard players reset @s timer2