tag @s remove slimesword3
scoreboard players reset @s timer2