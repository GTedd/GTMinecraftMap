tag @s remove magmasword1
scoreboard players reset @s timerfire