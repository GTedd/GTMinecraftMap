tag @s remove magmasword4
scoreboard players reset @s timerfire