tag @s remove icesword2
scoreboard players reset @s timerice