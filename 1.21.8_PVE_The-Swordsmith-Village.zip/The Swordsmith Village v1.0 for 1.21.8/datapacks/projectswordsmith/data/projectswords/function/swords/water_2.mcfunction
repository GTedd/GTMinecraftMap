tag @s remove watersword2
scoreboard players reset @s timerweather