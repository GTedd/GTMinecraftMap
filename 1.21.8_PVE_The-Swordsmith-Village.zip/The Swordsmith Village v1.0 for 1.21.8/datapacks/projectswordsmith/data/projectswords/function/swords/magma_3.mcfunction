tag @s remove magmasword3
scoreboard players reset @s timerfire