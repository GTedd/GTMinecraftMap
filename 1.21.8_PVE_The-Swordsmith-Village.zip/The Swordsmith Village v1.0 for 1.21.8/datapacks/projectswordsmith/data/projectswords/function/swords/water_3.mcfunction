tag @s remove watersword3
scoreboard players reset @s timerweather