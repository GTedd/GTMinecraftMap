tag @s remove watersword1
scoreboard players reset @s timerweather