tag @s remove icesword3
scoreboard players reset @s timerice