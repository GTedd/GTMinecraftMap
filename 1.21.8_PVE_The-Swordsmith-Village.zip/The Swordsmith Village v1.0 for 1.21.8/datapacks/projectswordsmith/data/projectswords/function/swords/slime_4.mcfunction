tag @s remove slimesword4
scoreboard players reset @s timer2