tag @s remove magmasword2
scoreboard players reset @s timerfire