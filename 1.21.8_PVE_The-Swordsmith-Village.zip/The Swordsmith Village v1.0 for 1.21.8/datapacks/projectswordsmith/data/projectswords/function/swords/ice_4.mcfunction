tag @s remove icesword4
scoreboard players reset @s timerice