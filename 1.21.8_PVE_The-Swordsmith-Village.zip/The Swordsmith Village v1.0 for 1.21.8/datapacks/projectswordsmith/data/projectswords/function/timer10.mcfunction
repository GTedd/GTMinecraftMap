#5 second timer#

scoreboard players remove @e[scores={timer=1..}] timer 1
scoreboard players set @e[scores={timer=0}] timer 100

