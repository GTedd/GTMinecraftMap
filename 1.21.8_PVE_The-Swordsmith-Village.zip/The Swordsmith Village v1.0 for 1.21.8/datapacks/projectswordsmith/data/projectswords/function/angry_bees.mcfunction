data merge entity @s {HasStung:0b,AngerTime:1999980}
data modify entity @s AngryAt set from entity @p[team=!Spectator] UUID