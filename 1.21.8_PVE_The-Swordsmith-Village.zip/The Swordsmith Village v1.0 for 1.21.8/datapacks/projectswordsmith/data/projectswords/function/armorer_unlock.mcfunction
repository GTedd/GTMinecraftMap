execute positioned -227 75 93 run kill @e[type=tnt,distance=..4]
particle minecraft:explosion -227 75 93 1 1 1 1 1 force
particle minecraft:explosion_emitter -227 75 93 1.5 1 1.5 1 1 force
particle minecraft:explosion_emitter -227 75 93 1 1.5 1 1 1 force
playsound minecraft:entity.generic.explode block @a -227 75 93 10 1
fill -227 74 94 -228 76 91 air
fill -229 74 92 -229 75 93 air