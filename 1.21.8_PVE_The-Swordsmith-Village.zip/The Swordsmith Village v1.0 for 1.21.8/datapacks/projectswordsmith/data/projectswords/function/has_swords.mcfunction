execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:1b}}}]}] run tag @s add watersword1
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:2b}}}]}] run tag @s add watersword2
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:3b}}}]}] run tag @s add watersword3
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{watersword:4b}}}]}] run tag @s add watersword4

execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:1b}}}]}] run tag @s add magmasword1
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:2b}}}]}] run tag @s add magmasword2
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:3b}}}]}] run tag @s add magmasword3
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{magmasword:4b}}}]}] run tag @s add magmasword4

execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:1b}}}]}] run tag @s add slimesword1
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:2b}}}]}] run tag @s add slimesword2
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:3b}}}]}] run tag @s add slimesword3
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{slimesword:4b}}}]}] run tag @s add slimesword4

execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:1b}}}]}] run tag @s add icesword1
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:2b}}}]}] run tag @s add icesword2
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:3b}}}]}] run tag @s add icesword3
execute as @a[nbt={Inventory:[{id:"minecraft:diamond_sword",count:1,components:{"minecraft:custom_data":{icesword:4b}}}]}] run tag @s add icesword4
