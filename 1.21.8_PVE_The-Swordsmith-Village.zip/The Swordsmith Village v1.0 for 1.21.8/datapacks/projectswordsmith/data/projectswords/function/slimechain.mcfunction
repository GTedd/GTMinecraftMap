setblock -219 44 116 air
setblock -217 41 116 minecraft:redstone_block
setblock -221 41 116 redstone_block
title @a title [{"text":"⏫ ","color":"green","bold":false},{"text":"REBOUND","color":"dark_green","bold":true,"underlined":true},{"text":" ⏫","color":"green","bold":false}]
title @a subtitle [{"text":"All Nearby Mobs Are Sent Flying Upwards!","color":"dark_green","bold":true,"underlined":true}]