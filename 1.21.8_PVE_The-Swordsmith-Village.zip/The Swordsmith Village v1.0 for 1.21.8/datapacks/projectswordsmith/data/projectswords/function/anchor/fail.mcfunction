tag @s remove anchor.night
tag @s remove anchor.started
tag @s remove anchor.held
execute if entity @s[scores={clickevent.compass=1..4},tag=!anchor.failed] run tellraw @s [{"text":"Please hold the ","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":"Anchor","color":"yellow","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" while travelling.","color":"red","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]
execute if entity @s[scores={clickevent.compass=1..4},tag=!anchor.failed] run tag @s add anchor.failed