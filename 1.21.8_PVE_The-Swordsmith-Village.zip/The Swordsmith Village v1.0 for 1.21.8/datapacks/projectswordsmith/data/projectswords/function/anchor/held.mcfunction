# start
tag @s remove anchor.night
execute if entity @s[tag=!anchor.held] run scoreboard players set @s clickevent.compass 0
tag @s add anchor.held
tag @s remove anchor.failed
execute if entity @s[predicate=projectswords:is_sneaking,tag=!anchor.started] run function projectswords:anchor/start

# tp
execute if entity @s[scores={clickevent.compass=1}] run tp @s -250.0 63 178.0 46 -14.5
execute if entity @s[scores={clickevent.compass=2}] run tp @s -161.5 68 164.5 -58.5 -6.0
execute if entity @s[scores={clickevent.compass=3}] run tp @s -213.5 72 43.1 180.0 -34.0
execute if entity @s[scores={clickevent.compass=4}] run tp @s -200.2 64.5 113.5 -90.0 5.0
execute if entity @s[scores={clickevent.compass=1..4}] at @s run playsound minecraft:entity.enderman.teleport master @s ~ ~ ~ 1 1.8

# end
execute if entity @s[scores={clickevent.compass=1..4}] run tag @s remove anchor.started
execute if entity @s[scores={clickevent.compass=1..4}] run scoreboard players reset @s clickevent.compass