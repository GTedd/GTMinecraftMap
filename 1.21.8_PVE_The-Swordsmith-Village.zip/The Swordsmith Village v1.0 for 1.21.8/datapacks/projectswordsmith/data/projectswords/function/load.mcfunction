# Loaded #
tellraw @a [{"text": "Project Swordsmith Datapack Loaded!", "color": "green"}]
execute as @a at @s run playsound minecraft:entity.arrow.hit_player master @s ~ ~ ~ 1 1

# Schedules #
schedule function projectswords:10t 10t replace