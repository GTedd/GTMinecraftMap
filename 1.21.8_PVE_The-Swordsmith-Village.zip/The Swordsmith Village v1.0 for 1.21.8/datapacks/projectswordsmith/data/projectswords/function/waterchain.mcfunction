setblock -219 44 96 air
setblock -218 41 96 redstone_block
setblock -219 41 98 minecraft:redstone_block
execute in minecraft:overworld as @a at @s at @e[tag=Mob,distance=..50] run summon minecraft:lightning_bolt ~ ~ ~
effect give @a[scores={timerweather=..299}] absorption 15 1
title @a title [{"text":"⚡ ","color":"aqua","bold":false},{"text":"THUNDERSTORM","color":"blue","bold":true,"underlined":true},{"text":" ⚡","color":"aqua","bold":false}]
title @a subtitle [{"text":"Thunder And Rain Are Summoned For ","color":"blue","bold":true,"underlined":true},{"text":"15","color":"aqua","bold":true,"underlined":true},{"text":" Seconds!","color":"blue","bold":true,"underlined":true}]
