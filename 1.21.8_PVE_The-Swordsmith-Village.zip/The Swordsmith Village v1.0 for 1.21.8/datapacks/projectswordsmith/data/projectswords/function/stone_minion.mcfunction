scoreboard players add fangs timer20s 1
execute if entity @s[tag=StoneMinion] run teleport @e[distance=..2,type=minecraft:block_display,tag=StoneMinion,limit=1,sort=nearest] ~-0.25 ~ ~-0.25
execute if score fangs timer20s matches 39 run summon evoker_fangs ^ ^ ^2 {Tags:["Mob"],CustomName:[{"color":"green","text":"[Monster] "},{"color":"dark_red","text":"Fang"}]}
execute if score fangs timer20s matches 29 run summon evoker_fangs ^ ^ ^-2 {Tags:["Mob"],CustomName:[{"color":"green","text":"[Monster] "},{"color":"dark_red","text":"Fang"}]}
execute if score fangs timer20s matches 19 run summon evoker_fangs ^2 ^ ^ {Tags:["Mob"],CustomName:[{"color":"green","text":"[Monster] "},{"color":"dark_red","text":"Fang"}]}
execute if score fangs timer20s matches 9 run summon evoker_fangs ^-2 ^ ^ {Tags:["Mob"],CustomName:[{"color":"green","text":"[Monster] "},{"color":"dark_red","text":"Fang"}]}