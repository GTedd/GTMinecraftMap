execute if data entity @s {Health:275f} run tag @s add 9ball
execute if entity @s[tag=9ball,tag=8hurt] if data entity @s {HurtTime:1s,Health:275f} run data merge entity @e[type=ghast,limit=1] {Health:250f}

execute if data entity @s {Health:300f} run tag @s add 8ball
execute if entity @s[tag=8ball,tag=7hurt] if data entity @s {HurtTime:1s,Health:300f} run tag @s add 8hurt
execute if entity @s[tag=8ball,tag=7hurt] if data entity @s {HurtTime:1s,Health:300f} run data merge entity @e[type=ghast,limit=1] {Health:275f}

execute if data entity @s {Health:325f} run tag @s add 7ball
execute if entity @s[tag=7ball,tag=6hurt] if data entity @s {HurtTime:1s,Health:325f} run tag @s add 7hurt
execute if entity @s[tag=7ball,tag=6hurt] if data entity @s {HurtTime:1s,Health:325f} run data merge entity @e[type=ghast,limit=1] {Health:300f}

execute if data entity @s {Health:350f} run tag @s add 6ball
execute if entity @s[tag=6ball,tag=5hurt] if data entity @s {HurtTime:1s,Health:350f} run tag @s add 6hurt
execute if entity @s[tag=6ball,tag=5hurt] if data entity @s {HurtTime:1s,Health:350f} run data merge entity @e[type=ghast,limit=1] {Health:325f}

execute if data entity @s {Health:375f} run tag @s add 5ball
execute if entity @s[tag=5ball,tag=4hurt] if data entity @s {HurtTime:1s,Health:375f} run tag @s add 5hurt
execute if entity @s[tag=5ball,tag=4hurt] if data entity @s {HurtTime:1s,Health:375f} run data merge entity @e[type=ghast,limit=1] {Health:350f}

execute if data entity @s {Health:400f} run tag @s add 4ball
execute if entity @s[tag=4ball,tag=3hurt] if data entity @s {HurtTime:1s,Health:400f} run tag @s add 4hurt
execute if entity @s[tag=4ball,tag=3hurt] if data entity @s {HurtTime:1s,Health:400f} run data merge entity @e[type=ghast,limit=1] {Health:375f}

execute if data entity @s {Health:425f} run tag @s add 3ball
execute if entity @s[tag=3ball,tag=2hurt] if data entity @s {HurtTime:1s,Health:425f} run tag @s add 3hurt
execute if entity @s[tag=3ball,tag=2hurt] if data entity @s {HurtTime:1s,Health:425f} run data merge entity @e[type=ghast,limit=1] {Health:400f}

execute if data entity @s {Health:450f} run tag @s add 2ball
execute if entity @s[tag=2ball,tag=1hurt] if data entity @s {HurtTime:1s,Health:450f} run tag @s add 2hurt
execute if entity @s[tag=2ball,tag=1hurt] if data entity @s {HurtTime:1s,Health:450f} run data merge entity @e[type=ghast,limit=1] {Health:425f}

execute if data entity @s {Health:475f} run tag @s add 1ball
execute if entity @s[tag=1ball,tag=0hurt] if data entity @s {HurtTime:1s,Health:475f} run tag @s add 1hurt
execute if entity @s[tag=1ball,tag=0hurt] if data entity @s {HurtTime:1s,Health:475f} run data merge entity @e[type=ghast,limit=1] {Health:450f}

execute if data entity @s {Health:500f} run tag @s add 0ball
execute if entity @s[tag=0ball] if data entity @s {HurtTime:1s,Health:500f} run tag @s add 0hurt
execute if entity @s[tag=0hurt] if data entity @s {HurtTime:1s,Health:500f} run data merge entity @e[type=ghast,limit=1] {Health:475f}

execute if data entity @s {Health:250f} run tag @s add stage2

execute if data entity @s {HurtTime:1s} run tag @s remove can_takeDMG