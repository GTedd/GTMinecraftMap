execute if predicate projectswords:armor run item modify entity @s armor.head projectswords:enchant/protection
execute if predicate projectswords:armor run item modify entity @s armor.chest projectswords:enchant/protection
execute if predicate projectswords:armor run item modify entity @s armor.legs projectswords:enchant/protection
execute if predicate projectswords:armor run item modify entity @s armor.feet projectswords:enchant/protection
execute if predicate projectswords:armor run setblock -258 35 77 minecraft:redstone_block
execute if predicate projectswords:armor run item replace entity @s weapon with air 1
execute unless predicate projectswords:armor if entity @s[nbt={Inventory:[{Slot:100b}]}] run tag @s add prot_confirm
execute unless predicate projectswords:armor if entity @s[nbt={Inventory:[{Slot:101b}]}] run tag @s add prot_confirm
execute unless predicate projectswords:armor if entity @s[nbt={Inventory:[{Slot:102b}]}] run tag @s add prot_confirm
execute unless predicate projectswords:armor if entity @s[nbt={Inventory:[{Slot:103b}]}] run tag @s add prot_confirm
execute unless predicate projectswords:armor if entity @s[tag=prot_confirm] run tellraw @s {"color":"red","text":"Missing compatible items in the Armor Slots!"}
execute unless predicate projectswords:armor unless entity @s[tag=prot_confirm] run tellraw @s {"color":"red","text":"No compatible items found in the Armor Slots!"}