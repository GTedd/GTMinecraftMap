execute if predicate projectswords:offhand run item modify entity @s weapon.offhand projectswords:enchant/sharpness
execute if predicate projectswords:offhand run setblock -258 35 77 minecraft:redstone_block
execute if predicate projectswords:offhand run item replace entity @s weapon with air 1
execute unless predicate projectswords:offhand run tellraw @s {"color":"red","text":"Incompatible item in the Offhand Slot!"}