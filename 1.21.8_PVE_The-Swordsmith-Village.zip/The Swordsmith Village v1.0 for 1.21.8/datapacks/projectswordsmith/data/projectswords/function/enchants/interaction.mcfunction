execute if data entity @s interaction on target if entity @s[nbt={SelectedItem:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:protection":1}}}}] run function projectswords:enchants/protection
execute if data entity @s interaction run tag @a remove prot_confirm

execute if data entity @s interaction on target if entity @s[nbt={SelectedItem:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:unbreaking":1}}}}] run function projectswords:enchants/unbreaking
execute if data entity @s interaction run tag @a remove unb_confirm

execute if data entity @s interaction on target if entity @s[nbt={SelectedItem:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:looting":1}}}}] run function projectswords:enchants/looting

execute if data entity @s interaction on target if entity @s[nbt={SelectedItem:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:sharpness":1}}}}] run function projectswords:enchants/sharpness

execute if data entity @s interaction on target if entity @s[nbt={SelectedItem:{id:"minecraft:enchanted_book",count:1,components:{"minecraft:stored_enchantments":{"minecraft:mending":1}}}}] run function projectswords:enchants/mending
execute if data entity @s interaction run tag @a remove mend_confirm

data remove entity @s interaction