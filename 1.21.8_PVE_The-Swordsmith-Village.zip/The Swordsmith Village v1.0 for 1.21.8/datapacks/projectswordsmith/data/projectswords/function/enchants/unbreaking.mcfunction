execute if predicate projectswords:armor if predicate projectswords:offhand run item modify entity @s armor.head projectswords:enchant/unbreaking
execute if predicate projectswords:armor if predicate projectswords:offhand run item modify entity @s armor.chest projectswords:enchant/unbreaking
execute if predicate projectswords:armor if predicate projectswords:offhand run item modify entity @s armor.legs projectswords:enchant/unbreaking
execute if predicate projectswords:armor if predicate projectswords:offhand run item modify entity @s armor.feet projectswords:enchant/unbreaking
execute if predicate projectswords:armor if predicate projectswords:offhand run item modify entity @s weapon.offhand projectswords:enchant/unbreaking
execute if predicate projectswords:armor if predicate projectswords:offhand run setblock -258 35 77 minecraft:redstone_block
execute if predicate projectswords:armor if predicate projectswords:offhand run item replace entity @s weapon with air 1
execute if predicate projectswords:armor unless predicate projectswords:offhand run tellraw @s {"color":"red","text":"Missing compatible item in the Offhand Slot!"}
execute unless predicate projectswords:armor if entity @s[nbt={Inventory:[{Slot:100b}]}] run tag @s add unb_confirm
execute unless predicate projectswords:armor if entity @s[nbt={Inventory:[{Slot:101b}]}] run tag @s add unb_confirm
execute unless predicate projectswords:armor if entity @s[nbt={Inventory:[{Slot:102b}]}] run tag @s add unb_confirm
execute unless predicate projectswords:armor if entity @s[nbt={Inventory:[{Slot:103b}]}] run tag @s add unb_confirm
execute if entity @s[nbt={Inventory:[{Slot:-106b}]}] unless predicate projectswords:armor run tellraw @s {"color":"red","text":"Missing compatible items in the Armor Slots!"}
execute unless entity @s[nbt={Inventory:[{Slot:-106b}]}] unless predicate projectswords:armor run tellraw @s {"color":"red","text":"No compatible items found in the Armor or Offhand Slots!"}