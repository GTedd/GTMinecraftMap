execute positioned -170 69 56 if block ~ ~ ~ air run tag @a add tuff1
execute positioned -169 69 56 if block ~ ~ ~ air run tag @a add tuff2
execute positioned -169 68 56 if block ~ ~ ~ air run tag @a add tuff3
execute positioned -168 69 56 if block ~ ~ ~ air run tag @a add tuff4
execute positioned -168 70 56 if block ~ ~ ~ air run tag @a add tuff5
execute positioned -163 69 61 if block ~ ~ ~ air run tag @a add tuff6
execute positioned -163 70 61 if block ~ ~ ~ air run tag @a add tuff7
execute positioned -163 70 60 if block ~ ~ ~ air run tag @a add tuff8
execute positioned -163 71 60 if block ~ ~ ~ air run tag @a add tuff9
execute positioned -174 68 56 if block ~ ~ ~ air run tag @a add tuff10
execute positioned -173 67 56 if block ~ ~ ~ air run tag @a add tuff11
execute positioned -174 67 57 if block ~ ~ ~ air run tag @a add tuff12
execute positioned -165 72 59 if block ~ ~ ~ air run tag @a add tuff13
execute positioned -165 73 59 if block ~ ~ ~ air run tag @a add tuff14
execute positioned -166 73 59 if block ~ ~ ~ air run tag @a add tuff15
execute positioned -165 68 59 if block ~ ~ ~ air run tag @a add tuff16
execute positioned -166 67 59 if block ~ ~ ~ air run tag @a add tuff17
execute positioned -166 67 60 if block ~ ~ ~ air run tag @a add tuff18
execute positioned -167 66 60 if block ~ ~ ~ air run tag @a add tuff19
execute positioned -166 66 61 if block ~ ~ ~ air run tag @a add tuff20
execute positioned -168 68 65 if block ~ ~ ~ air run tag @a add tuff21
execute positioned -169 67 64 if block ~ ~ ~ air run tag @a add tuff22
execute positioned -172 66 60 if block ~ ~ ~ air run tag @a add tuff23
execute positioned -173 71 56 if block ~ ~ ~ air run tag @a add tuff24
execute positioned -174 70 56 if block ~ ~ ~ air run tag @a add tuff25
execute positioned -165 68 63 if block ~ ~ ~ air run tag @a add tuff26
execute positioned -170 66 59 if block ~ ~ ~ air run tag @a add tuff27

execute positioned -170 69 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -169 69 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -169 68 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -168 69 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -168 70 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -163 69 61 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -163 70 61 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -163 70 60 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -163 71 60 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -174 68 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -173 67 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -174 67 57 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -165 72 59 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -165 73 59 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -166 73 59 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -165 68 59 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -166 67 59 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -166 67 60 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -167 66 60 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -166 66 61 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -168 68 65 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -169 67 64 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -172 66 60 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -173 71 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -174 70 56 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -165 68 63 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force
execute positioned -170 66 59 if block ~ ~ ~ air run particle block{block_state:"minecraft:dead_brain_coral"} ~ ~0.5 ~ 0.2 0.2 0.2 0 3 force

execute positioned -170 69 56 if block ~ ~ ~ air run setblock -239 35 78 redstone_block
execute positioned -169 69 56 if block ~ ~ ~ air run setblock -238 35 78 redstone_block
execute positioned -169 68 56 if block ~ ~ ~ air run setblock -237 35 78 redstone_block
execute positioned -168 69 56 if block ~ ~ ~ air run setblock -236 35 78 redstone_block
execute positioned -168 70 56 if block ~ ~ ~ air run setblock -235 35 78 redstone_block
execute positioned -163 69 61 if block ~ ~ ~ air run setblock -235 35 79 redstone_block
execute positioned -163 70 61 if block ~ ~ ~ air run setblock -236 35 79 redstone_block
execute positioned -163 70 60 if block ~ ~ ~ air run setblock -237 35 79 redstone_block
execute positioned -163 71 60 if block ~ ~ ~ air run setblock -238 35 79 redstone_block
execute positioned -174 68 56 if block ~ ~ ~ air run setblock -239 35 79 redstone_block
execute positioned -173 67 56 if block ~ ~ ~ air run setblock -239 35 80 redstone_block
execute positioned -174 67 57 if block ~ ~ ~ air run setblock -238 35 80 redstone_block
execute positioned -165 72 59 if block ~ ~ ~ air run setblock -237 35 80 redstone_block
execute positioned -165 73 59 if block ~ ~ ~ air run setblock -236 35 80 redstone_block
execute positioned -166 73 59 if block ~ ~ ~ air run setblock -235 35 80 redstone_block
execute positioned -165 68 59 if block ~ ~ ~ air run setblock -239 35 82 redstone_block
execute positioned -166 67 59 if block ~ ~ ~ air run setblock -238 35 82 redstone_block
execute positioned -166 67 60 if block ~ ~ ~ air run setblock -237 35 82 redstone_block
execute positioned -167 66 60 if block ~ ~ ~ air run setblock -236 35 82 redstone_block
execute positioned -166 66 61 if block ~ ~ ~ air run setblock -236 35 83 redstone_block
execute positioned -168 68 65 if block ~ ~ ~ air run setblock -237 35 83 redstone_block
execute positioned -169 67 64 if block ~ ~ ~ air run setblock -238 35 83 redstone_block
execute positioned -172 66 60 if block ~ ~ ~ air run setblock -239 35 83 redstone_block
execute positioned -173 71 56 if block ~ ~ ~ air run setblock -239 35 84 redstone_block
execute positioned -174 70 56 if block ~ ~ ~ air run setblock -238 35 84 redstone_block
execute positioned -165 68 63 if block ~ ~ ~ air run setblock -237 35 84 redstone_block
execute positioned -170 66 59 if block ~ ~ ~ air run setblock -236 35 84 redstone_block

execute positioned -170 69 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -239 35 78 air
execute positioned -169 69 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -238 35 78 air
execute positioned -169 68 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -237 35 78 air
execute positioned -168 69 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -236 35 78 air
execute positioned -168 70 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -235 35 78 air
execute positioned -163 69 61 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -235 35 79 air
execute positioned -163 70 61 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -236 35 79 air
execute positioned -163 70 60 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -237 35 79 air
execute positioned -163 71 60 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -238 35 79 air
execute positioned -174 68 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -239 35 79 air
execute positioned -173 67 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -239 35 80 air
execute positioned -174 67 57 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -238 35 80 air
execute positioned -165 72 59 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -237 35 80 air
execute positioned -165 73 59 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -236 35 80 air
execute positioned -166 73 59 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -235 35 80 air
execute positioned -165 68 59 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -239 35 82 air
execute positioned -166 67 59 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -238 35 82 air
execute positioned -166 67 60 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -237 35 82 air
execute positioned -167 66 60 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -236 35 82 air
execute positioned -166 66 61 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -236 35 83 air
execute positioned -168 68 65 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -237 35 83 air
execute positioned -169 67 64 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -238 35 83 air
execute positioned -172 66 60 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -239 35 83 air
execute positioned -173 71 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -239 35 84 air
execute positioned -174 70 56 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -238 35 84 air
execute positioned -165 68 63 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -237 35 84 air
execute positioned -170 66 59 if block ~ ~ ~ minecraft:dead_brain_coral_block run setblock -236 35 84 air
