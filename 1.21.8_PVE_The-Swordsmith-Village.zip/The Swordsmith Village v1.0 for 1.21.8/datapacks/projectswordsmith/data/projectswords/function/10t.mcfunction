# Items #
execute positioned -276 78 154 run kill @e[distance=..5,type=item,nbt={Item:{id:"minecraft:dropper"}}]
execute positioned -250 35 132 as @e[distance=..5,type=item] run kill @s

# Player Health #
execute as @a[team=!Spectator] store result score @s player.health run data get entity @s Health

# Hooks #
execute positioned -214 74 35 run kill @e[type=item,nbt={Item:{id:"minecraft:tripwire_hook",count:1}},nbt=!{Item:{id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{trapdoor:1b}}}},distance=..5,nbt=!{Item:{id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}}}}]
execute positioned -276 67 151 run kill @e[type=item,nbt={Item:{id:"minecraft:tripwire_hook",count:1}},nbt=!{Item:{id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{trapdoor:1b}}}},distance=..5,nbt=!{Item:{id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}}}}]

# Kills #
# Blaze
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=block_display,tag=FireDisplay1] at @s unless entity @e[type=blaze,distance=..5] run kill @s
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=block_display,tag=FireDisplay2] at @s unless entity @e[type=blaze,distance=..5] run kill @s
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=block_display,tag=FireDisplay3] at @s unless entity @e[type=blaze,distance=..5] run kill @s
# Honey
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=minecraft:area_effect_cloud,tag=HoneyDecay] at @s unless entity @e[type=zombie,tag=NoGlow,distance=..2] run kill @s
# Overcharged
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=minecraft:armor_stand,tag=Spin] at @s run function projectswords:overcharged
#summon: /summon creeper ~ ~ ~ {CustomNameVisible:1b,Silent:0b,PersistenceRequired:1b,Health:40f,powered:1b,ExplosionRadius:3b,Tags:["Mob"],Passengers:[{id:"minecraft:armor_stand",Silent:0b,Invulnerable:1b,Small:1b,Marker:1b,Invisible:1b,NoBasePlate:1b,PersistenceRequired:1b,Tags:["Spin"]}],CustomName:'[{"text":"[Subterranean]","color":"dark_gray","bold":true,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false},{"text":" Overcharged","color":"green","bold":false,"italic":false,"underlined":false,"strikethrough":false,"obfuscated":false}]',Attributes:[{Name:generic.max_health,Base:40}]}
# Guardian
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=guardian,tag=MiniBoss1] at @s unless entity @e[type=drowned,distance=..3] run kill @s
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=guardian,tag=MiniBoss2] at @s unless entity @e[type=drowned,distance=..3] run kill @s
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=guardian,tag=MiniBoss3] at @s unless entity @e[type=drowned,distance=..3] run kill @s
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=armor_stand,tag=MiniBoss1] at @s unless entity @e[type=drowned,distance=..3] run kill @s
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=armor_stand,tag=MiniBoss2] at @s unless entity @e[type=drowned,distance=..3] run kill @s
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=armor_stand,tag=MiniBoss3] at @s unless entity @e[type=drowned,distance=..3] run kill @s
# Vex
execute positioned -191.99 79.90 114.00 as @e[distance=..200,type=vex,tag=!Mob] at @s unless entity @e[distance=..50,type=evoker] run kill @s
# Lightning
execute positioned -195 42 -10 as @e[distance=..500,type=minecraft:lightning_bolt] at @s if entity @e[type=minecraft:villager,distance=..5] run kill @s

# Fireball #
execute positioned -178.52 36.00 -0.49 as @e[distance=..100,type=minecraft:fireball] run data merge entity @s {Item:{id:"minecraft:cobblestone",count:1},Fire:-20,HasVisualFire:0b,ExplosionPower:3b}

# Bossbars #
bossbar set minecraft:daytimer players @a[tag=daybar]
bossbar set minecraft:nighttimer players @a[tag=nightbar]

# Setup #
execute as @a[tag=setup] run function projectswords:setup

# Saturation #
execute positioned 0 100 0 as @a[distance=..20] run effect give @s saturation 1 0 true
execute positioned 0 100 0 as @a[distance=21..,tag=!housetp] run effect clear @s saturation

# Gamerules #
execute as @a[tag=easy_difficulty] run gamerule naturalRegeneration true
execute as @a[tag=easy_difficulty] run gamerule keepInventory true
execute as @a[tag=easy_difficulty] run gamerule fallDamage false
execute as @a[tag=!easy_difficulty] run gamerule fallDamage true
execute as @a[tag=!housetp] run gamerule fallDamage false
execute as @a[tag=medium_difficulty] run gamerule naturalRegeneration true
execute as @a[tag=medium_difficulty] run gamerule keepInventory true
execute as @a[tag=hard_difficulty] run gamerule naturalRegeneration false
execute as @a[tag=hard_difficulty] run gamerule keepInventory true

# Charms #
# SeaStride
execute as @a[nbt={equipment:{offhand:{id:"minecraft:heart_of_the_sea"}}}] run effect give @s water_breathing 1 0 true
execute as @a[nbt={equipment:{offhand:{id:"minecraft:heart_of_the_sea"}}}] run effect give @s dolphins_grace 1 0 true
execute as @a[nbt={SelectedItem:{id:"minecraft:heart_of_the_sea"}}] run effect give @s water_breathing 1 0 true
execute as @a[nbt={SelectedItem:{id:"minecraft:heart_of_the_sea"}}] run effect give @s dolphins_grace 1 0 true
# Safeguard 
execute as @a if data entity @s {equipment:{offhand:{id:"minecraft:shulker_shell"}}} run function projectswords:charms/safeguard
execute as @a if data entity @s {SelectedItem:{id:"minecraft:shulker_shell"}} run function projectswords:charms/safeguard

# Nighttime #
execute as @a[tag=night] positioned -191.99 79.90 114.00 run schedule function projectswords:mob_data 30t replace

# Recall
schedule function projectswords:10t 10t replace