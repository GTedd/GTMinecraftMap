#tags
tag 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 remove night
tag @a remove nightbar
tag @a remove night
tag @a[tag=housetp] add daybar
tag 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 add day
execute as 9f2261a1-8ef1-4dd2-8ce8-9e5f0b28da63 if entity @s[tag=day] run tag @a add day
tag @a remove clone.ran
#scores
scoreboard players set dummy random 0

# StartDay #
execute as @a unless entity @s[tag=day0] unless entity @s[tag=day1,tag=!transition1] run time set day

# OpenGates #
fill -275 70 150 -277 67 150 air
fill -215 74 35 -213 77 35 air

# Butcher #
#execute positioned -191.99 79.90 114.00 as @e[distance=..100,type=pig,tag=butcher] at @s run particle minecraft:block redstone_block ~ ~0.1 ~ 0.2 0 0.2 1 2 normal
execute as @a at @s if block ~ ~-0.2 ~ minecraft:stonecutter run damage @s 0.1 minecraft:cactus

# PlaceVillagers #
execute unless entity @a[tag=tp.ran.villagers] run function projectswords:day_once
tag @a add tp.ran.villagers

# Resets #
#kills
execute positioned -191.99 79.90 114.00 run kill @e[tag=Mob,distance=..300]
execute positioned -191.99 79.90 114.00 run kill @e[type=drowned,distance=..300]
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=splash_potion] run kill @s
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=arrow] run scoreboard players add @s timer 1
execute positioned -191.99 79.90 114.00 as @e[distance=..300,type=arrow] if score @s timer matches 200 run kill @s

# NPCs #
#armorer
execute positioned -231 74 92 as @p[team=!Spectator,tag=!key.dropped,distance=..1.6] run summon item -232.5 75 89.00 {Age:-32768,PickupDelay:20,Item:{id:"minecraft:tripwire_hook",count:1,components:{"minecraft:custom_name":{"bold":false,"color":"dark_gray","italic":false,"obfuscated":false,"strikethrough":false,"text":"Upstairs Key","underlined":false},"minecraft:custom_data":{trapdoor:1b,NoPickup:1b}}}}
execute positioned -231 74 92 as @p[team=!Spectator,tag=!key.dropped,distance=..1.6] as a6331fcd-5172-4df7-ae12-73cc5eb5402e at @s run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":" Ah, monsieur! Yes, you! Look, up here! I dropped my ","color":"gray"},{"text":"Key","color":"gold"},{"text":"! You will pick it up for me, yes?","color":"gray"}]
execute positioned -231 74 92 as @p[team=!Spectator,tag=!key.dropped,distance=..1.6] run tag @a add key.dropped
execute positioned -231 74 92 as @a[distance=..10,tag=key.dropped,tag=!has.key] if entity @s[nbt={Inventory:[{id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{trapdoor:1b}}}]}] as a6331fcd-5172-4df7-ae12-73cc5eb5402e at @s run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":" Yes! That's the one! Merci, mon ami! Now come up the ladders and unlock this for me!","color":"gray"}]
execute positioned -231 74 92 as @a[distance=..10,tag=key.dropped,tag=!has.key] if entity @s[nbt={Inventory:[{id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{trapdoor:1b}}}]}] run tag @s add has.key
execute positioned -235.5 80.5 90.5 if entity @a[distance=..1,tag=has.key,tag=!armorer.saved] as a6331fcd-5172-4df7-ae12-73cc5eb5402e at @s run function projectswords:dialogue/approach_armorer_1
#execute if entity @a[tag=armorer.saved] as a6331fcd-5172-4df7-ae12-73cc5eb5402e at @s if score @p timer matches 1 run tp @s ~ ~ ~ facing entity @p[team=!Spectator,distance=..10]
#apprentice
execute as 29344ae4-8b41-42e5-84a0-4f1cffcb7b94 at @s if entity @a[distance=..2,tag=!apprentice.talked] run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Heard you talkin' to ","color":"gray"},{"text":"Sensei","color":"dark_red","bold":false},{"text":". Y'know he never once gifted me anything, much less let me touch his weapons. I guess you're just ","color":"gray"},{"text":"special","color":"gold","bold":false},{"text":" to him.","color":"gray"}]
execute as 29344ae4-8b41-42e5-84a0-4f1cffcb7b94 at @s if entity @a[distance=..2,tag=!apprentice.talked] run tag @a add apprentice.talked
#climber
execute as 9dbb94cc-920f-40d6-af06-6fe169bd21ff at @s as @a[distance=..10,tag=!theo.1] run tellraw @s [{"text":"<Theodoros> ","color":"#FF962E"},{"text":"I, Theodoros, flee the village, climbing the mountain. Father ","color":"white"},{"text":"Amari","color":"#524e4e"},{"text":" is a fool. I will climb to the top. I will find my own way.","color":"white"}]
execute as 9dbb94cc-920f-40d6-af06-6fe169bd21ff at @s as @a[distance=..10,tag=!theo.1] run tellraw @s [{"italic":true,"text":"You feel inspired by Theodoros' words. What if you could leave this village, too?","color":"gold"}]
execute as 9dbb94cc-920f-40d6-af06-6fe169bd21ff at @s if entity @a[distance=..10,tag=!theo.1] run playsound minecraft:entity.villager.no master @a ~ ~ ~ 3 1.6
execute as 9dbb94cc-920f-40d6-af06-6fe169bd21ff at @s as @a[distance=..10,tag=!theo.1] run tag @s add theo.1
#miner
execute as 975bcf8a-1e63-4396-ad99-d31de7b93a0d at @s run function projectswords:miner
#fletcher
execute as a5f818a2-9e88-40f4-9178-47d63ef5dba6 at @s if entity @p[team=!Spectator,distance=..3] run setblock -239 40 104 redstone_block
execute as a5f818a2-9e88-40f4-9178-47d63ef5dba6 at @s as @e[distance=..10,type=armor_stand,tag=zp,limit=1,sort=nearest] run tp @s ~ ~ ~ facing entity @p[team=!Spectator]
execute as a5f818a2-9e88-40f4-9178-47d63ef5dba6 at @s if entity @a[distance=..5] run data modify entity @s Rotation set from entity @n[distance=..5,type=armor_stand,tag=zp] Rotation
execute as a5f818a2-9e88-40f4-9178-47d63ef5dba6 at @s unless entity @a[distance=..5] run data modify entity @s Rotation set from entity @n[distance=..5,type=armor_stand,tag=yp] Rotation
#mason
execute as 84dbcb45-052f-45d5-83d2-20690b218504 at @s if entity @p[team=!Spectator,distance=..4] run setblock -239 42 104 redstone_block
execute as 84dbcb45-052f-45d5-83d2-20690b218504 at @s as @e[distance=..10,type=armor_stand,tag=xp,limit=1,sort=nearest] run tp @s ~ ~ ~ facing entity @p[team=!Spectator]
execute as 84dbcb45-052f-45d5-83d2-20690b218504 at @s if entity @a[distance=..5] run data modify entity @s Rotation set from entity @n[distance=..5,type=armor_stand,tag=xp] Rotation
execute as 84dbcb45-052f-45d5-83d2-20690b218504 at @s unless entity @a[distance=..5] run data modify entity @s Rotation set from entity @n[distance=..5,type=armor_stand,tag=yp] Rotation
#miner
#execute as 975bcf8a-1e63-4396-ad99-d31de7b93a0d at @s if score @p timer20s matches 1 run tp @s ~ ~ ~ facing entity @p[team=!Spectator,distance=..20]
#shopper#
execute as fcc42dd6-4cbf-47ea-b6cc-670ae78da842 at @s if entity @p[team=!Spectator,distance=5..] run tag @s remove trade_shopper_repeat
#farmer
execute as 5f6b174e-d917-432d-b936-19eaaefff8d9 at @s if entity @p[team=!Spectator,distance=5..] run tag @s remove trade_farmer_repeat
#execute as 5f6b174e-d917-432d-b936-19eaaefff8d9 at @s if score @p timer20s matches 1 run tp @s ~ ~ ~ facing entity @p[team=!Spectator,distance=..20]
#fisher
execute as cc7c202c-7e8d-4f92-9272-f6421091a3ae at @s if entity @p[team=!Spectator,distance=5..] run tag @s remove trade_fisher_repeat
#cleric
execute as a2b887d5-fede-4abd-8662-957bbe3ba81e at @s if entity @p[team=!Spectator,distance=5..] run tag @s remove trade_cleric_repeat
#elder
execute as 6289716a-679f-4ddf-b3dd-c185e197726c at @s if entity @p[team=!Spectator,distance=..5,tag=!by.elder] run tellraw @a[distance=..10] [{"text":"<"},{"selector":"@s"},{"text":"> "},{"text":"Welcome, our guardian, to the ","color":"gray"},{"text":"Apologue Altar","color":"gold","bold":false},{"text":". I have been waiting for you to arrive.","color":"gray"}]
execute as 6289716a-679f-4ddf-b3dd-c185e197726c at @s if entity @p[team=!Spectator,distance=..5,tag=!by.elder] run tag @a add by.elder
#swordsmith
#execute as 26d6176b-0201-4c9e-a80b-d46300ae7d9a at @s if entity @a[distance=..5] run teleport @s ~ ~ ~ facing entity @p[team=!Spectator]