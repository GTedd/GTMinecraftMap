#bossbar
bossbar set minecraft:nighttimer max 939

#gamerules
gamerule doMobLoot true
gamerule doDaylightCycle true

#clone
clone -223 63 44 -225 66 43 -277 67 149
execute unless score day0 transition matches 1.. run clone -225 63 41 -223 66 40 -215 74 35
tag @a add clone.ran