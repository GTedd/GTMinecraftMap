execute if entity @a[tag=parrot.unlocked,distance=..3,nbt={foodLevel:14}] run particle minecraft:happy_villager ~ ~ ~ 1 1 1 0 10 normal
execute as @a[tag=parrot.unlocked,distance=..3,nbt={foodLevel:14}] run playsound minecraft:entity.generic.eat master @s ~ ~ ~ 1 1
effect give @a[tag=parrot.unlocked,distance=..3,nbt={foodLevel:14}] minecraft:saturation 10 5 false
execute at @p[team=!Spectator,tag=parrot.unlocked] positioned ~ ~1.4 ~ run tp @s ^-0.4 ^ ^-0.5 ~ ~