effect give @s regeneration 2 4 false
particle minecraft:heart ~ ~0.5 ~ 0.3 0.5 0.3 0 10 force
playsound minecraft:entity.allay.ambient_with_item block @a ~ ~ ~ 1.5 0.45
tag @s add executed