scoreboard players set @s reset.wasHere 1
tp @s 0 101 0 -90 0
execute if entity @a[tag=day1] run tag @s add day1
execute if entity @a[tag=housetp] run tellraw @s [{"text":"You joined while a game is occuring. You will Spectate this game.","color":"dark_red"}]
execute if entity @a[tag=housetp] run tag @s add housetp
execute if entity @a[tag=housetp] run team join Spectator @s