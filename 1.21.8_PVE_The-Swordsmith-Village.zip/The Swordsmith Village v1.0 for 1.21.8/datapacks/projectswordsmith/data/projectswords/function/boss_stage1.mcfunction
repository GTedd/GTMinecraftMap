effect give @s minecraft:resistance infinite 3 true
execute if entity @s[tag=!stage2] run scoreboard players add @s cagemobs 1
execute if entity @s[tag=!stage2] if score @s cagemobs matches 50 run kill @e[distance=..50,type=fireball,limit=1]
execute if entity @s[tag=!stage2] if score @s cagemobs matches 99 run tag @s remove can_takeDMG
execute if entity @s[tag=!stage2] if score @s cagemobs matches 100 at @s facing entity @p eyes positioned 0.0 0.0 0.0 run summon marker ^ ^ ^2 {Tags:["fireball.d"]}
execute if entity @s[tag=!stage2] if score @s cagemobs matches 100 at @s anchored feet run summon fireball ^ ^ ^1.5 {acceleration_power:0.1d,Tags:["fireball.s"]}
execute if entity @s[tag=!stage2] if score @s cagemobs matches 100 run data modify entity @e[type=fireball,tag=fireball.s,limit=1] Motion set from entity @e[type=marker,tag=fireball.d,limit=1] Pos
execute if entity @s[tag=!stage2] if score @s cagemobs matches 100 run tag @e[type=fireball,tag=fireball.s,limit=1] remove fireball.s
execute if entity @s[tag=!stage2] if score @s cagemobs matches 100 run kill @e[type=marker,tag=fireball.d]
execute if entity @s[tag=!stage2] if data entity @e[limit=1,distance=..50,type=fireball,sort=nearest] Owner run tag @s add can_takeDMG
execute if score @s cagemobs matches 100 run scoreboard players reset @s
execute unless entity @a[tag=cagelimit] run scoreboard players add timer cagemobs 1
execute if score players difficulty matches 1 unless score timer cagemobs matches 599 run scoreboard players reset random cagemobs
execute if score players difficulty matches 1 if score timer cagemobs matches 599 store result score random cagemobs run random value 1..16
execute if score players difficulty matches 2 unless score timer cagemobs matches 399 run scoreboard players reset random cagemobs
execute if score players difficulty matches 2 if score timer cagemobs matches 399 store result score random cagemobs run random value 1..16
execute if score players difficulty matches 3 unless score timer cagemobs matches 299 run scoreboard players reset random cagemobs
execute if score players difficulty matches 3 if score timer cagemobs matches 299 store result score random cagemobs run random value 1..16
execute if score players difficulty matches 4.. unless score timer cagemobs matches 199 run scoreboard players reset random cagemobs
execute if score players difficulty matches 4.. if score timer cagemobs matches 199 store result score random cagemobs run random value 1..16
execute if score random cagemobs matches 1 run function projectswords:summon_cage/1
execute if score random cagemobs matches 2 run function projectswords:summon_cage/2
execute if score random cagemobs matches 3 run function projectswords:summon_cage/3
execute if score random cagemobs matches 4 run function projectswords:summon_cage/4
execute if score random cagemobs matches 5 run function projectswords:summon_cage/5
execute if score random cagemobs matches 6 run function projectswords:summon_cage/6
execute if score random cagemobs matches 7 run function projectswords:summon_cage/7
execute if score random cagemobs matches 8 run function projectswords:summon_cage/8
execute if score random cagemobs matches 9 run function projectswords:summon_cage/9
execute if score random cagemobs matches 10 run function projectswords:summon_cage/10
execute if score random cagemobs matches 11 run function projectswords:summon_cage/11
execute if score random cagemobs matches 12 run function projectswords:summon_cage/12
execute if score random cagemobs matches 13 run function projectswords:summon_cage/13
execute if score random cagemobs matches 14 run function projectswords:summon_cage/14
execute if score random cagemobs matches 15 run function projectswords:summon_cage/15
execute if score random cagemobs matches 16 run function projectswords:summon_cage/16
execute if score players difficulty matches 1 if score timer cagemobs matches 600.. run scoreboard players set timer cagemobs 1
execute if score players difficulty matches 2 if score timer cagemobs matches 400.. run scoreboard players set timer cagemobs 1
execute if score players difficulty matches 3 if score timer cagemobs matches 300.. run scoreboard players set timer cagemobs 1
execute if score players difficulty matches 4.. if score timer cagemobs matches 200.. run scoreboard players set timer cagemobs 1
execute if score limit cagemobs matches 12.. run tag @a add cagelimit
execute unless score limit cagemobs matches 12.. run tag @a remove cagelimit
fill -209 47 -8 -207 47 -10 air
fill -203 37 -19 -205 37 -17 air
fill -189 43 -4 -187 43 -6 air
fill -205 41 3 -203 41 1 air