execute if entity @s[tag=FireRange1] run teleport @e[type=minecraft:block_display,tag=FireDisplay1,distance=..5,limit=1,sort=nearest] ~-2 ~ ~-2
execute if entity @s[tag=FireRange2] run teleport @e[type=minecraft:block_display,tag=FireDisplay2,distance=..5,limit=1,sort=nearest] ~-2 ~ ~-2
execute if entity @s[tag=FireRange3] run teleport @e[type=minecraft:block_display,tag=FireDisplay3,distance=..5,limit=1,sort=nearest] ~-2 ~ ~-2

fill ~2 ~-2 ~2 ~-2 ~2 ~-2 air replace fire

execute as @a[distance=..2.5] at @s run summon minecraft:small_fireball ~ ~3 ~ {acceleration_power:2d,Motion:[0.0,-5.0,0.0]}