# Allay Unlock #
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:0b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:1b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:2b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:3b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:4b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:5b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:6b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:7b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay
execute as @a[tag=has.allay_key] if block -276 78 154 dropper{Items:[{Slot:8b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run tag @s add opened.allay

execute if block -276 78 154 dropper{Items:[{Slot:2b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block
execute if block -276 78 154 dropper{Items:[{Slot:1b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block
execute if block -276 78 154 dropper{Items:[{Slot:0b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block
execute if block -276 78 154 dropper{Items:[{Slot:3b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block
execute if block -276 78 154 dropper{Items:[{Slot:4b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block
execute if block -276 78 154 dropper{Items:[{Slot:5b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block
execute if block -276 78 154 dropper{Items:[{Slot:8b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block
execute if block -276 78 154 dropper{Items:[{Slot:7b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block
execute if block -276 78 154 dropper{Items:[{Slot:6b,id:"minecraft:tripwire_hook",components:{"minecraft:custom_data":{tower:1b}},count:1}]} run setblock -251 35 141 minecraft:redstone_block


