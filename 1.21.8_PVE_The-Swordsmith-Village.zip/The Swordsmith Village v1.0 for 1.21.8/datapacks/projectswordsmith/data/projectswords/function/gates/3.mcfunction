fill -237 74 45 -235 74 41 air replace minecraft:iron_bars
playsound minecraft:block.chain.step master @a -237 74 43 0.8 0.7
schedule function projectswords:gates/4 1s append