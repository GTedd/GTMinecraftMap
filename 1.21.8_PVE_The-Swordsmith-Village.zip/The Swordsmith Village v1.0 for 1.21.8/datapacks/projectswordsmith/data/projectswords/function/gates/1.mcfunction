fill -237 72 45 -235 72 41 air replace minecraft:iron_bars
playsound minecraft:block.chain.step master @a -237 72 43 0.8 0.7
schedule function projectswords:gates/2 1s append