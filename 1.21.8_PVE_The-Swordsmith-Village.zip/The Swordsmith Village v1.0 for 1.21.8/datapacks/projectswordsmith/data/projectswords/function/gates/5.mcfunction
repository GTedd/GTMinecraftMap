fill -237 76 45 -235 76 41 air replace minecraft:iron_bars
playsound minecraft:block.chain.step master @a -237 76 43 0.8 0.7
