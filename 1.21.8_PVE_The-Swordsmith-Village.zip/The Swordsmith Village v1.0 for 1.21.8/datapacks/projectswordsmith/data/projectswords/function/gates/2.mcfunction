fill -237 73 45 -235 73 41 air replace minecraft:iron_bars
playsound minecraft:block.chain.step master @a -237 73 43 0.8 0.7
schedule function projectswords:gates/3 1s append