fill -237 75 45 -235 75 41 air replace minecraft:iron_bars
playsound minecraft:block.chain.step master @a -237 75 43 0.8 0.7
schedule function projectswords:gates/5 1s append