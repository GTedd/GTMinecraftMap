setblock -229 44 96 air
title @a title [{"text":"❆ ","color":"white","bold":true},{"text":"BLIZZARD","color":"aqua","bold":true,"underlined":true},{"text":" ❆","color":"white","bold":true}]
title @a subtitle [{"text":"Mobs Are Frozen For ","color":"aqua","bold":true,"underlined":true},{"text":"15 ","color":"white","bold":true,"underlined":true},{"text":"Seconds","color":"aqua","bold":true,"underlined":true}]
setblock -229 41 95 minecraft:redstone_block
setblock -228 41 96 minecraft:redstone_block
