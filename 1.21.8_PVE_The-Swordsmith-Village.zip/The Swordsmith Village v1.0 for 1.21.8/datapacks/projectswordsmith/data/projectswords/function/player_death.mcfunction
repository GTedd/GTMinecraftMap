title @s times 0s 9s 0s
scoreboard players add @s respawn.timer 1
execute if score @s respawn.timer matches 1 run title @s title {"text":"Respawning in...","color":"yellow"}
execute if score @s respawn.timer matches 1 run title @s subtitle {"text":"10","color":"red"}
execute if score @s respawn.timer matches 20 run title @s subtitle {"text":"9","color":"red"}
execute if score @s respawn.timer matches 40 run title @s subtitle {"text":"8","color":"red"}
execute if score @s respawn.timer matches 60 run title @s subtitle {"text":"7","color":"red"}
execute if score @s respawn.timer matches 80 run title @s subtitle {"text":"6","color":"red"}
execute if score @s respawn.timer matches 100 run title @s subtitle {"text":"5","color":"red"}
execute if score @s respawn.timer matches 120 run title @s subtitle {"text":"4","color":"red"}
execute if score @s respawn.timer matches 140 run title @s subtitle {"text":"3","color":"red"}
execute if score @s respawn.timer matches 160 run title @s subtitle {"text":"2","color":"red"}
execute if score @s respawn.timer matches 180 run title @s subtitle {"text":"1","color":"red"}
execute if entity @s[tag=!boss_spawned] if score @s respawn.timer matches 199 run tp @s -197 65 113 90 0
execute if entity @s[tag=!boss_spawned] if score @s respawn.timer matches 199 at @s run playsound minecraft:entity.evoker.prepare_summon master @s ~ ~ ~ 2 1.8
execute if entity @s[tag=!boss_spawned] if score @s respawn.timer matches 199 at @s run particle minecraft:witch ~ ~ ~ 0.3 3 0.3 1 30 normal
execute if entity @s[tag=!boss_spawned] if score @s respawn.timer matches 199 at @s run particle minecraft:warped_spore ~ ~ ~ 0.3 3 0.3 1 50 normal
execute if entity @s[tag=boss_spawned] if score @s respawn.timer matches 199 run tp @s -229 25 -32
execute if entity @s[tag=boss_spawned] if score @s respawn.timer matches 199 at @s run playsound minecraft:entity.evoker.prepare_summon master @s ~ ~ ~ 2 1.8
execute if entity @s[tag=boss_spawned] if score @s respawn.timer matches 199 at @s run particle minecraft:witch ~ ~ ~ 0.3 3 0.3 1 30 normal
execute if entity @s[tag=boss_spawned] if score @s respawn.timer matches 199 at @s run particle minecraft:warped_spore ~ ~ ~ 0.3 3 0.3 1 50 normal
execute if score @s respawn.timer matches 200 run scoreboard players reset @s respawn.timer