playsound minecraft:entity.player.levelup master @a 0 101 0
title @a title [{"text":"YOU WIN!","color":"green","bold":true}]